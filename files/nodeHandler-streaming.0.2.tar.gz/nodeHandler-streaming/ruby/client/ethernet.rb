require 'client/device'

#
# This class represents an Ethernet device
#
class EthernetDevice < Device

  def initialize(logicalName, deviceName)
    super(logicalName, deviceName)
  end
  
  def getConfigCmd(prop, value)
    debug "looking for property '#{prop}' in ethernet"
    case prop
      when 'ip'
       return "/sbin/ifconfig #{@deviceName} #{value} netmask 255.255.0.0"      
           
      when 'up'
       return "/sbin/ifconfig #{@deviceName} up"      
      when 'down'
       return "/sbin/ifconfig #{@deviceName} down"      

      when 'arp'
        dash = (value == 'true') ? '' : '-'
        return "/sbin/ifconfig #{@deviceName} #{dash}arp"      

      when 'forwarding'
        flag = (value == 'true') ? '1' : '0'
        return "echo #{flag} > /proc/sys/net/ipv4/conf/#{@deviceName}/forwarding"
    end
    super
  end
  
end
