#
# This runs on the node
#
require 'mobject'
require 'communication'


class NodeAgent < MObject

  include NodeCommunication

  VERSION = "$Revision: 1.2 $".split(":")[1].chomp("$").strip

  # Interface used for the control channel
  CONTROL_IF = "eth1"
  
  # Singleton
  @@instance = nil
  
  #
  # Return singleton
  #
  def NodeAgent.instance
    return @@instance
  end
  
  #
  # Run node agent. This method will
  # block until somebody calls 'done'
  #
  def NodeAgent.run
    if (@@instance != nil)
      raise "Already running"
    end
    @@instance = NodeAgent.new
    @@running = ConditionVariable.new
    @@mutex = Mutex.new
    @@mutex.synchronize {
      @@running.wait(@@mutex)
    }
  end
  
  
  # Send a reply back to the node handler
  #
  # @param code Code of reply
  # @param id Id of component sending reply
  # @param message Optional text message
  #
  def NodeAgent.sendReply(code, id, message = nil)
    instance.send("#{code} #{id} #{message}")
  end

  # Send an ERROR reply back to the node handler
  #
  # @param id Id of component sending reply
  # @param message Optional text message
  #
  def NodeAgent.sendErrorReply(id, message = nil) 
    NodeAgent.sendReply(:error, id, message)
  end

  private
  
  # Start the node agent
  def initialize
    initCommunication(true)
    # check in
    send("whoami #{Socket.gethostname} #{VERSION}")
  end

  # 
  # Return the IP address of the control interface
  #
  # This method assumes that the 'ifconfig' command returns something like:
  #
  # eth1      Link encap:Ethernet  HWaddr 00:0D:61:46:1E:E1  
  #           inet addr:10.10.101.101  Bcast:10.10.255.255  Mask:255.255.0.0
  #           UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
  #           RX packets:118965 errors:0 dropped:0 overruns:0 frame:0
  #           TX packets:10291 errors:0 dropped:0 overruns:0 carrier:0
  #           collisions:0 txqueuelen:1000 
  #           RX bytes:17394487 (16.5 MiB)  TX bytes:1073233 (1.0 MiB)
  #           Interrupt:11 Memory:eb024000-0 
  #
  def getMCInterface
    #controlIP = IO.popen("/sbin/ifconfig #{CONTROL_IF}", "r").readlines[1][/[.\d]+/]
    return "192.168.121.234"
  end
end

#
# START
#
MObject::initLog(Socket.gethostname)
NodeAgent.run




