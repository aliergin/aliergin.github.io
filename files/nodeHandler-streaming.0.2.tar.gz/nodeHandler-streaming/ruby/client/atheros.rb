
require 'client/ethernet'

#
# This class represents an Atheros device
#
class AtherosDevice < EthernetDevice

  def initialize(logicalName, deviceName)
    super(logicalName, deviceName)
    @essid = "ORBIT"
    @loaded = false
  end
  
  def getConfigCmd(prop, value)

    case prop
      when 'type'
        # 'value' defines type of operation
        p = case
          when value == 'a' : 1
          when value == 'b' : 2
          when value == 'g' : 3
          else 
            raise "Unknown type. Should be 'a', 'b', or 'g'."
        end
        return "iwpriv #{@deviceName} mode #{p}"

      when "mode"
        # 'value' defines mode of operation
        p = case
          when value == 'master' : 'Master'
          when value == 'managed' : 'Managed'
          else 
            raise "Unknown mode '#{value}'. Should be 'master', or 'managed'."
        end
        return "/sbin/iwconfig #{@deviceName} mode #{value}"

      when "essid"
        @essid = value
        return "/sbin/iwconfig #{@deviceName} essid #{value}"

      when "frequency"
        return "/sbin/iwconfig #{@deviceName} freq #{value}"      

      when "tx_power"
        return "/sbin/iwconfig #{@deviceName} txpower #{value}"      
     
      when "rts"
        return "/sbin/iwconfig #{@deviceName} rts #{value}"

      when "rate"
        return "/sbin/iwconfig #{@deviceName} rate #{value}"

      when "unload"
        return "/sbin/modprobe -r #{value}"

      when "load"
        return "/sbin/modprobe #{value}"
	
      when "bash"
        return "/bin/sh #{value}"

    end
    super
  end
  
  #  
  # Called multiple times to ensure that device is up
  #
  def activate()
    if (! @loaded)
      reply = `/sbin/modprobe ath_pci`
      if ! $?.success?
        raise "Problems loading Atheros module -- #{reply}"      
      end
      @loaded = true
    end
  end
    
end