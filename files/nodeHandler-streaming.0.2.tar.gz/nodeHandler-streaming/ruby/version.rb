#
# Defines a class to define application versions
#


class Version

  VERSION_EL_NAME = "version"
  
  attr_reader :major, :minor, :revision
  
  def initialize(major = 0, minor = 0, revision = 0)
  
    @major = major
    @minor = minor
    @revision = revision
  end

  #
  # Return the version definition as an XML element
  #
  def to_xml
    e = REXML::Element.new("version")
    e.add_element("major").text = major
    e.add_element("minor").text = minor
    e.add_element("revision").text = revision
    
    return e
  end

end
   
class MutableVersion < Version

  attr_writer :major, :minor, :revision
     
end   
 
 
#mu = MutableVersion.new 4
#mu.major
#mu.major = 2
#mu.major
