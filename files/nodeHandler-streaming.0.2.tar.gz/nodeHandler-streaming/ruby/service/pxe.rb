#
# Implements various servlets to control what PXE serves to nodes
#

require 'webrick'
require 'webrick/httpstatus'
require 'stringio'
require 'log4r'
require 'util/mobject'
require 'util/websupp'


include WEBrick

module PxeService

  # Directory holding PXE information
  PXE_DIR = "/tftpboot/pxelinux.cfg"

  # Image served by default
  DEFAULT_IMAGE = "orbit-1.0.0"

  # Port of what?
  PORT = 5000

  # Port for this web server to listen on
  WEB_PORT = 5005

  # Maximum age of PXE symbolic link
  MAX_TIME = 15 * 60;

  # How long do we sleep before we check for stale links
  SLEEP_TIME  = 10 * 60;

  def PxeService.mount(prefix = '/pxe')
    GridService.mount_proc(prefix) {|req, res|
      res['ContentType'] = "text/html"
      res.body = %{<?xml version='1.0'?>
        <serviceGroup name="pxe">
          <info>Serve node images via a pxe server</info>
          <service name="setBootImage">
            <info>Configure PXE to boot a node with a specific ip address into a specifif image</info>
            <args><arg name="img" value="imageName"/></args>
            <args><arg name="node" value="nodeName"/></args>
            <args><arg name="ip" value="ipAddress"/></args>
          </service>
          <service name="clearBootImage">
            <info>Configure PXE to boot a node into the image on its disk</info>
            <args><arg name="node" value="nodeName"/></args>
            <args><arg name="ip" value="ipAddress"/></args>
          </service>
          <service name="removeAllBootImages">
            <info>Configure PXE to boot all nodes into the image on their disks</info>
          </service>
          <service name="status">
            <info>Returns a list of IP addresses and their associated boot image</info>
          </service>
        </serviceGroup>
      }
    }
    GridService.mount("#{prefix}/setBootImage", SetBootImageServlet)
    GridService.mount("#{prefix}/clearBootImage", ClearBootImageServlet)
    GridService.mount("#{prefix}/removeAllBootImages", RemoveAllBootImagesServlet)
    GridService.mount("#{prefix}/status", StatusServlet)  

    # Start the cleaner thread ...

    Thread.new() {
      loop do
        MObject.debug("Viper thread run")
        PxeService.cleanstale
        sleep SLEEP_TIME
      end
    }

  end
  
  # Cleans stale links
  def PxeService.cleanstale
    Dir.chdir(PXE_DIR) {
      # Find all directory entries that have only 8 hex digits in the name
      Dir['[0-9,A-F][0-9,A-F][0-9,A-F][0-9,A-F][0-9,A-F][0-9,A-F][0-9,A-F][0-9,A-F]'].each { |link|
        # Let's make sure it is a symlink
        if File.symlink?(link) then
          # And then delete it if older than MAX seconds
          #File.delete(link) unless  (Time.new - File.ctime(link)) <= MAX_TIME
          if (Time.new - File.ctime(link)) > MAX_TIME then
            MObject.debug("Deleting stale PXE link "+link)
            File.delete(link)
          end
        end
      }
    }
  end

  #
  # Configure the tftp directory to force a node with
  # IP address @v addr to boot into @v image.
  #
  class SetBootImageServlet < HTTPServlet::AbstractServlet
    def do_GET(req, res)
      # Let's see the arguments to this request
      q = req.query
      img = q['img'] || DEFAULT_IMAGE
      imgPath = "#{PXE_DIR}/#{img}"
      if ! File.readable?(imgPath) 
        raise HTTPStatus::BadRequest, "Image file '#{imgPath}' not found"
      end
      # Which subdomain did the request come from?
      domain = Websupp.getPeerSubDomain(req)
      # We have to get either node names or IP address as well
      ips = Websupp.getIPAddresses(q, domain)
      # Do we have everything?
      if (img == nil || ips == nil || ips.length < 1)
        raise HTTPStatus::BadRequest, "Missing argument 'img', 'node' or 'ip'"
      end
      ips.each { |ip|
        # turn '10.11.12.13' into 0A0B0C0D
        hex = ip.split('.').map {|e| format "%02X", e} . join()
        hexPath = "#{PXE_DIR}/#{hex}"
        if File.readable?(hexPath)
          MObject.debug("setBootImage: Remove old #{hexPath}")
          File.delete(hexPath)
        end
        cmd = "#{PXE_DIR}/makeLink #{img} #{hex}"
        MObject.debug("Executing '#{cmd}'")
        if ! system(cmd) 
          raise HTTPStatus::BadRequest, "Couldn't create link to boot image (#{$?})"
        end
      }
      res['ContentType'] = "text"
      res.body = "OK"
    end
  end
  
  #
  # Remove the boot image for IP address @v
  #
  class ClearBootImageServlet < HTTPServlet::AbstractServlet
    def do_GET(req, res)
      # Which subdomain did the request come from?
      domain = Websupp.getPeerSubDomain(req)
      # We have to get either node names or IP address as well
      ips = Websupp.getIPAddresses(req.query, domain)
      # Do we have everything?
      if (ips == nil || ips.length < 1)
        raise HTTPStatus::BadRequest, "Missing argument 'node' or 'ip'"
      end
      ips.each { |ip|
        # turn '10.11.12.13' into 0A0B0C0D
        hex = ip.split('.').map {|e| format "%02X", e} . join()
        hexPath = "#{PXE_DIR}/#{hex}"
        if File.readable?(hexPath)
          MObject.debug("clearBootImage: Remove old #{hexPath}")
          File.delete(hexPath)
        end
      }
      res['ContentType'] = "text"
      res.body = "OK"
    end
  end
  
  #
  # Remove pxe booting for all IP adrresses
  #
  class RemoveAllBootImagesServlet < HTTPServlet::AbstractServlet
    def do_GET(req, res)
      # Which subdomain did the request come from?
      domain = Websupp.getPeerSubDomain(req)
      addr = Websupp.getAddress("repository.#{domain}")
      if (addr==nil) 
        raise HTTPStatus::BadRequest, "Host not found 'repository.#{domain}"
      end
      # Lest take just frist two octets ...
      ip=addr.to_s.split('.').slice(0..1).join('.')
      # turn '10.11.x.x' into 0A0B
      hex = ip.split('.').map {|e| format "%02X", e} . join()
      Dir.chdir(PXE_DIR) {
        Dir["#{hex}[0-9,A-Z][0-9,A-Z][0-9,A-Z][0-9,A-Z]"].each { |link|
          if File.symlink?(link)
              MObject.debug("Deleting all subnet (#{hex}*) link ="+link)
              File.delete(link)
          end
        }
      }
      res['ContentType'] = "text"
      res.body = "OK"
    end
  end
  

  class StatusServlet < HTTPServlet::AbstractServlet
    def do_GET(req, res)
      res['ContentType'] = "text/xml"
      s = %{<?xml version='1.0'?>
        <pxe_status>
          <pxe_dir>#{PXE_DIR}</pxe_dir>
          <default_image>#{DEFAULT_IMAGE}</default_image>
      }
      Dir.chdir(PXE_DIR) {
        Dir['[0-9,A-F][0-9,A-F][0-9,A-F][0-9,A-F][0-9,A-F][0-9,A-F][0-9,A-F][0-9,A-F]'].each { |n|
          if File.symlink?(n)
            name = File.readlink(n)
            ip =  [n[0,2], n[2,2], n[4,2], n[6,2]].map{|e| e.hex}.join('.')
            s += "  <boot ip='#{ip}' img='#{name}' link='#{n}'/>\n"
          end
        }
      }
      s += "</pxe_status>"
      res.body = s
    end
  end

end

if $0 == __FILE__
include Log4r

  MObject.initLog('pxeService')

  MObject.info("PXE Service Testharness")

  
  module GridService

    SERVER = HTTPServer.new(
      :Port => 5012,
      :Logger => Logger.new("#{MObject.logger.fullname}::web")
    )

    def GridService.mount(name, servlet)
      SERVER.mount(name, servlet)
    end

    def GridService.mount_proc(name, &block) 
      SERVER.mount_proc(name, &block)
    end
  end

  trap("INT") { GridService::SERVER.shutdown }
  GridService::SERVER.start
end

PxeService::mount()
