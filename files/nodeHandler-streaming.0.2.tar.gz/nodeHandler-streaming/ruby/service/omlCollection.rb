#
# This servlet accepts an OML server configuration file and
# and starts a collection server on behalf of the caller.
#

require 'webrick'
require 'stringio'
require 'log4r'
require 'util/mobject'
require 'util/websupp'
require 'date'
require 'rexml/document'
require 'external/mysql'

include WEBrick

module OmlCollectionService

  DB_USER = 'orbit'
  DB_PASSWORD = 'orbit'
  #
  # DB_HOST ='idb1.grid.orbit-lab.org'
  #	
  DB_HOST ='10.10.0.8'

  # Multicast address to use for servicing images
  MC_ADDRESS = "224.0.0.6"

  # Default interface to use for multicast
  DEFAULT_IF = "eth1"

  # Time out daemon if nobody requested it within TIMEOUT sec
  TIMEOUT = 10000
  
  # Using ports starting at ...
  MC_START_PORT = 7000

  # Max. number of active daemons allowed
  MAX_DAEMONS = 10

  # Local interface to bind to for frisbee traffic
  #variable MULTICAST_IF    "192.168.160.11"
  MULTICAST_IF = "10.10.0.40"
  

  # Mapping between OML data types and SQL types. 
  # Fix the duplication of xsd: and plain types.
  XSD2SQL = {
    "xsd:float" => "FLOAT NOT NULL",
    "xsd:int" => "INTEGER NOT NULL",
#    "xsd:long" => "LONG NOT NULL",
    "xsd:long" => "INTEGER NOT NULL",
    "xsd:short" => "INTEGER NOT NULL",
    "xsd:bool" => "DO NOT KNOW",
    "xsd:string" => "CHAR(32) NOT NULL",
    "float" => "FLOAT NOT NULL",
    "int" => "INTEGER NOT NULL",
#    "long" => "LONG NOT NULL",
    "long" => "INTEGER NOT NULL",
    "short" => "INTEGER NOT NULL",
    "bool" => "DO NOT KNOW",
    "string" => "CHAR(32) NOT NULL"
  }

  SERVER_BIN = '/usr/bin/oml_collection_server'
  SERVER_DEBUG_LEVEL = 5


  def OmlCollectionService.mount(prefix = '/oml')
    GridService.mount_proc(prefix) {|req, res|
      res['ContentType'] = "text/html"
      res.body = %{<?xml version='1.0'?>
        <serviceGroup name="oml">
          <info>Interface to OML collection server</info>
          <service name="start">
            <info>
              Start a collection server. The config information is expected
              to be in the body.
            </info>
          </service>
          <service name="stop">
            <info>Stop a specific collection service</info>
            <args><arg name="id" value="idReturnedByStart"/></args>
          </service>
          <service name="log">
            <info>Return the log file of the named service</info>
            <args><arg name="id" value="idReturnedByStart"/></args>
          </service>
          <service name="status">
            <info>Returning the status of the service</info>
          </service>
        </serviceGroup>
      }
    }
    GridService.mount("#{prefix}/start", StartServlet)
    GridService.mount("#{prefix}/stop", StopServlet)
    GridService.mount("#{prefix}/log", LogServlet)
    GridService.mount("#{prefix}/status", StatusServlet)  
  end
  

  class StartServlet < HTTPServlet::AbstractServlet
    def do_GET(req, res)
      raise HTTPStatus::NotFound, "Use POST instead"
    end
    
    def do_POST(req, res)
      content = req.body
      q = req.query
      id = q['id']
      if (content == nil)
        raise HTTPStatus::NotFound, "Missing configure information in body"
      end
      begin
	d = Daemon.start(content, id)
      rescue Exception => e
        raise HTTPStatus::NotFound, e.to_s
      end
      res['ContentType'] = "text/xml"
      s = "<collection_server id='#{d.daemon_id}'>\n"
      s += "  <multicast-channel "
      s += "port='#{d.port}' addr='#{d.addr}' iface='#{d.iface}'"
      s += "/>\n</collection_server>"
      res.body = s

    end
  end
  
  class StopServlet < HTTPServlet::AbstractServlet
    def do_GET(req, res)
      q = req.query
      id = q['id']
      if (id == nil)
        raise HTTPStatus::NotFound, "Missing 'id' parameter"
      end
      d = Daemon.stop(id)
      res['ContentType'] = "text"
      res.body = "Done"
    end
  end

  class LogServlet < HTTPServlet::DefaultFileHandler

    def initialize(server, *options)
      super(server, nil)
    end

    def do_GET(req, res)
      q = req.query
      id = q['id']
      if (id == nil)
        raise HTTPStatus::NotFound, "Missing 'id' parameter"
      end
      d = Daemon[id]
      if (d == nil)
        raise HTTPStatus::NotFound, "Unknown service '#{id}'"
      end
      @local_path = d.logFile
      super(req, res)
    end
  end
  

  class StatusServlet < HTTPServlet::AbstractServlet
    def do_GET(req, res)
      q = req.query
      id = q['id']
      if (id == nil)
        list = Daemon.all
      else
        list = Daemon[id]
      end
     
      res['ContentType'] = "text/xml"
      s = %{<?xml version='1.0'?>
        <oml_status>
      }
      list.each { |d|
        s += "  <daemon id='#{d.daemon_id}' addr='#{d.addr}' port='#{d.port}' "
	s += "iface='#{d.iface}' logfile='#{d.logFile}' timeLeft='#{d.untilTimeout}'/>\n"
      } if list != nil
      s += "</oml_status>"
      res.body = s
    end
  end
  
   class Daemon < MObject
  
    @@inst = Hash.new
    
    def Daemon.start(config, id = nil)
      if id != nil && @@inst.has_key?(id)
        raise HTTPStatus::NotFound, "Already exists. Use different name"
      end
      if (@@inst.length > MAX_DAEMONS)
        raise HTTPStatus::NotFound, "Max. number of daemons reached. Shutdown others and try again"
      end
      d = Daemon.new(config, id)
      return d
    end
    
    def Daemon.stop(id)
      d = @@inst[id]
      if (d != nil)
        d.stop
      end
    end

    def Daemon.[] (id)
      return @@inst[id]
    end
    
    def Daemon.all
      return @@inst.values
    end

    attr_reader :daemon_id, :addr, :port, :iface, :logFile, :running
    
    def initialize(config, id)

      @addr = MC_ADDRESS
      @iface = DEFAULT_IF
      @port = findPort()
      
      io = StringIO.new(config)
      doc = REXML::Document.new(io)
      
      root = doc.root
      if root.name != 'experiment'
        raise "Expected 'experiment' as root of XML document, but found '#{root.name}'"
      end

      if (@daemon_id = id) == nil
	if (@daemon_id = root.attributes['id']) == nil
	  @daemon_id = DateTime.now.strftime("%F-%T").split(':').join('-')
	end
      end
      logger("oml::#{@daemon_id}")

      root.add_element("multicast-channel", 
        {'port' => @port, 'addr' => @addr, 'iface' => @iface})
      root.add_element("db", 
        {'user' => DB_USER, 'id' => @daemon_id, 'host' => DB_HOST, 'password' => DB_PASSWORD})
      
      cfgFile = "/tmp/#{@daemon_id}.xml"
      f = File.open(cfgFile, "w")
      doc.write(f)
      f.close
      info("Wrote config to #{cfgFile}")

      createDB(root)      

      @logFile = "/tmp/#{@daemon_id}.log"
      dbDir = "/tmp/#{@daemon_id}"
      cmd = "#{SERVER_BIN} -l #{@logFile} -d #{SERVER_DEBUG_LEVEL} -b #{dbDir} #{cfgFile}"
      debug("Exec '#{cmd}'")
      run(cmd)


      # check if that was successful
      sleep 1  # give it some time to start up
      if (! @running)
        raise "Starting oml_collection_server daemon failed"
      end
      @@inst[@daemon_id] = self
    end

    def createDB(root)
      dbHandle = Mysql.connect(DB_HOST, DB_USER, DB_PASSWORD)
      info("Create database #{@daemon_id}")
      sql = "CREATE DATABASE #{@daemon_id};"
      debug(sql)
      dbHandle.query(sql)
      
      cnt = 1
      root.elements.each("//measurement-point") { |mp|
        tableName = mp.attributes['table']
        if (tableName == nil)
          tableName = mp.attributes['name'] + cnt.to_s
          cnt += 1
        end
        sql = "CREATE TABLE #{@daemon_id}.#{tableName} ("
        sql += "node_id VARCHAR(32), "
        sql += "sequence_no INTEGER NOT NULL, "
        sql += "timestamp INTEGER NOT NULL, "
	spacer = ""
        mp.elements.each("metric") { |m|
          sql += spacer
          refid = m.attributes['refid']
	  if (refid == nil) 
	    raise "Missing attribute 'refid' in metric"
	  end
          filters = m.elements.to_a("filter")
          if filters.length == 0
            type = m.attributes['type'] 
            raise "Missing type in #{m.to_s}" if type == nil
            sql += "#{refid} #{XSD2SQL[type]}"
          else
            spacer2 = ""
            filters.each {|f|
              f_refid = f.attributes['refid']
              type = f.attributes['returnType'] 
              raise "Missing type in filter #{f.to_s} in #{m.to_s}" if type == nil              
	          sql += "#{spacer2}#{refid}_#{f_refid} #{XSD2SQL[type]}"
              spacer2 = ", "
            }
          end
	  spacer = ", "
        }
        sql += "); "
	debug(sql)
	dbHandle.query(sql)
      }
    end
    
    def stop()
      @running = false  # to avoid error message from kill
      Process.kill("KILL", @pid)
    end
    
    def findPort()
      # this is REALLY ugly
      port = MC_START_PORT
      while true
        good = true
        @@inst.each_value { |v|
          if (v.port == port)
            good = false
            break
          end
        }
        if (good)
          return port
        end
        port += 1 
      end
    end
    
    def run(cmd)
      @pipe = pipe = IO::pipe

      info "Starting #{cmd}"
      @running = true
      @pid = fork {
        begin
          exec(cmd)
        rescue
          error("exec failed for '#{cmd}': #{$!}")
        end
        # Should never get here
        exit! 
      }
      # Create thread which waits for application to exit
      Thread.new(@pid) {|pid|
        ret = Process.waitpid2(pid)
        status = ret[1]
        # app finished
        if ! status.success? && @running
          error "omlCollection daemon '#{@id}' failed (code=#{status.exitstatus})"
        end
        done()
      }
      # Create thread to time out daemon
      ping()
      Thread.new() {
        while ((diff = Time.now - @pingTime) < TIMEOUT)
          debug "Check for time out (#{diff}:#{TIMEOUT})"
          sleep TIMEOUT - diff + 2
        end
        info "#{@id} timed out"
        stop
      }
      
    end
    
    #
    # Return the time in seconds before this instance will timeout
    #
    def untilTimeout()
      return TIMEOUT - (Time.now - @pingTime)
    end
    
    def ping()
      @pingTime = Time.now
    end
    
    def done()
      info "#{@daemon_id} done"
      @running = false
      @@inst.delete(@daemon_id)
    end
    
  end
end

if $0 == __FILE__
include Log4r

  MObject.initLog('omlCollectionService')
  MObject.info("omlCollection Service Testharness")

  module GridService

    SERVER = HTTPServer.new(
      :Port => 5013,
      :Logger => Logger.new("#{MObject.logger.fullname}::web")
    )

    def GridService.mount(name, servlet)
      SERVER.mount(name, servlet)
    end

    def GridService.mount_proc(name, &block) 
      SERVER.mount_proc(name, &block)
    end
  end

end

OmlCollectionService::mount()

if $0 == __FILE__
  trap("INT") { GridService::SERVER.shutdown }
  GridService::SERVER.start
end  
