#
# Implements various servlets to control a frisbee server
#

require 'webrick'
require 'stringio'
require 'log4r'
require 'util/mobject'
require 'util/websupp'

include WEBrick

module FrisbeeService

  IMAGE_DIR = "/export/orbit/image"
  DEFAULT_IMAGE = "orbit-baseline"

  BANDWIDTH = 50000000

  # Multicast address to use for servicing images
  MC_ADDRESS = "224.0.0.2"

  # Time out daemon if nobody requested it within TIMEOUT sec
  TIMEOUT = 1000
  
  # Using ports starting at ...
  MC_START_PORT = 7000

  # Max. number of active daemons allowed
  MAX_DAEMONS = 10

  # Local interface to bind to for frisbee traffic
  #variable MULTICAST_IF    "192.168.160.11"
  MULTICAST_IF = "10.10.0.40"

  # Directory to find frisbee daemon
  FRISBEE_BIN = "/opt/frisbee/bin"
  FRISBEED = "#{FRISBEE_BIN}/frisbeed"

  # Port for this web server to listen on
  WEB_PORT = 5005


  def FrisbeeService.mount(prefix = '/frisbee')
    GridService.mount_proc(prefix) {|req, res|
      res['ContentType'] = "text/html"
      res.body = %{<?xml version='1.0'?>
        <serviceGroup name="frisbee">
          <info>Serve node images via a frisbee server</info>
          <service name="getAddress">
            <info>Get the port number of a frisbee server serving a specified image</info>
            <args><arg name="img" value="imageName"/></args>
          </service>
          <service name="stop">
            <info>Stop serving a specified image</info>
            <args><arg name="img" value="imageName"/></args>
          </service>
          <service name="status">
            <info>Returns the status of either a specific daemon, or all of them</info>
            <args><arg name="img" value="imageName" optional="true"/></args>
          </service>
        </serviceGroup>
      }
    }
    GridService.mount("#{prefix}/getAddress", GetAddressServlet)
    GridService.mount("#{prefix}/stop", StopServlet)
    GridService.mount("#{prefix}/status", StatusServlet)  
  end
  

  class GetAddressServlet < HTTPServlet::AbstractServlet
    def do_GET(req, res)
      q = req.query
      img = q['img']
      if (img == nil)
        raise HTTPStatus::BadRequest, "Missing argument 'img'"
      end
      # Which subdomain did the request come from?
      domain = Websupp.getPeerSubDomain(req)
      addr = Websupp.getAddress("repository.#{domain}")
      if (addr==nil)
        raise HTTPStatus::BadRequest, "Interface IP address not found for 'repository.#{domain}"
      end
      d = Daemon.start(img,addr)
      res['ContentType'] = "text"
      res.body = "#{MC_ADDRESS}:#{d.port.to_s}"
    end
  end
  
  class StopServlet < HTTPServlet::AbstractServlet
    def do_GET(req, res)
      q = req.query
      img = q['img']
      if (img == nil)
        raise HTTPStatus::BadRequest, "Missing sargument 'img'"
      end
      d = Daemon.stop(img)
      res['ContentType'] = "text"
      res.body = "Done"
    end
  end
  

  class StatusServlet < HTTPServlet::AbstractServlet
    def do_GET(req, res)
      q = req.query
      img = q['img']
      if (img == nil)
        list = Daemon.all
      else
        list = Daemon[img]
      end
     
      res['ContentType'] = "text/xml"
      s = %{<?xml version='1.0'?>
        <frisbee_status>
          <bandwidth>#{BANDWIDTH / 1000000.0}</bandwidth>
          <mc_address>#{MC_ADDRESS}</mc_address>
      }
      list.each { |d|
        s += "  <daemon img='#{d.img}' port='#{d.port}' timeLeft='#{d.untilTimeout}'/>\n"
      } if list != nil
      s += "</frisbee_status>"
      res.body = s
    end
  end


  class Daemon < MObject
  
    @@inst = Hash.new
    
    def Daemon.start(img,addr)
      d = @@inst[img]
      if (d == nil)
        if (@@inst.length > MAX_DAEMONS)
          raise HTTPStatus::BadRequest, "Max. number of daemons reached. Shutdown others and try again"
        end
        d = Daemon.new(img,addr)
      end
      d.ping  # somebody cares about you
      return d
    end
    
    def Daemon.stop(img)
      d = @@inst[img]
      if (d != nil)
        d.stop
      end
    end

    def Daemon.[] (img)
      return @@inst[img]
    end
    
    def Daemon.all
      return @@inst.values
    end

    attr_reader :port, :img, :running
    
    def initialize(img,addr)

      @img = img

      imgPath = "#{IMAGE_DIR}/#{img}"
      if ! File.readable?(imgPath) 
        raise HTTPStatus::BadRequest, "Image file '#{imgPath}' not found"
      end

      @port = findPort() 
    
      debug("Starting frisbeed for '#{img}' on '#{port}' interface '#{addr}'")
      cmd = "#{FRISBEED} -i #{addr} -m #{MC_ADDRESS} -p #{port} -W #{BANDWIDTH} #{imgPath}"
      run(cmd)
      # check if that was successful
      sleep 1  # give it some time to start up
      if (! @running)
        raise HTTPStatus::BadRequest, "Starting frisbee daemon for #{img} failed"
      end
      @@inst[img] = self
    end

    def stop()
      @running = false  # to avoid error message from kill
      Process.kill("KILL", @pid)
    end
    
    def findPort()
      # this is REALLY ugly
      port = MC_START_PORT
      while true
        good = true
        @@inst.each_value { |v|
          if (v.port == port)
            good = false
            break
          end
        }
        if (good)
          return port
        end
        port += 1 
      end
    end
    
    def run(cmd)
      @pipe = pipe = IO::pipe

      info "Starting #{cmd}"
      @running = true
      @pid = fork {
        begin
          exec(cmd)
        rescue
          pipe.puts "exec failed for '#{cmd.join(' ')}': #{$!}"
        end
        # Should never get here
        exit! 
      }
      # Create thread which waits for application to exit
      Thread.new(@pid) {|pid|
        ret = Process.waitpid2(pid)
        status = ret[1]
        # app finished
        if ! status.success? && @running
          error "Frisbee daemon '#{@img}' failed (code=#{status.exitstatus})"
        end
        done()
      }
      # Create thread to time out daemon
      ping()
      Thread.new() {
        while ((diff = Time.now - @pingTime) < TIMEOUT)
          debug "Check for time out (#{diff}:#{TIMEOUT})"
          sleep TIMEOUT - diff + 2
        end
        info "#{@img} timed out"
        stop
      }
      
    end
    
    #
    # Return the time in seconds before this instance will timeout
    #
    def untilTimeout()
      return TIMEOUT - (Time.now - @pingTime)
    end
    
    def ping()
      @pingTime = Time.now
    end
    
    def done()
      info "#{@img} done"
      @running = false
      @@inst.delete(img)
    end
    
  end
end

if $0 == __FILE__
include Log4r

  MObject.initLog('frisbeeService')

  MObject.info("Frisbee Service Testharness")

  module GridService

    SERVER = HTTPServer.new(
      :Port => 5012,
      :Logger => Logger.new("#{MObject.logger.fullname}::web")
    )

    def GridService.mount(name, servlet)
      SERVER.mount(name, servlet)
    end

    def GridService.mount_proc(name, &block) 
      SERVER.mount_proc(name, &block)
    end
  end

  trap("INT") { GridService::SERVER.shutdown }
  GridService::SERVER.start

end

FrisbeeService::mount()
