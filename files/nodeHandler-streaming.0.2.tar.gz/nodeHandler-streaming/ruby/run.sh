ruby nodeHandler.rb  -s false test:exp:streaming-panasonic
