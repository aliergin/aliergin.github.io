#
# This class describes a parameter
#
class Parameter

  attr_reader :id, :name, :description, :defaultValue
  
  def initialize(id, name, description, defaultValue = nil)
    @id = id
    @name = name != nil ? name : id
    @description = description
    @defaultValue = defaultValue
  end
  
  #
  # Return the object definition as an XML element
  #
  def to_xml
    a = REXML::Element.new("parameter")
	a.add_attribute("id", id)
	a.add_attribute("name", name)
    if (description != nil) 
      a.add_element("description").text = description
    end
    if (defaultValue != nil)
      a.add_element("default").text = defaultValue
    end
    return a
  end
  
end

