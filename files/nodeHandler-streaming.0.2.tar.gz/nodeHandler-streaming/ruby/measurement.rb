#
# 
#
require "property.rb"
require "metric.rb"

#
# A measurement point used in an application definition
#
class Measurement

  
  include CreatePropertiesModule
  
  # ID for this measurement point
  attr_reader :id
  
  # Description of the measurement point
  attr_reader :description
  
  # List of global properties for filtering
  attr_reader :properties
  
  attr_reader :metrics
  
  attr_reader :filterMode
  
  # @param filterMode Type of OML filter - time or sample
  #
  def initialize(mDef, filterMode, properties = nil, metrics = nil)
    @mDef = mDef
    @id = mDef.id
    @filterMode = filterMode

    @properties = Array.new
    addProperties(properties)
    
    @metrics = Hash.new
    if metrics != nil  
      metrics.each {|e|
        if e.kind_of? Array 
          name = e.shift 
          addMetric(name, e)
        else
          raise "Metric definition '" + e + "' needs to be an array"
        end
      }
    end
  end
  
  def addMetric(refid, filter = nil)
    metricDef = @mDef.metrics[refid]
    if metricDef == nil
      raise "Unknown metric '#{refid}' for measurement point '#{@mDef.id}'"
    end
    m = Metric.new(refid, metricDef)
    if filter != nil
      if filter.kind_of? Filter
        m.addFilter(filter)
      elsif filter.kind_of? Array
        filter.each {|f|
          m.addFilter(f)
        }
      else
        raise "Filter needs to be of type Filter or an array, but is '" + filter + "'."
      end
    end
    metrics[refid] = m
    return m
  end
  
  #
  # Return the object definition as an XML element
  #
  def to_xml
    a = REXML::Element.new("measurement")
	a.add_attribute("name", id)
	
	if @properties.length > 0
      pe = a.add_element("properties")
      @properties.each {|p|
        pe.add_element(p.to_xml)
      }
    end
	
    metrics.each_value {|m|
      a.add_element(m.to_xml)
    }
    return a
  end
  
end

#
# This class provides write access to many of its properties
#
class MutableMeasurement < Measurement

  #
  # Add a metric.
  def addMetric(name, type, description = nil)
    if @metrics[name] != nil
      raise "Metric '" + name + "' already defined."
    end
    @metrics[name] = {"type" => type, "description" => description} 
  end

end
