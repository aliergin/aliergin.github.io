require 'webrick'
require 'stringio'
require 'date'
require 'external/mysql'
require 'util/mobject'

#
# This class represents an oml definition for a particular
# application configuration.
#
class OmlApp < MObject

  @@mpCnt = 0
  @@dbName = nil
#  @@dbHandle = nil
  @@initialized = false
  @@collectionServerStarted = false

  @@omlUrl = nil

  def OmlApp.setServiceURL(host, port)
    @@omlUrl = {:host => host, :port => port}
  end
  
  #
  # @returns The url for a client to pick up it's OML configuration.
  # @param application Applciation for which to create the configuration
  # @param name Unique name of application, used for creating DB tables
  #
  def OmlApp.create(application, name)

    if ! @@initialized
      @@initialized = true
      NodeHandlerServer.map("/omls", OMLServerServlet)      
      NodeHandlerServer.map("/omlc", OMLClientServlet)
      NodeHandler::OML_EL.add_element('database-name').text = OmlApp.getDbName
      @@mpointsEl = NodeHandler::OML_EL.add_element('measurement-points')
    end
  
    id = "oml_#{name}"
    #pel = NodeHandler::OML_EL.add_element('measurement-points', {'id' => id})
    pel = @@mpointsEl

    application.measurements.each {|m|
      tableName = "#{name}_#{m.id}"
      el = pel.add_element("measurement-point", 
              {'id' => (@@mpCnt += 1), 'name' => m.id, 'table' => tableName, 
              'type' => m.filterMode, 'client' => id})
      properties = m.properties
      if properties.length > 0
        pe = el.add_element("properties")
        properties.each {|p|
          pe.add_element(p.to_xml)
        }
      end
      sorted = m.metrics.sort {|a, b| a[1].seqNo <=> b[1].seqNo}
      sorted.each {|arr|
        metric = arr[1]
        el.add_element(metric.to_xml)
      }
    }



#     #sql = "CREATE DATABASE #{OmlApp.getDbName}\n"
#     sql = ""

#     application.measurements.each {|m|
#       tableName = "#{name}_#{m.id}"
#       el = pel.add_element("measurement-point", 
#               {'id' => (@@mpCnt += 1), 'name' => m.id, 'table' => tableName, 
#               'type' => m.filterMode, 'client' => id})
#       sql += "CREATE TABLE #{OmlApp.getDbName}.#{tableName} ("
#       sql += "node_id VARCHAR(32), "
#       sql += "sequence_no INTEGER NOT NULL, "
#       sql += "timestamp INTEGER NOT NULL, "
#       properties = m.properties
#       if properties.length > 0
#         pe = el.add_element("properties")
#         properties.each {|p|
#           pe.add_element(p.to_xml)
#         }
#       end
#       sorted = m.metrics.sort {|a, b| a[1].seqNo <=> b[1].seqNo}
#       spacer = ""
#       sorted.each {|arr|
#         metric = arr[1]
#         el.add_element(metric.to_xml)
#         sql += "#{spacer}#{metric.to_sql}"
#         spacer = ", "
#       }
#       sql += ");"
#     }
#     MObject.debug("OML::sql", sql)
#     OmlApp.getDB.query(sql) if sql != ""
#     sqlEl = NodeHandler::OML_EL.add_element('sql').text = sql
    
    return "#{NodeHandlerServer.url()}/omlc?id=#{id}"
  end

  def OmlApp.getDbName()
    if (@@dbName == nil)
      ts = DateTime.now.strftime("%F-%T")
      name = "#{Experiment.name}_#{ts}"
      @@dbName = name.split(%r{[-:/]}).join('_') # turn all non char into '_'
      #OmlApp.getDB.query("CREATE DATABASE #{@@dbName}")	
    end
    return @@dbName
  end 

#  def OmlApp.getDB()
#    if (@dbHandle == nil)
#      @@dbHandle = Mysql.connect('10.10.0.8', 'orbit', 'orbit')
#    end
#    return @@dbHandle
#  end

  #
  # Start the OML Collection Server
  #
  # FIX ME: What about if no application is using OML?
  #
  def OmlApp.startCollectionServer()
    if @@collectionServerStarted
      # already running
      return
    end

    @@collectionServerStarted = true
    
    ss = StringIO.new()
    ss.write("<?xml version='1.0'?>\n")
    ss.write("<experiment id=\"#{OmlApp.getDbName}\">\n")      
    
    # WARNING: This may not work for multiple measurment points
    el = NodeHandler::OML_EL.elements["measurement-points"]
    el.write(ss, 2)
    ss.write("\n")
              
    ss.write("</experiment>\n")      

    
p ss.string
    
    Net::HTTP.start(@@omlUrl[:host], @@omlUrl[:port]) {|http|
      http.post('/oml/start', ss.string) { |str|
p str
	doc = REXML::Document.new(str)
	mc = doc.root.elements['multicast-channel'].attributes
	
	attr = {'addr' => "#{mc['addr']}", 
	  'iface' => "#{mc['iface']}", 
	  'port' => "#{mc['port']}" }
p attr
	NodeHandler::OML_EL.add_element('multicast-channel', attr)
      }
    }

#     filename = "#{NodeHandlerServer.url()}/omls"
#     url = "http://idb1.grid.orbit-lab.org:5001/startCollectionServer?config_file=#{filename}"
#     response = Net::HTTP.get_response(URI.parse(url))
#     if (! response.kind_of? Net::HTTPSuccess)
#       raise "Can't start OML Collection Server : #{response.to_s}"
#     end

    @@collectionServerStarted = true
  end

  def OmlApp.stopCollectionServer
    if ! @@collectionServerStarted
      # not running
      return
    end
    Net::HTTP.start(@@omlUrl[:host], @@omlUrl[:port]) {|http|
      http.get("/oml/stop?id=#{OmlApp.getDbName}")
    }
#     filename = "#{NodeHandlerServer.url()}/omls"
#     url = "http://idb1.grid.orbit-lab.org:5001/stopCollectionServer?config_file=#{filename}"
#     response = Net::HTTP.get_response(URI.parse(url))
#     if (! response.kind_of? Net::HTTPSuccess)
#       raise "Can't stop OML Collection Server : #{response.to_s}"
#     end
  end
  
end

class OMLClientServlet < WEBrick::HTTPServlet::AbstractServlet
  def do_GET(req, res)
    q = req.query    
    id = q['id']
    if (id == nil)
      raise "Missing argument 'id'"
    end

    res['ContentType'] = "text/xml"
    ss = StringIO.new()
    ss.write("<?xml version='1.0'?>\n")
    ss.write("<experiment id=\"#{OmlApp.getDbName}\">\n")      
    
    el = NodeHandler::OML_EL.elements['multicast-channel']
    el.write(ss, 2)
    ss.write("\n")
    
#    p "measurement-points[@id=\"#{id}\"]"
    ss.write("<measurement-points>\n")
    NodeHandler::OML_EL.elements.each("//measurement-point[@client=\"#{id}\"]") { |el|
      el.write(ss, 2)
      ss.write("\n")
    }
    ss.write("</measurement-points>\n")
                  
    ss.write("</experiment>\n")      
    res.body = ss.string
  end
end
  
class OMLServerServlet < WEBrick::HTTPServlet::AbstractServlet
  def do_GET(req, res)

    res['ContentType'] = "text/xml"
    ss = StringIO.new()
    ss.write("<?xml version='1.0'?>\n")
    ss.write("<experiment id=\"#{OmlApp.getDbName}\">\n")      
    
    el = NodeHandler::OML_EL.elements['db']
    el.write(ss, 2)
    ss.write("\n")
    el = NodeHandler::OML_EL.elements['multicast-channel']
    el.write(ss, 2)
    ss.write("\n")
    
    # WARNING: This may not work for multiple measurment points
    el = NodeHandler::OML_EL.elements["measurement-points"]
    el.write(ss, 2)
    ss.write("\n")
              
    ss.write("</experiment>\n")      
    res.body = ss.string
  end
end


#CREATE TABLE `foo2`.`senderport` (
#  `node_id` CHAR(32) NOT NULL,
#  `sequence_no` INTEGER UNSIGNED NOT NULL,
#  `timestamp` INTEGER UNSIGNED NOT NULL,
#  `pkt_sequ_no_sample_mean` FLOAT NOT NULL,
#  `pkt_timestamp_sample_mean` FLOAT NOT NULL,
#  `pkt_size_sample_mean` FLOAT NOT NULL
#)

