
module HandlerCommands

  #
  # WHOAMI: Send the nodes actual name
  #
  # Args: agentVersion
  #
  def HandlerCommands.WHOAMI(handler, sender, senderId, argArray)
    MObject.debug("agentCmd::whoami", sender, ": ", sender, " senderId: ", senderId, ":" , senderId.class)
    agentVersion = getArg(argArray, "Agent version")
    image = getArgDefault(argArray, "UNKNOWN")
    sender.checkIn(senderId, agentVersion, image)
  end

  #
  # HEARTBEAT: Periodic heartbeat from an agent
  #
  # Args: sendSeq#
  #       recvSeq#
  #       timeStamp
  #
  def HandlerCommands.HEARTBEAT(handler, sender, senderId, argArray)
    sendSeqNo = getArg(argArray, "Number of packets sent").to_i
    recvSeqNo = getArg(argArray, "Number of packets received").to_i
    ts = getArg(argArray, "TimestampD")
    
    # check if we received all packets (may trigger a RETRY request)
    handler.inSequence?(sender, sendSeqNo)

    sender.heartbeat(sendSeqNo, recvSeqNo, ts)
  end

  #
  # APP_EVENT: Event reported by the agent
  #
  # Args: eventName
  #       appId
  #       message
  #
  def HandlerCommands.APP_EVENT(handler, sender, senderId, argArray)
    eventName = getArg(argArray, "Name of event")
    appId = getArg(argArray, "Application ID")
    message = getArgDefault(argArray, nil)
    MObject.debug("agentCmd::APP_EVENT", eventName, "' from '", appId, \
        "' executing on ", sender, ": '", message, "'")
    sender.onAppEvent(eventName, appId, message)
    return nil
  end
  
  #
  # RETRY: Resend a command to the nodes
  #
  # Args: messageId
  #
  def HandlerCommands.RETRY(handler, sender, senderId, argArray)
    firstId = getArg(argArray, "Number of first message to resend").to_i
    lastId = getArg(argArray, "Number of last message to resend").to_i    
    MObject.debug("agentCmd::RETRY", "Nessage ", firstId, "..", lastId)
    NodeHandler.resendCommand(Range.new(firstId, lastId))
  end
 


  #
  # ERROR: A agent is reporting an error
  #
  # Args: command Command which caused the error
  #       *args   Optional information
  #
  # Args for "CONFIGURE" errors
  #       'CONFIGURE'
  #       path  Id of resource to have been configured
  #       msg   Message describing error condition
  #
  def HandlerCommands.ERROR(handler, sender, senderId, argArray)
    command = getArg(argArray, "Command causing error")
    case command
      when 'CONFIGURE'
        path = getArg(argArray, "Name of resource")
        reason = "Couldn't configure '#{path}'"
        message = argArray.join(' ')
        id = handler.logError(sender, reason, {:details => message})
        sender.configureStatus(path, "error", {"logRef" => id})
        MObject.error("agentCmd::CONFIGURE_ERROR", "#{reason} on '#{sender}': #{message}")
      else
        reason = "Unknown error caused by '#{command}'"
        message = argArray.join(' ')
        handler.logError(sender, reason, {:details => message})        
        MObject.error("agentCmd::UNKNOWN_ERROR", "#{reason} on '#{sender}': #{message}")    
    end
  end
  
  
  
  
  # Remove the first element from 'argArray' and
  # return it. If it is nil, raise exception 
  # with 'exepString' providing MObject.information about the 
  # missing argument
  #
  # @return First element in 'argArray' or raise execprion if nil
  # @param argArray Array of arguments
  # @param exepString MObject.information about argument, used for expection
  # @raises Exception if arg is nil
  #
  def HandlerCommands.getArg(argArray, exepString)
    arg = argArray.delete_at(0)
    if (arg == nil)
      raise exepString
    end
    return arg
  end
    
  # Remove the first element from 'argArray' and
  # return it. If it is nil, return 'default'
  #
  # @return First element in 'argArray' or 'default' if nil
  # @param argArray Array of arguments
  # @param default Default value if arg in argArray is nil
  #
  def HandlerCommands.getArgDefault(argArray, default = nil)
    arg = argArray.delete_at(0)
    if (arg == nil)
      arg = default
    end
    return arg
  end


end
