
#
# Define a metric for a measurement point
# A metric can include a list of filters
#

class Metric

  # Mapping between OML data types and SQL types. 
  # Fix the duplication of xsd: and plain types.
  XSD2SQL = {
    "xsd:float" => "FLOAT NOT NULL",
    "xsd:int" => "INTEGER NOT NULL",
#    "xsd:long" => "LONG NOT NULL",
    "xsd:long" => "INTEGER NOT NULL",
    "xsd:short" => "INTEGER NOT NULL",
    "xsd:bool" => "DO NOT KNOW",
    "xsd:string" => "CHAR(32) NOT NULL",
    "float" => "FLOAT NOT NULL",
    "int" => "INTEGER NOT NULL",
#    "long" => "LONG NOT NULL",
    "long" => "INTEGER NOT NULL",
    "short" => "INTEGER NOT NULL",
    "bool" => "DO NOT KNOW",
    "string" => "CHAR(32) NOT NULL"
  }


  attr_reader :refid
  
  # Filters added to metric
  attr_reader :filters, :type, :seqNo
  
  def initialize(refid, metricDef)
    @refid = refid
    @type = metricDef['type']
    @seqNo = metricDef['seqNo']
  end
  
  def addFilter(filter, properties = nil)
    if !(filter.kind_of? Filter)
      raise "Needs to be a filter, but is a #{filter.class} (#{filter.inspect})"
    end
    if (properties != nil)
      filter = filter.clone(properties)
    end
    if @filters == nil
      @filters = Array.new
    end
    @filters += [filter]
  end
  
  #
  # Return the object definition as an XML element
  #
  def to_xml
    a = REXML::Element.new("metric")
	a.add_attribute("name", refid)
    a.add_attribute("id", refid) # for legacy reasons
    a.add_attribute("refid", refid) # for legacy reasons

    # for legacy reasons
    t = type
    if (t =~ /xsd:/) == 0
      t = t[4..-1]
    end
	a.add_attribute("type", t)
	#a.add_attribute("seqNo", @seqNo)	
	
	if filters != nil
	  filters.each {|f|
	    a.add_element(f.to_xml)
	  }
    end
    return a
  end
  
  # Return a string describing the columns needed in an OML database to capture
  # the metric described by this object. NOte, that a separate column is needed
  # for every filter.
  def to_sql
	if filters == nil
	  return "#{refid} #{XSD2SQL[type]}"
	else
	  sql = ""
	  spacer = ""
	  filters.each {|f|
	    sql += "#{spacer}#{refid}_#{f.idref} #{XSD2SQL[f.returnType]}"
	    spacer = ", "
	  }
	  return sql
    end
  end
  
end
