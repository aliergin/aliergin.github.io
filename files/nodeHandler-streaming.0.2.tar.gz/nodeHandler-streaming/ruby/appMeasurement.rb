#
# 
#

#
# A measurement point used in an application definition
#
class AppMeasurement


  FLOAT = Float
  
  @@conversion = {
    Float => "xsd:float",
    Integer => "xsd:int",
    'int' => "xsd:int",
    'long' => "xsd:long",
    :long => "xsd:long",    
    'short' => "xsd:short",
    :short => "xsd:short",    
    :boolean => "xsd:bool",
    :bool => "xsd:bool",
    String => "xsd:string"
  }


  #
  # Unmarshall an AppMeasurement instance from an XML tree.
  #
  # @param appDefRoot Root of measurment definition
  #
  def AppMeasurement.from_xml(defRoot)
    if (defRoot.name != "measurement")
      raise "Measurement definition needs to start with an 'measurement' element"
    end 
    id = defRoot.attributes['id']
    metrics = Array.new
    description = nil
    defRoot.elements.each { |el|
      case el.name
      when 'description' : description = el.text
      when 'metric' 
	name = type = description = nil
	el.attributes.each { |n, v|
	  case n
	  when 'id' : name = v
	  when 'type' : type = v
	  else
	    warn "Ignoring metric attribute '#{n}'"
	  end
	}
	description = el.elements['description']
	metrics << [name, type, description]
      else
	warn "Ignoring measurement element '#{el.name}'"
      end
    }
    m = AppMeasurement.new(id, description, metrics)
    return m
  end
  

#  def AppMeasurement.FLOAT()
#    return "float"
#  end

  # ID for this measurement point
  attr_reader :id
  
  # Description of the measurement point
  attr_reader :description
  
  attr_reader :metrics
  
  def initialize(id, description = nil, metrics = nil)
    @id = id
    @description = description
    @metrics = Hash.new
    if metrics != nil
      metrics.each {|e|
        if e.kind_of? Array 
          addMetric(e[0], e[1], e.length == 3 ? e[2] : nil)
        elsif e.kind_of? Hash
          addMetric(e["name"], e["type"], e["description"])
        else
          raise "Metric definition '" + e + "' needs to be either and array or a hash"
        end
      }
    end
  end
  
  #
  # Return the object definition as an XML element
  #
  def to_xml
    a = REXML::Element.new("measurement")
    a.add_attribute("id", id)
    a.add_element("description").text = description
    metrics.each {|id, v|
      m = REXML::Element.new("metric")
      m.add_attribute("id", id)
      m.add_attribute("type", v["type"])
      description = v["description"]
      if description != nil
        m.add_element("description").text = description
      end
      a.add_element(m)
    }
    return a
  end

  private 
  #
  # Add a metric.
  def addMetric(name, type, description = nil)
    if @metrics[name] != nil
      raise "Metric '" + name + "' already defined."
    end
    if (type =~ /xsd:/) != 0
      if (! @@conversion.key?(type))
	raise "Unknown type '#{type}' for metric '#{name}'."
      end
      type = @@conversion[type]
    end
    @metrics[name] = {"type" => type, "description" => description, 'seqNo' => @metrics.length} 
  end

end

#
# This class provides write access to many of its properties
#
class MutableAppMeasurement < AppMeasurement

  #
  # Add a metric.
  def addMetric(name, type, description = nil)
    super(name, type, description)
  end

end
