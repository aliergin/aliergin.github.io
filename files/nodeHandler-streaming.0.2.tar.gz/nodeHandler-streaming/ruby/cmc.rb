
module CMC

  @@cmcUrl = nil

  def CMC.setServiceURL(url)
    @@cmcUrl = url
  end

  #
  # Switch a node on
  #
  # @param x X coordinate of node
  # @param y Y coordinate of node
  #
  def CMC.nodeOn(x, y)
    if NodeHandler.JUST_PRINT
      puts "CMC: Switch on node #{x}@#{y}"
    else
#      url = "#{@@cmcUrl}?cmd=U&x=#{x}&y=#{y}"
      url = "#{@@cmcUrl}/on?x=#{x}&y=#{y}"      
      MObject.debug("CMC", "up ", url)
      response = Net::HTTP.get_response(URI.parse(url))
      if (! response.kind_of? Net::HTTPSuccess)
        raise "Can't switch on node #{x}:#{y} (#{response})"
      end
    end
  end
    
  #
  # Switch a node off
  #
  # @param x X coordinate of node
  # @param y Y coordinate of node
  #
  def CMC.nodeOff(x, y)
    if NodeHandler.JUST_PRINT
      puts "CMC: Switch of node #{x}@#{y}"
    else
#      url = "#{@@cmcUrl}?cmd=d&x=#{x}&y=#{y}"
      url = "#{@@cmcUrl}/off?x=#{x}&y=#{y}"      
      MObject.debug("CMC", "down ", url)      
      #MObject.debug "CMC.down #{url}"
      response = Net::HTTP.get_response(URI.parse(url))
      if (! response.kind_of? Net::HTTPSuccess)
        raise "Can't switch off node #{x}:#{y} (#{response})"
      end
    end
  end
  
  #
  # Switch all nodes off
  #
  def CMC.nodeAllOff()
      nodeOff('ALL', 'ALL')
  end
  
  
  #
  # Reset a node
  #
  # @param x X coordinate of node
  # @param y Y coordinate of node
  #
  def CMC.nodeReset(x, y)
    if NodeHandler.JUST_PRINT
      puts "CMC: Reset node #{x}@#{y} (#{response})"
    else
#      url = "#{@@cmcUrl}?cmd=R&x=#{x}&y=#{y}"
      url = "#{@@cmcUrl}/reset?x=#{x}&y=#{y}"      
      #MObject.debug "CMC.reset #{url}"
      response = Net::HTTP.get_response(URI.parse(url))
      if (! response.kind_of? Net::HTTPSuccess)
        raise "Can't reset node #{x}:#{y}"
      end
    end
  end

  
end

