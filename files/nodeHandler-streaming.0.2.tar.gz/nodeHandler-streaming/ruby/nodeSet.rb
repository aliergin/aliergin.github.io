require 'set'
require 'util/mobject'
require 'prototype'
require 'node'
require 'experiment'
require 'observer'

#
# This abstract class represents a set of nodes on which
# various operations can be performed in parallel
#
class NodeSet < MObject
  include Observable
  
  PXE_SERVICE = 'http://pxe:5012/pxe'
  
  def NodeSet.[](groupName)
    return @@groups[groupName]
  end
  
  def NodeSet.ROOT
    return NodeSet['_ALL_']
  end
  
  # Counter of anonymous groups
  @@groupCnt = 0
  
  # keep track of all the groups
  @@groups = Hash.new

  
  attr_reader :groupName
  
  #
  #
  # The additional 'groupName' parameter will associate a 
  # group name with this node set. All the nodes defined
  # by the selector can from then on be addressed by
  # the selector "/groupName/*". 
  #
  # @param groupName Optional name for specific node sets
  #
  def initialize(groupName = nil)
    @applications = Hash.new
    @deferred = [] # s any messages if nodes aren't up yet
    @onUpBlock = nil # Block to execute for every node checking in

    @groupName = groupName != nil ? groupName.to_s : nil
    if @groupName == nil
      @groupName = "_#{@@groupCnt += 1}"
    else
      if @groupName[0] == '/'[0]
        @groupName = @groupName[1..-1]
      end
    end
    super("set::#{@groupName}") # set debug name

    if (groupName == "_ALL_")
      @nodeSelector = "/*/*"    
    else
      @nodeSelector = "/#{@groupName}/*"
      eachNode { |n|
        n.addAlias(@groupName)
      }
      add_observer(NodeSet.ROOT)
    end
    @@groups[@groupName] = self
    
    eachNode { |n|
      n.add_observer(self)
    }
  end
  
  def +(nodeSelector)
    # Don't know how to call the "+" operator from inside
    add(nodeSelector)
  end
  
  def add(selector)
    if @nodeSelector != nil
      raise "Adding nodes hasn't been implemented, yet"
    end
    if selector.kind_of?(String)
      @nodeSelector = selector
      Node.match(selector).each { |n|
        @nodes.add(n)
      }
    elsif selector.kind_of?(Array)
      # now lets check if the array just describes a single 
      # node [x, y] a set of nodes [[a, b], [[c..d], f]]
      if selector.length == 2 && selector[0].kind_of?(Integer) && selector[1].kind_of?(Integer)
        n = addNode(selector[0], selector[1])
      else
        addNodes(selector)
      end  
    elsif selector.kind_of?(ExperimentProperty)
      s = selector.value
      add(s)
    else
       raise "Unrecognized node set selector type '#{selector.class}'."        
    end
  end

  # Add node at coordinates x and y
  #
  # @param x X coordinate of added node
  # @param y Y coordinate of added node
  def addNode(x, y)
    n = Node.at!(x, y)
    #debug "AddNode #{n}"
    @nodes.add(n)
  end
    
  def addNodes(nodes)
    #debug("addNodes: #{nodes}")
    if ! nodes.kind_of?(Array) 
      raise "Parameter to 'addNodes' need to be of type Array, but is #{nodes.class.to_s}."
    end
    if ! nodes[0].kind_of?(Array)
      # Array should contain two ranges
      if nodes.length != 2
        raise "Expected array with 2 elements denoting x and y, but found #{n.join(', ')}."
      end
      x = nodes[0]
      if x.kind_of?(Integer) 
        x = [x]
      end
      y = nodes[1]
      if y.kind_of?(Integer) 
        y = [y]
      end
      if ! ((x.kind_of?(Range) || x.kind_of?(Array)) \
              && (y.kind_of?(Array) || y.kind_of?(Range)))
        raise "Expected two range declarations, but found #{nodes.join(', ')}."
      end
      x.each {|i|
        y.each {|j|
          addNode(i, j)
        }
      }
    else 
      nodes.each {|n|
        addNodes(n)
      }
    end
  end
  
  #
  # Add an application which is associated with this node set
  # These applications will be started when {@link #startApplications}
  # is called
  #
  # @param app Application to register
  # @param vName Virtual name used for this app (used for state name)
  # @param bindings Bindings for local parameters
  # @param env Envioronment to set before starting application
  # @param install Request installation immediately
  #
  def addApplication(app, vName, bindings, env, install = true)
  
    vName = vName.to_s	
    @applications[vName] = {
      :app => app, 
      :bindings => bindings,
      :env => env
    }
    
    if install
      # Immediately request installation
      appDef = app.appDefinition
      if (aptName = appDef.aptName) != nil
        send(:APT_INSTALL, "app:#{vName}/install", aptName)
      elsif (rep = appDef.binaryRepository) != nil
        # Assume apps are in tar file
        send(:PM_INSTALL, "app:#{vName}/install", rep, '/')
      end
    end
  end
  
  #
  # Start the application with ID 'name'
  # This application has to have been added ({@link #addApplication})
  # before.
  #
  # This method will create the command by querying the applciation's
  # definition class and obtain parameters from either the fixed settings
  # or the current value of experiment variables.
  #
  # @param name Virtual name of application
  #
  def startApplication(name)
    debug("Starting application '", name, "'")
    ctxt = @applications[name]
    if (ctxt == nil) 
      raise "Unknown application '#{name}' (#{@applications.keys.join(', ')})"
    end
    
    OmlApp.startCollectionServer
    
    app = ctxt[:app]
    bindings = ctxt[:bindings]
    env = ctxt[:env]
    appDef = app.appDefinition
    procName = "app:#{name}"
    cmd = [procName, 'env', '-i']
    env.each {|name, value|
      cmd << "#{name}=#{value}"
    }

    cmd << appDef.path
    pdef = appDef.properties
    # check if bindings contain unknown parameters
    if (diff = bindings.keys - pdef.keys) != []
      raise "Unknown parameters '#{diff.join(', ')}'" \
        + " not in '#{pdef.keys.join(', ')}'."
    end
    bindings.each {|name, value|
      p = pdef[name]
      if value.kind_of?(ExperimentProperty)
        value.onChange { |v| 
          # FIX ME: This should actually come form the application def object
          # as only it knows how to do this.
          send(:STDIN, procName, p.name, v)
        }
        if (value = value.value) == nil
          next
        end
      end
      if p.mnemonic != nil
        cmd << "-#{p.mnemonic.chr}"
      else
        cmd << "--#{p.name}"
      end
      cmd << value
    }
    send(:exec, *cmd)
  end
  
  def startApplications()
    debug("Start all applications")  
    @applications.each_key { |name|
      startApplication(name)
    }
  end

  #
  # Stop the application with ID 'name'
  # This application has to have been added ({@link #addApplication})
  # before.
  #
  # @param name Virtual name of application
  #
  def stopApplication(name)
    debug("Stoppping application '", name, "'")
    ctxt = @applications[name]
    if (ctxt == nil) 
      raise "Unknown application '#{name}' (#{@applications.keys.join(', ')})"
    end
    
    procName = "app:#{name}"
    send(:STDIN, procName, 'exit')
  end
  
  def stopApplications()
    debug("Stop all applications")  
    @applications.each_key { |name|
      stopApplication(name)
    }
  end
  
  # Return true if all nodes in this set are
  # up
  #
  # @return True if all nodes in set are up
  #
  def up?
    return inject(true) { |flag, n|
      #debug "Checking if #{n} is up"
      if flag
        if ! n.isUp
          debug n, " is not up yet."
          flag = false
        end
      end
      flag
    }
  end

  
  
  #
  # Set resource 'path' on all nodesin this
  # set to 'value'
  #
  # @param path Path to resource
  # @paran value New value
  #
  def configure(path, value)

    if value.kind_of?(ExperimentProperty)
      value.onChange { |v| 
        configure(path, v)
      }
      value = value.value
    end
  
    eachNode {|n|
      n.configure(path, value)
    }
    send(:CONFIGURE, path.join('/'), value.to_s)
  end

  # def modprobe(name, *args = nil)
  #   send(:MODPROBE, name, args)
  # end

  #
  # Execute block for every node in this set
  # when it comes up
  #
  # Note, we currently only support one block.
  #
  def onNodeUp(&block)
    @onUpBlock = block
  end
  
  
  #
  # If the provided image is non-nil, then the nodes in this set
  # will be configured to boot the provided image name over the 
  # network. If 'image' is set to 'nil' than the node boots from
  # local disk. The optional 'imageName' allows a node to verify
  # at the time the node checks in, if it really booted into the right
  # image. The image name is stored in /.orbit_image
  #
  # @param image Network image to boot
  # @param imageName name of image to check for
  #
  def pxeImage(image, imageName = nil)
    op = nil
    if (image == nil)
      # clear PXE
      op = 'clear'
#      prefix = "#{PXE_SERVICE}/clearBootImage?ip="
      prefix = "#{PXE_SERVICE}/clearBootImage?node="
    else
      # set PXE
      op = 'set'
#      prefix = "#{PXE_SERVICE}/setBootImage?img=#{image}&ip="
      prefix = "#{PXE_SERVICE}/setBootImage?img=#{image}&node="
    end
    if NodeHandler.JUST_PRINT
      if (image == nil)
        puts "PXE: Boot from local disk"
      else
    	puts "PXE: Boot into network image #{image} for node set #{self}"
      end
    else
      eachNode { |n|
#        url = "#{prefix}#{n.getControlIP}"
        url = "#{prefix}#{n.getNodeName}"
        debug "PXE: #{url}"
        response = Net::HTTP.get_response(URI.parse(url))
        if (! response.kind_of? Net::HTTPSuccess)
          raise "Can't #{op} PXE image #{response.to_s}"
        end
        n.image = imageName
      }
    end
  end
  
  #
  # Name of image to expect on all nodes in this set
  #
  def image=(imageName)
    eachNode { |n|
      n.image = imageName
    }
  end
  
  
  #
  # Send a command to all node agents
  #
  # @param command Command 
  # @param args Array of parameters
  #
  def send(command, *args)
    debug("#send: args(#{args.length})'#{args.join('#')}")
    if (up?)
      NodeHandler.sendCommand(@nodeSelector, command, args)
    else
      debug "Deferred message: #{command} #{@nodeSelector} #{args.join(' ')}"
      @deferred << [command, args]
    end
  end
    
  #
  # Called by observable node 'sender' reporting 
  # change identified by 'code'
  #
  def update(sender, code)
    #debug "nodeSet (#{to_s}) update: #{sender} #{code}"
    if (code == :node_is_up)
      if (up?)
        update(self, :group_is_up)
        changed
        notify_observers(self, :group_is_up)
      end
      if @onUpBlock != nil
        begin 
          @onUpBlock.call(sender)
        rescue Exception => err
          error("onUpBlock threw exception for #{sender}: #{err}")
        end
      end
    elsif (code == :group_is_up)
      send_deferred
    end
  end
  
  #
  # Send all deferred messages if there are any
  # and all the nodes are up
  #
  def send_deferred()
    if (@deferred.size > 0 && up?)
      da = @deferred
      @deferred = []
      da.each { |e|
        command = e[0]
        args = e[1]
        #debug "send_deferred(#{args.class}:#{args.length}):#{args.join('#')}"
        send(command, *args)
      }
    end
  end
  
  def to_s
    @nodeSelector
  end
end

#
# This class represents a set of individual nodes. 
#
class BasicNodeSet < NodeSet

  #
  # Create a new node set where the selector is an
  # array of x/y coordinates. 
  #
  # If the specified nodes do not exist, they will
  # be created.
  #
  # The additional 'groupName' parameter will associate a 
  # group name with this node set. All the nodes defined
  # by the selector can from then on be addressed by
  # the selector "/groupName/*". 
  #
  # @param groupName Optional name for specific node sets
  # @param selector Identifiying the nodes in this set
  #
  def initialize(groupName, selector)
  
    if (selector == nil)
      raise "Need to specifiy array of nodes"
    end
    
    @nodes = Set.new
    add(selector)
    
    super(groupName)

  end
  
  #
  # Add an application which is associated with this node set
  # These applications will be started when {@link #startApplications}
  # is called
  #
  # @see NodeSet::addApplication
  #
  def addApplication(app, vName, bindings, env, install = true)
    super(app, vName, bindings, env, install)
    self.eachNode { |n|
      n.addApplication(app, vName, bindings, env)
    }
  end
  
  # Execute block for every node in this node set
  #
  def eachNode(&block)
    @nodes.each(&block)
  end
  
  # Call inject over the nodes contained in this set.
  #
  def inject(seed = nil, &block)
    @nodes.inject(seed, &block)
  end
  
  private
  
  def add(selector)
#    if @nodeSelector != nil
#      raise "Adding nodes hasn't been implemented, yet"
#    end
    if selector.kind_of?(Array)
      # now lets check if the array just describes a single 
      # node [x, y] a set of nodes [[a, b], [c..d, f]]
      if selector.length == 2 && selector[0].kind_of?(Integer) && selector[1].kind_of?(Integer)
        n = addNode(selector[0], selector[1])
      else
        addNodes(selector)
      end  
    elsif selector.kind_of?(ExperimentProperty)
      s = selector.value
      add(s)
    else
       raise "Unrecognized node set selector type '#{selector.class}'."        
    end
  end

  # Add node at coordinates x and y
  #
  # @param x X coordinate of added node
  # @param y Y coordinate of added node
  def addNode(x, y)
    n = Node.at!(x, y)
    #debug "AddNode #{n}"
    @nodes.add(n)
  end
    
  def addNodes(nodes)
    #debug("addNodes: #{nodes}")
    if ! nodes.kind_of?(Array) 
      raise "Parameter to 'addNodes' need to be of type Array, but is #{nodes.class.to_s}."
    end
    if ! nodes[0].kind_of?(Array)
      # Array should contain two ranges
      if nodes.length != 2
        raise "Expected array with 2 elements denoting x and y, but found #{n.join(', ')}."
      end
      x = nodes[0]
      if x.kind_of?(Integer) 
        x = [x]
      end
      y = nodes[1]
      if y.kind_of?(Integer) 
        y = [y]
      end
      if ! ((x.kind_of?(Range) || x.kind_of?(Array)) \
              && (y.kind_of?(Array) || y.kind_of?(Range)))
        raise "Expected two range declarations, but found #{nodes.join(', ')}."
      end
      x.each {|i|
        y.each {|j|
          addNode(i, j)
        }
      }
    else 
      nodes.each {|n|
        addNodes(n)
      }
    end
  end

end

#
# This class implemants behavior for sets containing other node sets.
#
class AbstractGroupNodeSet < NodeSet

#  def startApplication(name)
#    super(name)
#    eachGroup { |g|
#      g.startApplication(name)
#    }
#  end

  def startApplications
    debug("Start all applications")  
    super
    eachGroup { |g|
      debug("..... Start applications in #{g}")
      g.startApplications
    }
  end

  def stopApplications
    debug("Stop all applications")  
    super
    eachGroup { |g|
      debug(".... Stop applications in #{g}")
      g.stopApplications
    }
  end

end

#
# This class represents a set containing other node sets.
#
class GroupNodeSet < AbstractGroupNodeSet

  #
  # Create a new node set where the selector is an
  # array of names of existing node sets.
  #
  # The additional 'groupName' parameter will associate a 
  # group name with this node set. All the nodes defined
  # by the selector can from then on be addressed by
  # the selector "/groupName/*". 
  #
  # @param groupName Optional name for specific node sets
  # @param selector Identifiying the nodes in this set
  #
  def initialize(groupName, selector)
  
    if (selector == nil)
      raise "Need to specifiy array of nodes"
    end
    
    @nodeSets = Set.new
    add(selector)
    
    super(groupName)
  end
  
  # Execute block for every group in this node set
  #
  def eachGroup(&block)
    debug("Running 'eachGroup' in GroupNodeSet")
    @nodeSets.each { |g|
       block.call(g)
    }
  end
  
  #
  # Add an application which is associated with this node set
  # These applications will be started when {@link #startApplications}
  # is called
  #
  # @see NodeSet::addApplication
  #
  def addApplication(app, vName, bindings, env, install = true)
    super(app, vName, bindings, env, install)
    eachGroup { |g|
      # inform all enclosed groups, but do not request another install
      g.addApplication(app, vName, bindings, env, false) 
    }
  end
  
  # Execute block for every node in this node set
  #
  def eachNode(&block)
    @nodeSets.each { |s|
      s.eachNode &block
    }
  end
  
  # Call inject over the nodes contained in this set.
  #
  def inject(seed = nil, &block)
    result = seed
    @nodeSets.each { |s|
      result = s.inject(result, &block)
    }
    return result
  end
  
  
  private
  
  def add(selector)
    if selector.kind_of?(Array)
      # now lets check if the array just describes a single 
      # node [x, y] a set of nodes [[a, b], [c..d, f]]
      selector.each { |name| 
        s = NodeSet[name]
        if s == nil
          raise "Unknown set name '#{name}'"
        end
        s.add_observer(self)
        @nodeSets.add(s)
      }
    elsif selector.kind_of?(ExperimentProperty)
      s = selector.value
      add(s)
    else
       raise "Unrecognized node set selector type '#{selector.class}'."        
    end
  end
end

#
# This singleton class represents ALL nodes
#
class RootGroupNodeSet < AbstractGroupNodeSet

  #
  # Create a new node set where the selector is an
  # array of names of existing node sets.
  #
  # The additional 'groupName' parameter will associate a 
  # group name with this node set. All the nodes defined
  # by the selector can from then on be addressed by
  # the selector "/groupName/*". 
  #
  # @param groupName Optional name for specific node sets
  # @param selector Identifiying the nodes in this set
  #
  def initialize()
    super('_ALL_')
    @nodeSelector = "/*/*"
  end
  
  # Execute block for every group in this node set
  #
  def eachGroup(&block)
    debug("Running 'eachGroup' in RootGroupNodeSet")
    @@groups.each_value { |g|
      if g.kind_of?(BasicNodeSet)
        debug("Call #{g}")
        block.call(g)
      end
    }
  end
  
  # Execute block for every node in this node set
  #
  def eachNode(&block)
#    debug("Running 'each' in RootGroupNodeSet")
    @@groups.each_value { |g|
      if g.kind_of?(BasicNodeSet)
        debug("Running each for #{g}")
        g.eachNode &block
      end
    }
  end
  
  # Call inject over the nodes contained in this set.
  #
  def inject(seed = nil, &block)
    result = seed
    @@groups.each_value { |g|
#      debug "#inject: Checking #{g}:#{g.class} (#{result})"
      if g.kind_of?(BasicNodeSet)
#        debug "#inject: Calling inject on #{g} (#{result})"
        result = g.inject(result, &block)
      end
#      debug "#inject: result: #{result}"      
    }
    return result
  end
  
end

#####################################

class NodeSetPath < MObject
  attr_reader :nodeSet, :path
  
  VALID_PATHS = {
    "net" => //,
    "mode=" => %r{net/[ew][01]}, 
    "type=" => %r{net/[ew][01]}, 
    "rts=" => %r{net/[ew][01]},	
    "rate=" => %r{net/[ew][01]},	
    "essid=" => %r{net/[ew][01]},
    "ip=" => %r{net/[ew][01]},
    "channel=" => %r{net/[ew][01]},
    "down=" => %r{net/[ew][01]},
    "unload=" => %r{net/[ew][01]},
    "load=" => %r{net/[ew][01]},
    "bash=" => %r{net/[ew][01]},

#    "mod" => //
#    "=" => %r{net/[ew][01]},
  }
  
  VALID_PATHS_RE = {
    /[ew][01]/ => /net/
  }

  
  def initialize(obj, newLeaf = nil, value = nil, block = nil)
    if obj.kind_of? NodeSetPath
      @nodeSet = obj.nodeSet
      @path = obj.path.clone
    elsif obj.kind_of? NodeSet
      @nodeSet = obj
      @path = Array.new
    else
      raise "Argument needs to be either a NodeSet, or a NodeSetPath, but is #{obj.class.to_s}"
    end
    
    if value != nil
      if newLeaf == nil || newLeaf[-1] != ?=
        raise "Missing assignment operator for path '#{pathString}'."
      end
      newLeaf = newLeaf[0 .. -2]
      @value = value
    end
    if newLeaf != nil
      @path += [newLeaf]
    end
    
    @pathSubString = @path.join('/')
    super(@pathSubString == "" ? "nodeSetPath" : "nodeSetPath::#{@pathSubString}")
    #debug("Create nodeSetPath '", pathString, "' obj: #{obj.class}")
    
    if block != nil
      case block.arity
        when -1, 0
          block.call()
        when 1
          block.call(self)
        else
          raise "Block (#{block.arity}) for '" + pathString + "' requires zero, or one argument (|n|)"
      end
    end
    if @value != nil
      @nodeSet.configure(@path, @value)
    end
  end

  
#  def each(&block)
#    @nodeSet.each(&block)
#  end

  def pathString()
    @nodeSet.to_s + '/' + @pathSubString
  end
  
  def method_missing(name, *args, &block)
    # puts "path(" + pathString + ") " + name.to_s + " @ " + args.to_s + " @ " + (block != nil ? block : nil).to_s
    if args.length > 1
      raise "Assignment to '" + pathString + "/" + name.to_s + "' can only be a single parameter."
    end
    name_s = name.to_s
    re = VALID_PATHS[name_s]
    debug("Testing '#{name}' => '#{@pathSubString}' : #{re}")
    if (re != nil)
      debug("Checking against '#{re}'")
      if (@pathSubString =~ re) != 0
        warn("Unrecognized path '#{@pathSubString}/#{name}'")
      end
    else
      found = false
      VALID_PATHS_RE.each { |nameRe, pattern|
        if (name_s =~ nameRe) == 0
          found = true
          if (@pathSubString =~ pattern) != 0
            warn("Unrecognized path '#{@pathSubString}/#{name}'")
          end
        end
      }
      if ! found
        warn("Unrecognized path '#{@pathSubString}/#{name}'")      
      end
    end      

    #debug("Creating new nodeSetPath '#{name}'")
    return NodeSetPath.new(self, name_s, args[0], block)
  end

end

#
# The root path has additional methods specific to configuring the node itself
#
class RootNodeSetPath < NodeSetPath

  def prototype(name, params = nil)
    debug "Use prototype #{name}."
    p = Prototype[name]
    p.instantiate(@nodeSet, params)
  end

# Avoid this as it will cause all kind of problems. For instance, what happens when the group name
# is changed while nodes are already checked in. 
#  def groupName=(value)
#    @nodeSet.groupName = value
#  end
  
  #
  # If the provided image is non-nil, then the nodes in this set
  # will be configured to boot the provided image name over the 
  # network. If 'image' is set to 'nil' than the node boots from
  # local disk. The optional 'imageName' allows a node to verify
  # at the time the node checks in, if it really booted into the right
  # image. The image name is stored in /.orbit_image
  #
  # @param image Network image to boot
  # @param imageName name of image to check for
  #
  def pxeImage(image, imageName = nil)
    @nodeSet.pxeImage(image, imageName)
  end
    
  #
  # Set the image to boot on node. If image
  # is set to 'nil' than the node boots from
  # local disk.
  #
  # @param image Image to boot
  #
  def image=(image)
    @nodeSet.image = image
  end
  
  #
  # Execute block for every node in this set
  # when it comes up
  #
  def onNodeUp(&block)
    @nodeSet.onNodeUp &block
  end
  
  #
  # Start all registered applications
  #
  def startApplications()
    debug("Start all applications")
    @nodeSet.startApplications
  end

  #
  # Start all registered applications
  #
  def startApplication(name)
    @nodeSet.startApplication(name)
  end

  #
  # Stop all registered applications
  #
  def stopApplications()
    debug("Stop all applications")
    @nodeSet.stopApplications
  end

  #
  # Stop all registered applications
  #
  def stopApplication(name)
    @nodeSet.stopApplication(name)
  end
  
  # def modprobe(name, *args = nil)
  #   @nodeSet.modprobe(name, *args)
  # end
end

# Create _ALL_ group
RootGroupNodeSet.new()

if $0 == __FILE__
  MObject.initLog 'test'
#  n = NodeSet.new([1, 2..3])
#  n = NodeSet.new([1..2, 2..3])
#  n = NodeSet.new([[1..2, 2..3], [6..8, 5]])  
  n = NodeSet.new([[2, 1..3], [3, [1, 3]]])
end

