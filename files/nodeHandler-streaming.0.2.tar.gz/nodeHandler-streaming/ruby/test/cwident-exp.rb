#
# This is Haris's CWIDENT experiment
#


node([2, 4], :sender) { |n|
  n.prototype("http://apps.orbit-lab.org/sender", {
    :if => Node::W0_IF,
    :packetSize => Experiment.parameter(:senderPacketSize, "sender/packetSize"),
    :rate => Experiment.parameter(:senderRate, "sender/rate")
  })
}
node([3, 2], :receiver) { |n|
  n.prototype("http://apps.orbit-lab.org/receiver", {
    :if => Node::W0_IF
  })
}
node([[2, 1..3], [3, [1, 3]]], :interferer) {|n|
  n.prototype("http://apps.orbit-lab.org/sender", {
    :if => Node::W0_IF,
    :packetSize => Experiment.parameter(:infPacketSize, "interferer/packetSize"),
    :rate => Experiment.parameter(:infRate, "interferer/rate")
  })
}
node([3, 4], :sniffer) { |n|
  n.prototype("http://apps.orbit-lab.org/receiver", {
    :if => Node::W0_IF
  })
}

#
# Configure environment
#
node("/*/*").net.w0 { |n|
  n.up = true
  n.mode = Node::W_ADHOC
  n.channel = 1
  # Set the IP address. %x will be replaced by the x-coordinate and
  # %y by the y-coordinate of the node
  n.ip = "%10.0.%x.%y"
}

node("/sender/*").net.w0 {|n|
  n.essid = "BRUCE"
}

node("/receiver/*").net.w0 {|n|
  n.essid = "BRUCE"
}

node("/interferer/*").net.w0 {|n|
  n.essid = "ESTREET"
}

node("/receiver/*").net.w0 {|n|
  n.essid = "ESTREET"
}

#
# Now, start the application
#
startApplications {|p|
  p.senderPacketSize = 256
  p.infPacketSize = 256
}
#
# Now run the experiment
#
whenReady {|e, p|

  rateIncrease = {256 => 100, 512 => 50, 768 => 33, 1024 => 25, 1280 => 20}
  while (p.infPacketSize < 1500) do
    incr = rateIncrease[p.infPacketSize]
    p.infRate = 0
    7.times do
      Experiment.sleep 5.0
      p.infRate += incr
    end
    p.infPacketSize += 256
  end
  e.done
}

