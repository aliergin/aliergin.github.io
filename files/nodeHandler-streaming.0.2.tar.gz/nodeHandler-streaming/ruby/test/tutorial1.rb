
Experiment.name = "tutorial-1"
Experiment.project = "Orbit::Tutorial"

Experiment.startMode = Experiment::REBOOT

#
# Define nodes used in experiment
#
node([1, 2], 'sender') {|n|
  # use prototype "sender" 
  # and set it's parameter "if" to "eth2"
  # and bind the remaining parameters to the 
  # experiment parameter space
  n.prototype("http://apps.orbit-lab.org/sender", {
    'if' => Node::W0_IF,
    'packetSize' => Experiment.parameter("packetSize"),
    'rate' => Experiment.parameter("rate")
  })
}
#node([3, 4]) {|n|
#  n.prototype("http://apps.orbit-lab.org/receiver", {:if => Node::W0_IF})
#}

#NodeHandler::DOCUMENT.write($stdout, 2)
#Node.match('/*/*')

#
# Configure environment
#
node("/*/*").net.w0 {|n|
#  n.essid = "HelloWorld"
#  n.mode = "master"
#  n.channel = 1
#  n.xmitPower = 1 ;# What is 1?
#  n.bitrate = "11Mbps" # Force single rate

  # Set the IP address. %x will be replaced by the x-coordinate and
  # %y by the y-coordinate of the node
  n.ip = "%192.168.%x.%y"
}


#
# Now, start the application
#
whenReady('/*/*') {|e, p, n|
  p.packetSize = 1024
  p.rate = 250
}

#
# All applications are running now.
# Simply let them run for 5 seconds
# and we are done
#
whenGridReady {|e, p|
  s = 256
  while s <= 1280 do
    p.generators.packetSize = s
    e.sleep 2
    s += 256
  end

  e.sleep 5.0
  e.done
}
