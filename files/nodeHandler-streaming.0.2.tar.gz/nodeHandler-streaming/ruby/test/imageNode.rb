
Experiment.name = "imageNode"
Experiment.project = "Orbit::Admin"

Experiment.defParameter('nodes', [1..8, 1..8], "Range of nodes to image")

#
# Define nodes used in experiment
#
node(Experiment.parameter('nodes')) {|n|
  n.image = 'orbit-1.0.0'
  n.onNodeUp {|n|
    n.loadImage!('baseline.ndz')
  }
}


