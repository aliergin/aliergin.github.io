#
# Define a prototype
#

require "prototype.rb"
require "filter.rb"
require 'nodeSet'

require "test/gennySenderAppDef"

p = Prototype.create("http://apps.orbit-lab.org/sender")
p.name = "Sender"
p.description = "Nodes which send a stream of packets"
p.addParameter('if', "Name of interface to use", Node::W0_IF)
p.addParameter('packetSize', "Payload length of outgoing packets", 1000)
p.addParameter('rate', "Rate to send", 1000)
p.addParameter('channel', "Channel to send on", 1)
p.addParameter('useSocket', "If true use socket, otherwise use libmac for transport", true)

genny = p.addApplication(:gennySender, "http://apps.orbit-lab.org/gennySender#gennySender")
genny.bindProperty('interface_name', 'if')
genny.bindProperty('rate')
genny.bindProperty('payload_length', 'packetSize')
genny.bindProperty('use_socket', 'useSocket')

genny.addMeasurement(:group3,  Filter::SAMPLE, 
  {Filter::SAMPLE_SIZE => 100},
  [
    ["offered_load", Filter::MEAN]
  ]
)

if $0 == __FILE__
  p.to_xml.write($stdout, 2)
  puts
end

