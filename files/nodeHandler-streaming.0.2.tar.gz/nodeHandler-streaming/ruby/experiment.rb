require 'util/mobject'
require 'optparse'


#
# This class is the entry point for all experiments. It is 
# is primarily used as a singleton
#
class Experiment

  REBOOT = "reboot"
  
  @@name = "UNKNOWN"  # name of experiment

  @@expRoot = nil
  @@expPropsOverride = Hash.new  # from command line options
  @@expID = nil
  
  
  def Experiment.ID
    if (@@expID == nil)
      @@expID = DateTime.now.strftime("%F-%T").split(':').join('-')
    end
    return @@expID
  end
    
  def Experiment.load(uri)
    MObject.info("Experiment", "load ", uri)

    if (@@expRoot == nil)
      @@expRoot = NodeHandler::EXPERIMENT_EL
      expProps = @@expRoot.add_element('properties')
      ExperimentProperty.propertyRootEl = expProps
      Experiment.setConfigEl('status', "CONFIGURING")
    end
    
    obj, type = OConfig.load(uri, true)
    if type == "text/xml"
      # whatever.from_xml(obj.to_xml???)
    elsif type == "text/ruby"
      # already loaded by OConfig.load
    else
      raise IOError, "Unknown experiment source '#{uri}'."
    end
  end
  
  #
  # Set the array of command line arguments to 
  # overide experiment variable defaults
  #
  def Experiment.expArgs=(args)
    MObject.debug "Experiment", "command line args: #{args}."  
    while (a = args.shift) != nil
      if (a =~ /^--/) != 0
        warn("Skipping invalid option '", a ,"'.")
      else
        if (value = args.shift) == nil
          warn("Command line property '#{a}' doesn't have a value")
          exit -1
        else  
          if value[0] == ?[
            value = eval(value)
          end
          @@expPropsOverride[a[2..-1]] = value
        end  
      end
    end
  end
  
  def Experiment.name=(name)
    @@name = name
    Experiment.setConfigEl('name', name)
  end 
  
  def Experiment.name ()
    @@name
  end 
  
  def Experiment.project=(name)
    @@projectName = name
    Experiment.setConfigEl('project', name)
  end
  
  def Experiment.startMode=(mode)
    @@startMode = mode
    Experiment.setConfigEl('startMode', mode)
  end 
   
  def Experiment.defProperty(name, defaultValue, description)
    if (override = @@expPropsOverride[name]) != nil
      MObject.debug('Experiment', 'Setting property "', name, '" to "', override.inspect, '".')
      defaultValue = override
    end
    ExperimentProperty.create(name, defaultValue, description)
  end
   
  
  # Return a binding to an experiment-wide property
  def Experiment.property(paramName, altName = nil)
    return PropertyContext[paramName]
  end
  
  #
  # Return the context for setting experiment wide properties
  #
  def Experiment.props
    return PropertyContext
  end
  
  #
  # Start all known applications
  #
  def Experiment.startApplications
  end
  
  
  #
  # 
  
  #
  # Observe experiment for x milliseconds
  #
  def Experiment.sleep(time)
    Experiment.setConfigEl('status', "SLEEPING")
    ::Kernel.sleep time
    Experiment.getConfigEl('status', "RUNNING")    
  end
  
  #
  # Start the experiment
  #
  def Experiment.start()
    if NodeHandler.JUST_PRINT
      Node.each { |n| n.checkIn(n.id, '1.0', '1.0', 'UNKNOWN') }    
    else
      Node.each { |n| n.powerOn() }
    end
  end
  
  #
  # Experiment is done, clean up
  #
  def Experiment.done
    MObject.info "Experiment", "DONE!"
    Experiment.setConfigEl('status', "DONE")
    NodeHandler.exit
  end
  
  #
  # INTERNALS
  #
  
  #
  # Return an XML element with 'name' under the root
  # 
  def Experiment.getConfigEl(name)
    if (el = @@expRoot.elements[name]) == nil
      el = @@expRoot.add_element(name)
    end
    return el
  end  
  
  #
  # Set the text of an XML element with 'name' under the root
  # to 'value'
  # 
  def Experiment.setConfigEl(name, value)
    Experiment.getConfigEl(name).text = value
  end  
  
  
end

class PropertyContext < MObject

  
  def PropertyContext.[](paramName)
    return ExperimentProperty.create(paramName)
  end
  
  def PropertyContext.method_missing(name, args = nil)
    name = name.to_s
    if setter = (name[-1] == ?=)
      name.chop!
    end
    name = name.to_sym
    p = ExperimentProperty[name]
    if (p == nil)
        raise "Unknown experiment property '#{name}', " + \
            "should be '#{ExperimentProperty.names.join(', ')}'"
    end
    if setter
      p.set(args)
    else
      return p.value
    end
  end
end


class ExperimentProperty < MObject

  # Contains all the experiment properties
  @@properties = Hash.new

  def ExperimentProperty.[] (name)
    return @@properties[name.to_sym]
  end
  
  def ExperimentProperty.create(name, value = nil, description = nil)
    name = name.to_sym
    p = nil
    if (p = @@properties[name]) != nil
      p.value = value if value != nil
      p.description = description if description != nil
    else
      p = ExperimentProperty.new(name, value, description)
      @@properties[name] = p
    end
    return p
  end
  
  def ExperimentProperty.names()
    return @@properties.keys
  end
  
  def ExperimentProperty.propertyRootEl= (el)
    @@expProps = el
  end

  attr_reader :name, :value, :description, :id
  
  private :initialize
  def initialize(name, value = nil, description = nil)
    super("prop.#{name}")
    
    @name = name
    @description = description
    @bindings = Array.new
    @changeListeners = Array.new
    
    @id = "ep_#{name}"
    el = @@expProps.add_element('property', 
          {'name' => name.to_s, 'id' => @id})
    @valEl = el.add_element('value')
    if description != nil
      el.add_element('description').text = description
    end
    set(value)
  end
    
#  def bindTo(nodeSet, name) 
#    @bindings += [{:ns => nodeSet, :name => name}]
#  end
  
  def onChange (&block)
    debug("Somebody bound to me")
    @changeListeners << block
  end
  
  
  def set(value)
    @value = value
#    @bindings.each {|b|
#      b[:ns].send(:set, [b[:name], value])
#    }
    info(@name, ' = ', value.inspect, ':', value.class)
    @changeListeners.each { |l|
      l.call(value)
    }
    @valEl.text = value.inspect
  end

  def to_s()
    @value
  end
  
end



