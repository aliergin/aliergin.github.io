#
# This file implements a small web server to 
# observe the status of a nodeHandler
#

require 'webrick'
require 'webrick/httputils'
require 'stringio'
require 'util/mobject'
require 'config/grid'

include WEBrick

module NodeHandlerServer

  @@server = nil
  
  def NodeHandlerServer.start(port = 2000, args = {})
  
    args[:Port] = port

    mimeTable = HTTPUtils::DefaultMimeTypes
    mimeTable.update({ "xsl" => "text/xml" })
    args[:MimeTypes] = mimeTable
    
    @@server = HTTPServer.new(args)
    @@server.mount("/xml", XMLServlet)
    @@server.mount("/xpath", XPathServlet)  
    @@server.mount("/set", SetExpPropertyServlet)
    Thread.new {
      @@server.start  
    }
  end
  
  def NodeHandlerServer.url()
    addr = @@server.listeners[0].addr
    return "http://#{OConfig::NODE_HANDLER_HOST}:#{addr[1]}"
  end
  
  def NodeHandlerServer.map(path, servlet)
    @@server.mount(path, servlet)
  end
  
  def NodeHandlerServer.stop()
    @@server.shutdown if @@server != nil
    @@server = nil
  end

  class XMLServlet < HTTPServlet::AbstractServlet
    def do_GET(req, res)
      res['ContentType'] = "text/xml"
      ss = StringIO.new()
      ss.write("<?xml version='1.0'?>\n")
      
      xslt = req.query['xslt']
      if (xslt != nil)
        ss.write("<?xml-stylesheet href='#{xslt}' type='text/xsl'?>")
      end
          
      xpath = req.query['xpath']
      if (xpath == nil)
        #NodeHandler::DOCUMENT.write(ss, 2, true, true)
        NodeHandler::DOCUMENT.write(ss, 2)
      else
        ss.write("<match>\n")
        match = REXML::XPath.match(NodeHandler::DOCUMENT, xpath)  
        match.each { |frag|
          frag.write(ss, 2)
        }
        ss.write("</match>\n")                    
      end
      res.body = ss.string
    end
  end
  
  class XPathServlet < HTTPServlet::AbstractServlet
    def do_GET(req, res)
      q = req.query['q']
      filter = req.query['f']

      res['ContentType'] = "text/xml"
      ss = StringIO.new()
      ss.write("<?xml version='1.0'?>\n")
      ss.write("<match>\n")
      match = REXML::XPath.match(NodeHandler::DOCUMENT, q)        
      #match.write(ss, 2, true, true)
      if (filter == nil) 
        match.each { |frag|
          ss.write("<p>\n")
          frag.write(ss, 2)
          ss.write("</p>\n")          
        }
      else
        # issue filter against all matches
        match.each { |m|
          match2 = REXML::XPath.match(m, filter) 
          ss.write("<p>\n")
          match2.each { |frag|
            ss.write("<f>\n")
            frag.write(ss, 2)
            ss.write("</f>\n")            
          }
          ss.write("</p>\n")
        }
      end
      ss.write("</match>\n")
      res.body = ss.string
    end
  end
  
  class SetExpPropertyServlet < HTTPServlet::AbstractServlet
    def do_GET(req, res)
      q = req.query
      name = q['name']
      value = q['value']      
      if (name == nil || value == nil)
        raise HTTPStatus::BadRequest, "Missing sargument 'name' or 'value'"
      end
      prop = Experiment.props[name]
      if (prop == nil)
        raise HTTPStatus::BadRequest, "Undefined property '#{name}'"
      end
      prop.set(value)
      
      res['ContentType'] = "text"
      res.body = "Done"
    end
  end


end

