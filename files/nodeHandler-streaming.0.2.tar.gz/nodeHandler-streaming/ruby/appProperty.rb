#
# This class describes an application property
#

class AppProperty

  #
  # Unmarshall an AppProperty instance from an XML tree.
  #
  # @param appDefRoot Root of property definition
  #
  def AppProperty.from_xml(defRoot)
    if (defRoot.name != "property")
      raise "Property definition needs to start with an 'property' element"
    end 
    name = defRoot.attributes['id']
    description = mnemonic = type = constraints = nil
    isDynamic = false
    defRoot.elements.each { |el|
      case el.name
      when 'name' : name = el.text
      when 'description' : description = el.text
      when 'mnemonic' : mnemonic = el.text
      when 'type' : type = el.text
      when 'constraints' : constraints = el.text
      when 'dynamic' : isDynamic = el.text == 'true'
      else
	warn "Ignoring element '#{el.name}'"
      end
    }
    p = AppProperty.new(name, description, mnemonic, type, isDynamic, constraints)
    return p
  end

  attr_reader :name, :description, :mnemonic, :type, :constraints
  
  def initialize(name, description, mnemonic, type, isDynamic = false, constraints = nil)
    @name = name
    @description = description
    @mnemonic = mnemonic
    @type = type
    @isDynamic = isDynamic
    @constraints = constraints
  end
  
  def dynamic?
    @isDynamic
  end
  
  #
  # Return the object definition as an XML element
  #
  def to_xml
    a = REXML::Element.new("property")
	a.add_attribute("id", name)
    a.add_element("name").text = name
    a.add_element("description").text = description
    m = mnemonic
    if m.kind_of?(Integer) 
      m = m.chr
    end
    a.add_element("mnemonic").text = m
    a.add_element("type").text = type
    a.add_element("dynamic").text = dynamic?.to_s
    if constraints != nil	
      a.add_element("constraints").text = constraints
    end
    return a
  end

  
end

class MutableAppProperty < AppProperty

  attr_writer :name, :description, :mnemonic, :type, :isDynamic, :constraints
  
  
end

#p = AppProperty.new('foo', 'Some description', 'm', 'string')
#p.dynamic?
#
#mp = MutableAppProperty.new('foo2', 'Some description2', 'm', 'string')
#mp.dynamic?
#mp.isDynamic = true
#mp.dynamic?

