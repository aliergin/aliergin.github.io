#
# 
#

require "version.rb"
require "appMeasurement.rb"
require "appProperty.rb"

require "rexml/document"

#
# This class describes an application which can be used 
# for an experiment on Orbit
#

class AppDefinition

  VERSION = "$Revision: 1.8 $".split(":")[1].chomp("$").strip
  VERSION_STRING = "AppDefinition V#{NH_VERSION}"


  protected :initialize
	
  @@apps = Hash.new

  #
  # Return a known AppDefinition instance.
  #
  # @param uri URI identifying the AppDefinition
  #
  def AppDefinition.[](uri)
    app = @@apps[uri]
    if app == nil
      MObject.debug('AppDefinition: ', 'Loading app definition "', uri, '".')
      str, type = OConfig.load(uri, true)
      #MObject.debug('Prototype: ', 'str: "', str, '".')
      if type == "text/xml"
        #app = AppDefinition.from_xml(str.to_xml???)
      elsif type == "text/ruby"
        #eval(str)  # this should create the desired app definition
        app = @@apps[uri]
      end
      if app == nil
        raise "Unknown AppDefinition '" + uri + "'."
      end
    end
    return app
  end
	
  #
  # Return a new, mutable AppDefinition instance.
  #
  # @param id URI identifying the AppDefinition
  #
  def AppDefinition.create(uri)
    return MutableAppDefinition.new(uri)
  end

  #
  # Unmarshall an AppDefinition instance from an XML tree.
  #
  # @param appDefRoot Root of application definition
  #
  def AppDefinition.from_xml(appDefRoot)
    if (appDefRoot.name != "application")
      raise "Application definition needs to start with an 'application' element"
    end 
    id = appDefRoot.attributes['id']
    if @@apps[id] != nil
      raise "Application definition '#{id}' already loaded."
    end
    a = AppDefinition.new(id)
    a.from_xml(appDefRoot)
    @@apps[a.id] = a
    return a
  end

  # Local id
  attr_reader :id

  # location of the XML serialization of this definition
  attr_reader :uri

  # Name of AppDefinition  
  attr_reader :name
  
  # Version of AppDefinition
  attr_reader :version
  
  # Copyright notice (can be a URI)
  attr_reader :copyright
  
  # Short and longer description of the AppDefinition
  attr_reader :shortDescription, :description
  
  # Properties of the AppDefinition itself
  attr_reader :properties
  
  # Properties of the AppDefinition itself
  attr_reader :measurements
  
  # Location of binary install package
  attr_reader :binaryRepository
  
  # Location of development/source install package
  attr_reader :developmentRepository 
  
  # Name to use for apt-get install (nil if packet is not in apt)
  attr_reader :aptName
  
  # Location of binary on installed machine
  attr_reader :path
  
  # Environment settings required for running this application
  attr_reader :environment
  
  def initialize(uri)
    if @@apps.has_key? uri
      raise "application definition with name '" + uri + "' already exists."
    end
    @@apps[uri] = self
  
    @id = uri
    @uri = uri
    @properties = Hash.new
    @measurements = Hash.new
    @environment = Hash.new
  end
  
  #
  # Return the AppDefinition definition as XML element
  #
  def to_xml
    a = REXML::Element.new("application")
    a.add_attribute("id", id)
    a.add_element("name", id).text = name != nil ? name : id 
    if (uri != nil) 
      a.add_element("uri").text = uri
    end
    
    if (version != nil) 
      a.add_element(version.to_xml)
    end
    a.add_element("copyright").text = copyright
    a.add_element("shortDescription").text = shortDescription
    a.add_element("description").text = description
    
    if @properties.length > 0
      pe = a.add_element("properties")
      @properties.each_value {|p|
        pe.add_element(p.to_xml)
      }
    end

    if @measurements.length > 0
      me = a.add_element("measurements")
      @measurements.each_value {|m|
        me.add_element(m.to_xml)
      }
    end
    
    a.add_element("path").text = @path
    if (@environment.length > 0)
      pv = a.add_element("environments")
      @environment.each {|k, v|
        pv.add_element('env', {'name' => k}).text = v
      }
    end
    return a
  end
  
  #
  # Initialize the object with information contained in
  # an XML tree rooted at "appRoot".
  #
  # DO NOT CALL DIRECTLY. Use the class method instead
  #
  # @param appRoot XML element "application"
  #
  #protected
  def from_xml(appRoot)
    # assumes we already checked that appRoot.name = 'application'
    # and extracted 'id'. See AppDefinition.from_xml.
    @name = appRoot.attributes['name']
    appRoot.elements.each { |el|
      case el.name
      when 'url' : @uri = el.text
      when 'name' : @name = el.text
      when Version::VERSION_EL_NAME :  # @version = Version.from_xml(el)
      when 'copyright' : @copyright = el.text;
      when 'shortDescription' : @shortDescription = el.text;
      when 'description' : @description = el.text;

      when 'properties'
	el.elements.each { |el|
	  p = AppProperty.from_xml(el)
	  @properties[p.name] = p
	}

      when 'measurements'
	el.elements.each { |el|
	  m = AppMeasurement.from_xml(el)
	  @measurements[m.id] = m
	}
    
#    a.add_element("shortDescription").text = shortDescription
#    a.add_element("description").text = description
#    
#    if @properties.length > 0
#      pe = a.add_element("properties")
#      @properties.each_value {|p|
#        pe.add_element(p.to_xml)
#      }
#    end
#
#    if @measurements.length > 0
#      me = a.add_element("measurements")
#      @measurements.each {|m|
#        me.add_element(m.to_xml)
#      }
#    end
#    
#    a.add_element("path").text = @path
#    return a
      when 'path' : @path = el.text;
      else
	warn "Ignoring element '#{el.name}'"
      end
    }
  end
  
end

#
# These instances can be edited
#
class MutableAppDefinition < AppDefinition

  public_class_method :new
  
  attr_writer :name, :copyright, :shortDescription, :description
  attr_writer :aptName, :path, :environment
  
#  def url=(url)
#    currentUri = id
#    @id = url + "#" + id
#    if currentUri != @id
#      @@apps.delete(currentUri)
#      @@apps[@uri] = self
#    end 
#  end
  def addProperty(name, description, mnemonic, type, isDynamic = false, constraints = nil)
      if @properties[name] != nil
        raise "Property '" + name + "' already defined."
      end
    prop = AppProperty.new(name, description, mnemonic, type, isDynamic, constraints)
    @properties[name] = prop
  end
  
  def version(major = nil, minor = 0, revision = 0)
    if (major == nil)
      return @version
    end 
    @version = MutableVersion.new(major, minor, revision) 
  end

  
  #
  # Add a measurement point.
  #
  # @param id Id of measurement point
  # @param descr Description of this point [optional]
  #
  def addMeasurement(id, description = nil, metrics = nil)
    
    m = MutableAppMeasurement.new(id, description, metrics)
    @measurements[id] = m
    return m
  end

  def repository(binary, development = nil)
    @binaryRepository = binary
    @developmentRepository = development
  end
  
  private
  
  def initialize(uri)
    super(uri)
  end

  
  
end

if $0 == __FILE__
  require 'optparse'
  
  xFile = nil
  rFile = nil
  outFile = $stdout
  
  logConfigFile = 'log/default.xml'
  
  
  opts = OptionParser.new
  opts.banner = "Usage: appDefinition [-h] [options]"
  
  opts.on("-x", "--xml FILE", "App definition in XML format") {|file| 
    xFile = file
  }
  
  opts.on("-r", "--ruby FILE", "App definition in ruby format") {|file|
    rFile = file
  }
  
  opts.on("-o", "--output FILE", "File to write xml result to") {|file| 
    outFile = File.new(file, "w")
  }
  
  opts.on("-l", "--log FILE", "File containing logging configuration information") {|file| 
    logConfigFile = file
  }
  
  opts.on_tail("-h", "--help", "Show this message") { puts opts; exit }
  opts.on_tail("-v", "--version", "Show the version") { 
    puts AppDefinition::VERSION_STRING
    exit
  }

  begin 
    rest = opts.parse(ARGV)
    
    # create the loggers.
    MObject.initLog('appDef', logConfigFile)
    MObject.info('init', AppDefinition::VERSION_STRING)
    MObject.info('init', "Experiment ID: #{Experiment.ID}")
    
    appDef = nil
    if (xFile != nil)
      f = File.new(xFile)
      doc = REXML::Document.new(f)
      appDef = AppDefinition.from_xml(doc.root)
    elsif (rFile != nil)
      require rFile
    end
    
    
    
  rescue SystemExit => err
    exit
  rescue Exception => ex
    begin 
      bt = ex.backtrace.join("\n\t")
      puts "Exception: #{ex} (#{ex.class})\n\t#{bt}"
    rescue Exception
    end
    exit -1
  end
  

end

