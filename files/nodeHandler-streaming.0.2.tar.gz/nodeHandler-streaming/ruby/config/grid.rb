require 'cmc'
require 'omlApp'

module OConfig
  
  REPOSITORY_TOP = '../repository'

  NODE_HANDLER_HOST = 'console'  # used for OML_URL
  
#  CMC.setServiceURL("http://cmc.orbit-lab.org/controlgrid.html")
  CMC.setServiceURL("http://cmc:5012/cmc")
  OmlApp.setServiceURL("frisbee", 5012)

  #
  # Return the IP address of the control interface of
  # the node a coordinates x:y
  #
  # @param x X coordinate of node
  # @param y Y coordinate of node
  #
  def OConfig.getControlIP(x, y)
    return "10.10.#{x}.#{y}"
  end
  
  #
  # Return the x:y coordinates of a node signing on with
  # 'idString'. This string is supposed to be of the type 
  # '/ip/CONTROL_IP'.
  #
  # @param idString String of type '/ip/CONTROL_IP'
  # @return Array of [x, y]
  #
  def OConfig.getCoordFromControlIP(idString)
    match = /.*\.(\d+)\.(\d+)$/.match(idString)
    if (match != nil && match.size == 3)
      x = match[1].to_i
      y = match[2].to_i
      if x > 100
        # sandbox
        x = y / 100
        y = y % 100
      end
      return [x, y]
    end
    raise "Can't parse #{idString}"
  end
  
  #
  # Return the parameters for the collection server to connect to OML database 
  #
  def OConfig.getOmlDBSettings()
    return {'host' => "10.10.0.8", 'password' => "orbit", 'user' => "orbit"}
  end
  
  #
  # Return the parameters of the multicast session between OML clients and the server
  #
  def OConfig.getOmlMCSettings()
    return {'addr' => "224.10.10.2", 'iface' => "eth1", 'port' => "7000" }
  end
  
  #
  # Load the uri and return the body as well as the 
  # mime type.
  #  
  # Two different mime types are supported:
  # * 'text/xml': The object representation is in XML
  # * 'text/ruby' : The object is described in ruby syntax
  #
  # @param uri URI of source
  # @param evalRuby If true evaluate ruby code before returning
  # @returns text, mimeType
  #
  def OConfig.load(uri, evalRuby = false)
    path = [ uri.split(':').join('_') + '.rb', 
      REPOSITORY_TOP + '/' + uri.split(':').join('/') + '.rb' ]
    file = path.inject(nil) { |found, p|
      if found == nil && File.readable?(p)
        found = p
      end
      found
    }
    if file == nil
      raise IOError, "Can't find any of '#{path.join(', ')}'"
    end
    str = File.new(file).read() 
    if evalRuby
      #eval(str, nil, path, 1)
      require file
    end
    return [str, 'text/ruby']
  end
  
end
