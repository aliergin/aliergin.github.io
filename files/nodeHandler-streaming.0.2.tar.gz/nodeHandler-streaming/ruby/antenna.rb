require 'util/mobject'
require 'net/http'
#
# This class represents an antenna. An antenna is associated with a
# SignalGenerator and a SpectrumAnalyzer
#
class Antenna < MObject
  
  def Antenna.[] (x, y, precision = nil)
    key = "#{x}@#{y}"

    # right now, we just have ONE
    key = "1@1"
    return @@antennas[key]
  end

  #
  # Create an antenna at a specific location
  # If no node exists, create a new one.
  #
  def Antenna.create(x, y)
    key = "#{x}@#{y}"

    # right now, we just have ONE
    key = "1@1"
    a = Antenna.new(key)
    @@antennas[key] = a
    return a
  end

  @@antennas = Hash.new

  def initialize(name)
    @signal = SignalGenerator.new("instrument1", "1")
  end

  def signal(&block)
    if block != nil
      block.call(@signal)
    end
    @signal
  end
	
end

#
# This class controls a specific SignalGenerator
#
class SignalGenerator < MObject

  def initialize(name, inst_id)
    @name = name
    @inst_id = inst_id
    @url = "http://instrument#{@inst_id}.orbit-lab.org:8001/esg?instrument_id=#{inst_id}?"
  end

  attr_reader :bandwidth, :channel, :power, :on

  def bandwidth=(bandwidth)
    if (@bandwidth == bandwidth)
      return
    end
      
    u = "#{@url}&signal_type=noise&bandwidth=#{bandwidth}"
    set(u)
    @bandwidth = bandwidth
  end

  def channel=(channel)
    if (@channel == channel)
      return
    end
      
    u = "#{@url}&signal_type=noise&channel=#{channel}"
    set(u)
    @channel = channel
  end

  def power=(power)
    if (@power == power)
      return
    end
      
    u = "#{@url}&signal_type=noise&power=#{power}"
    set(u)
    @power = power
  end

  def on()
    if (@on)
      return
    end
      
    u = "#{@url}&command=start"
    set(u)
    info("Switched on signal generator #{inst_id} bw: #{@bandwidth} ch: #{@channel} pw: #{@power}")
    @on = true
  end

  def off()
    if (! @on)
      return
    end
      
    u = "#{@url}&command=stop"
    set(u)
    info("Switched off signal generator #{inst_id}")
    @on = false
  end

  private

  def set(url)
    response = Net::HTTP.get_response(URI.parse(url))
    if (! response.kind_of? Net::HTTPSuccess)
      raise "Can't initialize noise generator : #{response.to_s}"
    end
  end
end

MObject.initLog('antenna')

# Right now, we just have one antenna which works for everything
Antenna.create(1,1)

if $0 == __FILE__


  MObject.info("Antenna Testharness")

  Antenna[1, 2].signal {|s|
    s.bandwidth = 20
    s.channel = 3
    s.power = -18
    s.on
  }

  Kernel.sleep 20

  Antenna[1, 2].signal.off
end

