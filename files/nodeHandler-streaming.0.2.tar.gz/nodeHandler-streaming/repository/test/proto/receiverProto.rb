#
# Define a prototype
#

require "prototype.rb"
require "filter.rb"
require "nodeSet.rb"

require "test/gennyReceiverAppDef"

p = Prototype.create("http://apps.orbit-lab.org/receiver")
p.name = "Receiver"
p.description = "Nodes which receive a stream of packets"
p.addParameter(:if, "name of interface to use", Node::W0_IF)
p.addParameter(:useSocket, "If true use socket, otherwise use libmac for transport", true)
p.addParameter(:sampleSize, "size of samples to average over (OML)", 100)

genny = p.addApplication(:gennyReceiver, "http://apps.orbit-lab.org/gennyReceiver#gennyReceiver")
genny.bindProperty(:interface_name, :if)
genny.bindProperty(:use_socket, :useSocket)

genny.addMeasurement(:group3,  Filter::SAMPLE, 
  {Filter::SAMPLE_SIZE => :$sampleSize},
  [
    ["offered_load", Filter::MEAN]
  ]
)

genny.addMeasurement(:group1, Filter::SAMPLE, 
  {Filter::SAMPLE_SIZE => :$sampleSize},
  [
    [:rssi, Filter::MEAN],
    [:noise, Filter::MEAN]
  ]
)
genny.addMeasurement(:group2,  Filter::SAMPLE, 
  {Filter::SAMPLE_SIZE => 100},
  [
    [:throughput, Filter::MEAN]
  ]
)


if $0 == __FILE__
  p.to_xml.write($stdout, 2)
  puts
end

