#
# Define a prototype
#
# $Id: forwarder.rb,v 1.1 2005/03/28 21:34:06 zhibinwu Exp $

require 'prototype'
require 'filter'
require 'appDefinition'

p = Prototype.create("test:proto:forwarder")
p.name = "Forwarder"
p.description = "Nodes which forward packets"
p.defProperty('protocol', 'Protocol to use', 'raw')
p.defProperty('rxdev', 'hw interface to listen on', 'eth0')
p.defProperty('txdev', 'hw interaface to send', 'eth0')
p.defProperty('ipFilter', 'IP address of the destination', '12.0.0.6')
p.defProperty('nextHopMAC', 'hw address of next-hop receiver', 'FF:FF:FF:FF:FF:FF')

otf = p.addApplication('otf', "test:app:otf")

otf.bindProperty('protocol')
otf.bindProperty('rxdev')
otf.bindProperty('txdev')
otf.bindProperty('dstfilter','ipFilter')
otf.bindProperty('dstmacaddr','nextHopMAC')

otf.addMeasurement('senderport',  Filter::TIME, 
  {Filter::SAMPLE_SIZE => 1},
  [
    ['stream_no'],
    ['pkt_seqno'],
    ['pkt_size', Filter::SUM],
    ['gen_timestamp'],
    ['tx_timestamp']
  ]
)
otf.addMeasurement('receiverport',  Filter::TIME, 
  {Filter::SAMPLE_SIZE => 1},
  [
    ['stream_no'],
    ['pkt_seqno'],
    ['sender_port'],    ['flow_no'],
    ['pkt_num_rcvd'],
    ['rcvd_pkt_size', Filter::SUM],      
    ['rx_timestamp',  Filter::MEAN],
    ['rssi', Filter::MEAN],
    ['xmitrate']
  ]
)

if $0 == __FILE__
  p.to_xml.write($stdout, 2)
  puts
end

