#
# Define a prototype containing a single
# traffic generator (otg).
#

require 'prototype'
require 'filter'
require 'appDefinition'
require 'config/grid'

p = Prototype.create("test:proto:sender")
p.name = "Sender"
p.description = "A node which transmit a stream of packets"
# List properties of prototype
p.defProperty('protocol', 'Protocol to use', 'udp')
p.defProperty('destinationHost', 'Host to send packets to')
p.defProperty('packetSize', 'Size of packets', 1000)
p.defProperty('rate', 'Number of bits per second', 1000)

# Define applications to be installed on this type of node,
# bind the application properties to the prototype properties,
# and finally, define what measurements should be collected
# for each application.
#
otg = p.addApplication(:otg, "test:app:otg")
otg.bindProperty('protocol')
otg.bindProperty('dsthostname', 'destinationHost')
otg.bindProperty('size', 'packetSize')
otg.bindProperty('rate')

otg.addMeasurement('senderport',  Filter::TIME, 
  {Filter::SAMPLE_SIZE => 1},
  [
    ['stream_no'],
    ['pkt_seqno'],
    ['pkt_size', Filter::SUM],
    ['gen_timestamp'],
    ['tx_timestamp']
  ]
)

if $0 == __FILE__
  p.to_xml.write($stdout, 2)
  puts
end

