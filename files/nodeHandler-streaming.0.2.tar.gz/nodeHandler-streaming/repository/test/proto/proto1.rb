#
# Define a prototype
#

require "prototype.rb"
require "filter.rb"

require "appDef1.rb"

p = Prototype.create("sender")
p.name = "Sender"
p.description = "Nodes which send a stream of packets"
p.addParameter(:payload_length, "payload length of outgoing packets", 1000)
p.addParameter(:channel, "Channel to send on", 1)

nodeAgent = p.addApplication("http://apps.orbit-lab.org/nodeAgent#nodeAgent")
nodeAgent.bindProperty(:payload_length)
nodeAgent.bindProperty(:channel_id, :channel)

nodeAgent.addMeasurement(:group1, Measurement::SAMPLE, 
  {:trigger => 3},
  [
    [:rssi, Filter::MIN_MAX],
    [:noise, Filter::MEAN]
  ])

# Alternative syntax
m3 = nodeAgent.addMeasurement(:group2, Measurement::SAMPLE)
m3.setProperty(:trigger, 3, :sec)
m3.addMetric(:throughput).addFilter(Filter::MIN_MAX, {:foo => 3})


p.to_xml.write($stdout, 2)
puts
