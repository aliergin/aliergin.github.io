
require 'appDefinition'

a = AppDefinition.create('test:app:otr')
a.name = "otr"
a.version(0, 0, 2)
a.shortDescription = "Programmable traffic generator"
a.description = <<TEXT
otr is a configurable traffic sink. It contains port to receive 
packet streams via various transports, such as TCP and UDP.
TEXT

#addProperty(name, description, mnemonic, type, isDynamic = false, constraints = nil)
a.addProperty('protocol', 'Protocol to use [udp|tcp]', nil, String, false)
a.addProperty('hostname', 'My own ID', nil, String, false)
a.addProperty('port', 'transport port number of listen on', nil, "xsd:int", true)

a.addMeasurement("receiverport", nil, [
  ['stream_no', 'int', 'id of the stream'],
  ['pkt_seqno', 'long', 'Packet sequence id of the stream'],
  ['sender_port', 'int','Sender\'s port number'],
  ['flow_no', 'int','id of receiving flow'],
  ['pkt_num_rcvd', 'long',' Packet Sequence id of the flow'],
  ['rcvd_pkt_size', 'long', 'Payload size'],    
  ['rx_timestamp', 'long', 'Time when packet has been received'],
  ['rssi', 'int', 'rssi of received packet'] ,
  ['xmitrate','int','channel rate of received packet']
])

#a.repository("http://repository.orbit-lab.org/common/gennySender")
#a.repository("http://controlpxe.orbit-lab.org/repository/genny-0.3.tar")
#a.aptName = 'orbit-otr'

a.path = "/usr/local/bin/otr"
#a.environment['LD_LIBRARY_PATH'] = '/usr/local/lib/oml2'

if $0 == __FILE__
  require 'stringio'
  require 'rexml/document'
  include REXML
    
  sio = StringIO.new()
  a.to_xml.write($stdout, 2)
end
