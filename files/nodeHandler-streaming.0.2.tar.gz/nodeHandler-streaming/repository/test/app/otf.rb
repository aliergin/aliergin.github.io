#$Id: otf.rb,v 1.1 2005/03/28 21:32:27 zhibinwu Exp $

require 'appDefinition'

a = AppDefinition.create('test:app:otf')
a.name = "otr"
a.version(0, 0, 2)
a.shortDescription = "Programmable traffic forwarder"
a.description = <<TEXT
otf is a configurable traffic forwarder. It re-route traffice from one 
incoming interface to another one using raw sockets 
TEXT

#addProperty(name, description, mnemonic, type, isDynamic = false, constraints = nil)
a.addProperty('protocol', 'Protocol to use [raw|raw_libmac]', nil, String, false)
a.addProperty('rxdev', 'incoming interface [eth0|eth2|eth3]', nil, String, false)
a.addProperty('txdev', 'outgoing interface [eth0|eth2|eth3]', nil, String, false)
a.addProperty('dstfilter', 'packet filter using destination IP address', nil, String, false)
a.addProperty('dstmacaddr', 'MAC address for next-hop', nil,String, false)

a.addMeasurement("senderport", nil, [
    ['stream_no', 'int'],
    ['pkt_seqno', 'long'],
    ['pkt_size', 'long'],
    ['gen_timestamp', 'long'],
    ['tx_timestamp', 'long']
])

a.addMeasurement("otfreceiver", nil, [
  ['flow_no'],'int','id of receiving flow'],
  ['pkt_num_rcvd','long',' Packet Sequence id of the flow'],
  ['rcvd_pkt_size', 'long', 'Payload size'],    
  ['rx_timestamp', 'long', 'Time when packet has been received'],
  ['rssi', 'int', 'rssi of received packet'] ,
  ['xmitrate','int','channel rate of received packet']
])



#a.repository("http://repository.orbit-lab.org/common/gennySender")
#a.repository("http://controlpxe.orbit-lab.org/repository/genny-0.3.tar")
#a.aptName = 'orbit-otf'

a.path = "/usr/local/bin/otf"
#a.environment['LD_LIBRARY_PATH'] = '/usr/local/lib/oml2'

if $0 == __FILE__
  require 'stringio'
  require 'rexml/document'
  include REXML
    
  sio = StringIO.new()
  a.to_xml.write($stdout, 2)
end
