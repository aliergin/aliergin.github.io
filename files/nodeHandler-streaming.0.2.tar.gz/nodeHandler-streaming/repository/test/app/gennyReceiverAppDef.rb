#
# Create an application representation from scratch
#
require "appDefinition.rb"

a = AppDefinition.create("gennyReceiver")
a.url = "http://apps.orbit-lab.org/gennyReceiver"
a.name = "gennyReceiver"
a.version(0, 0, 1)
a.shortDescription = "Traffic sink"
a.description = <<TEXT
Genny Revceiver is the receiving peer of the UDP traffic 
generator that reports measurements such as RSSI, noise 
and throughput. It can be configured to use 
libmac (for RSSI measurement) or plain sockets 
as its underlying transport mechanism.
TEXT

# addProperty(name, description, mnemonic, type, isDynamic = false, constraints = nil)
a.addProperty(:interface_name, "Interface to send on", ?i, String, false)
a.addProperty(:use_socket, "Socket or Libmac", ?s, :boolean, false)


a.addMeasurement(:group1, nil, [
  [:rssi, AppMeasurement::FLOAT],
  [:noise, AppMeasurement::FLOAT]
])
a.addMeasurement(:group2, nil, [
  [:throughput, AppMeasurement::FLOAT]
])

a.repository("http://repository.orbit-lab.org/common/gennyReceiver")

if $0 == __FILE__
  a.to_xml.write($stdout, 2)
  puts
end

