require 'net/http'
require 'uri'

Experiment.name = "tutorial-1"
Experiment.project = "orbit:tutorial"

#
# Define various elements used in the experiment
#

defProperty('rate', 300, 'Bits per second sent from sender')
defProperty('packetSize', 256, 'Size of packets sent from sender')
defProperty('startExp', 0, 'Start experiment flag')

# Streaming Sources
defNodes('sender', [[1,2],[2,1],[3,2]]) {|node|
  # Dummy
  node.image = nil  # assume the right image to be on disk
  node.prototype("test:proto:sender", {
    'destinationHost' => '192.168.2.1',
    'packetSize' => Experiment.property("packetSize"),
    'rate' => Experiment.property("rate"),
    'protocol' => 'udp'
  })
  node.net.w0.down = "true"
  node.net.w1.down = "true"
  node.net.w0.unload = "ath_pci"
  node.net.w0.load = "ath_pci"
  node.net.w0.type = 'a'
  node.net.w0.essid = "%lunar%x"
  node.net.w0.mode = "master"
  node.net.w0.rate = "6M"
  node.net.w0.ip = "%192.168.%x.%y"
  node.net.w0.bash = "/root/send-stream.sh"
}

# Streaming Destinations
defNodes('receiver', [[1,8],[2,5],[3,8]]) {|node|
  # Dummy
  node.image = nil  # assume the right image to be on disk
  node.prototype("test:proto:sender", {
    'destinationHost' => '192.168.2.1',
    'packetSize' => Experiment.property("packetSize"),
    'rate' => Experiment.property("rate"),
    'protocol' => 'udp'
  })
  node.net.w0.down = "true"
  node.net.w1.down = "true"
  node.net.w0.unload = "ath_pci"
  node.net.w0.load = "ath_pci"
  node.net.w0.type = 'a'
  node.net.w0.essid = "%lunar%x"
  node.net.w0.mode = "managed"
  node.net.w0.rate = "6M"
  node.net.w0.ip = "%192.168.%x.%y"
  node.net.w0.bash = "/root/receive-stream.sh"
}


# Relaying Nodes
defNodes('relayer', [[3,4],[8,3]]) {|node|
  # Dummy
  node.image = nil  # assume the right image to be on disk
  node.prototype("test:proto:sender", {
    'destinationHost' => '192.168.2.1',
    'packetSize' => Experiment.property("packetSize"),
    'rate' => Experiment.property("rate"),
    'protocol' => 'udp'
  })
  node.net.w0.down = "true"
  node.net.w1.down = "true"
  node.net.w0.unload = "ath_pci"
  node.net.w0.load = "ath_pci"
  node.net.w0.type = 'a'
  node.net.w0.essid = "lunar3"
  node.net.w0.mode = "managed"
  node.net.w0.rate = "6M"
  node.net.w0.ip = "%192.168.%x.%y"
  node.net.w0.bash = "/root/common-functions.sh"
}
#
# Now, start the application
#
whenAllInstalled() {|node|
  Experiment.props.packetSize = 1024
  Experiment.props.rate = 5000
  Experiment.props.startExp = 0

#  wait 30000

  Experiment.done
}



