 
Experiment.name = "imageNode"
Experiment.project = "Orbit::Admin"

defProperty('nodes', [1..8, 1..8], "Range of nodes to image")
defProperty('image', 'baseline.ndz', "Image to load on nodes")

#
# Load an image onto a set of nodes
#
defNodes('image', Experiment.property('nodes')) {|n|
  n.pxeImage("orbit-1.0.5", "pxe:1.0.5")
#  n.image = "pxe"
#  n.image = "orbit-1.0.4"  
  n.onNodeUp {|n|
    n.loadImage!(Experiment.property('image'))
  }
}


whenAll('image', "apps/builtin/status[text()='DONE.OK']") {|node|
  node.pxeImage(nil)
  Experiment.done
}

