#!/bin/bash
#3). Stop
wget -q -O- "http://instrument1.orbit-lab.org:8001/esg?command=config&instrument_id=1&signal_type=noise"
wget -q -O- "http://instrument1.orbit-lab.org:8001/esg?command=init&instrument_id=1&signal_type=noise&bandwidth=$3&channel=$2"
#2). Start And Set Power
wget -q -O- "http://instrument1.orbit-lab.org:8001/esg?command=start&instrument_id=1&signal_type=noise&channel=$2&bandwidth=$3"

wget -q -O- "http://instrument1.orbit-lab.org:8001/esg?instrument_id=1&signal_type=noise&power=$1&channel=$2&bandwidth=$3"


#4). Status: This command is useful to check if the configuring/reconfiguring of the instrument actually took place. This command will actually query the instrument to get the values.

#wget "http://instrument1.orbit-lab.org:8001/esg?command=status&instrument_id=1&signal_type=noise"

#wget -q -O /dev/null "http://instrument1.orbit-lab.org:8001/esg?instrument_id=1&signal_type=noise&bandwidth=$3&channel=$2"
