#!/bin/bash

rowNumber=`hostname|cut -c5`
colNumber=`hostname|cut -c7`

insmod /usr/local/lunar_ac/lnx/ksapf.o debuglevel=0
if [ "$rowNumber-$colNumber" == "8-5" ];then
 insmod /usr/local/lunar_ac/lnx/klunar.o debuglevel=0 basedevname=ath0 mackill=\"00:60:B3:25:C0:0A\"
elif [ "$rowNumber-$colNumber" == "1-4" ];then
 insmod /usr/local/lunar_ac/lnx/klunar.o debuglevel=0 basedevname=ath0 mackill=\"00:60:B3:25:BF:EB\"
else
 insmod /usr/local/lunar_ac/lnx/klunar.o debuglevel=0 basedevname=ath0 
fi

echo "">/var/lib/dhcp/dhclient.leases
echo "40X6000">/proc/pkt_rate
kill -9 `ps x|grep 'dhclient eth2'|cut -d" " -f3`
dhclient eth2
sysctl -w dev.ath1.rawdev=1
ifconfig ath1raw up
sysctl -w dev.ath1.rxfilter=0x1ff
ifconfig ath1 up

if [ "$rowNumber-$colNumber" == "8-3" ];then
iwconfig ath1 essid lunarall mode ad-hoc rate 1M
fi

echo "nameserver 10.0.0.9">/etc/resolv.conf
