#!/bin/bash

echo "Bringing down $1 "
ssh -q root@node3-2 pkill vlc 
ssh -q root@node3-2 "sed -i 's/test-stream-2.mpg/test-stream-3.mpg/' /root/execfile"
ssh -q root@node3-2 sh /root/execfile
ssh -q root@$1 iwconfig ath0 mode managed 
