#!/bin/bash

sh /root/common-functions.sh

rowNumber=`hostname|cut -c5`
colNumber=`hostname|cut -c7`

ownCtrlNWIP=`ifconfig eth1|grep 10.1|cut -d":" -f2|cut -d" " -f1`
echo "vlc -d udp:@:1234 --sout '#standard{access=http,mux=ogg,url=$ownCtrlNWIP:80$rowNumber$colNumber}'">/root/execfile
chmod 755 /root/execfile
sh /root/execfile
exit 0

