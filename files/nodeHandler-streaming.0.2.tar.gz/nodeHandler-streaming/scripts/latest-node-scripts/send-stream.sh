#!/bin/bash

sh /root/common-functions.sh
apt-get install teststream

rowNumber=`hostname|cut -c5`
case $rowNumber in
1)
	destNode=8
	;;
2)
	destNode=5
	;;
3)
	destNode=8
	;;
4)
	destNode=7
	;;
*)	echo "Should not be here"
	exit -1
	;;
esac

# Wait a little before remote Lunar guys get their IP addresses

until echo $destLunarIP|grep 192.168. 
do
  echo ali
  sleep 1
  destLunarIP=`ssh -q root@node$rowNumber-$destNode ifconfig eth2|grep "inet addr:"|cut -d":" -f2|cut -d" " -f1`
done

streamName=`echo "/usr/streams/test-stream-$rowNumber.mpg"`
outputParameter="#standard{access=udp,mux=ts,url=$destLunarIP:1234}"

echo "vlc -d $streamName --sout '$outputParameter' --loop">/root/execfile
chmod 755 /root/execfile
sh /root/execfile&
exit 0
