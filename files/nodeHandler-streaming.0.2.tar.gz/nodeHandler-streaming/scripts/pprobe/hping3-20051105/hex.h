#ifndef __HEX_H
#define __HEX_H

int hextobin(void *dest, char *hexstr, int len);
void bintohex(char *dest, void *bin, int len);

#endif
