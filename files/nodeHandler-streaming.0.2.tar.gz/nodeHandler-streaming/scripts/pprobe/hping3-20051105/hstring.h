#ifndef HPING_HSTRNIG_H
#define HPING_HSTRING_H

int strisnum(char *s);
size_t strftok(char *sep, char *str, char **tptrs, size_t nptrs);

#endif
