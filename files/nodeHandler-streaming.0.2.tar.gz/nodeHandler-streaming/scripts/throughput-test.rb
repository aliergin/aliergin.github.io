Experiment.name = "tutorial-1a"
Experiment.project = "orbit:tutorial"

#
# Define nodes used in experiment
#
defNodes('sender', [1,2]) {|node|
  node.image = nil  # assume the right image to be on disk

  node.prototype("test:proto:sender", {
    'destinationHost' => '192.168.1.2',
    'packetSize' => 1024,
    'rate' => 300,
    'protocol' => 'udp'    
  })
  node.net.w0.mode = "managed"
}

defNodes('receiver', [1,8]) {|node|
  node.image = nil  # assume the right image to be on disk
  node.prototype("test:proto:receiver" , {
    'hostname' => '192.168.1.8',
    'protocol' => 'udp'
  })
  node.net.w0.mode = "master"
}

allNodes.net.w0 { |w|
    w.type = 'a'
    w.essid = "helloworld"
    w.ip = "%192.168.%x.%y"
    w.channel ="36";
}


#
# Now, start the application
#
whenAllInstalled() {|node|
#  wait 30 

#  allNodes.startApplications
#  wait 40

  Experiment.done
}
