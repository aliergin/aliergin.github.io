#!/bin/bash

echo "Bringing up $1 "
ssh -q root@node3-2 pkill vlc >/dev/null
ssh -q root@node3-2 "sed -i 's/test-stream-3.mpg/test-stream-2.mpg/' /root/execfile" >/dev/null
ssh -q root@node3-2 sh /root/execfile >/dev/null
ssh -q root@$1 iwconfig ath0 mode ad-hoc
