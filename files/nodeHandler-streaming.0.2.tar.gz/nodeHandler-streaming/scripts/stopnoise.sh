wget -q -O- "http://instrument1.orbit-lab.org:8001/esg?command=stop&instrument_id=1&signal_type=noise"
