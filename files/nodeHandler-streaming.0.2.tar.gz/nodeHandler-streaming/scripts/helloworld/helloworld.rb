Experiment.name = "tutorial-1a"
Experiment.project = "orbit:tutorial"

#
# Define nodes used in experiment
#
defNodes('sender', [5,5]) {|node|
  node.image = nil  # assume the right image to be on disk

  node.prototype("test:proto:sender", {
    'destinationHost' => '192.168.3.4',
    'packetSize' => 1024,
    'rate' => 300,
    'protocol' => 'udp'    
  })
  node.net.w0.mode = "managed"
}

defNodes('receiver', [3,4]) {|node|
  node.image = nil  # assume the right image to be on disk
  node.prototype("test:proto:receiver" , {
    'hostname' => '192.168.3.4',
    'protocol' => 'udp'
  })
  node.net.w0.mode = "master"
}

allNodes.net.w0 { |w|
  w.type = 'b'
  w.essid = "helloworld"
  w.ip = "%192.168.%x.%y"
}

#
# Now, start the application
#
whenAllInstalled() {|node|
  wait 30 

  allNodes.startApplications
  wait 40

  Experiment.done
}
