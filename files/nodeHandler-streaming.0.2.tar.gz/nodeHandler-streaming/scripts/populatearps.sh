#!/bin/bash

rowNumber=`hostname|cut -c5`
colNumber=`hostname|cut -c7`

if [ "$rowNumber-$colNumber" == "8-5" ];then
 arp -s 192.168.8.3 00:60:B3:25:BF:F2
 arp -s 192.168.1.4 00:60:B3:25:C0:0A
 arp -s 192.168.1.6 00:60:B3:AC:2B:5C
elif [ "$rowNumber-$colNumber" == "8-3" ];then
 arp -s 192.168.8.5 00:60:B3:25:BF:EB
 arp -s 192.168.1.4 00:60:B3:25:C0:0A
 arp -s 192.168.1.6 00:60:B3:AC:2B:5C
elif [ "$rowNumber-$colNumber" == "1-4" ];then
 arp -s 192.168.8.5 00:60:B3:25:BF:EB
 arp -s 192.168.8.3 00:60:B3:25:BF:F2
 arp -s 192.168.1.6 00:60:B3:AC:2B:5C
elif [ "$rowNumber-$colNumber" == "1-6" ];then
 arp -s 192.168.8.5 00:60:B3:25:BF:EB
 arp -s 192.168.8.3 00:60:B3:25:BF:F2
 arp -s 192.168.1.4 00:60:B3:25:C0:0A
else
  echo
fi
