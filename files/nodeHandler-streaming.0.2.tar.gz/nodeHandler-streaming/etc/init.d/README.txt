For testing, run script like follows:

sudo env LIB_DIR=/home/max/nodeAgent2/src/ruby ./gridServices start
