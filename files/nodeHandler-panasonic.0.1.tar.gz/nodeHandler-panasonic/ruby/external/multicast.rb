require 'socket'
 
#struct ip_mreq {
#        struct in_addr  imr_multiaddr;  /* IP multicast address of group */
#        struct in_addr  imr_interface;  /* local IP address of interface */
#};
 

class MulticastSocket < UDPSocket
 
 # Some constants that are not set in Win32 version of socket.c
 IPPROTO_IP = Socket::IPPROTO_IP
 #IPPROTO_UDP = 17
 IPPROTO_UDP = Socket::IPPROTO_UDP
 #IP_DROP_MEMBERSHIP = 6
 IP_DROP_MEMBERSHIP = Socket::IP_DROP_MEMBERSHIP
 
 def convAddr(a)
  h = nil
  case a
  when String
   h = a.split('.').collect! { |b| b.to_i }.pack('CCCC')
 
  when Array
   h = a.pack('CCCC')
 
  else
   raise "Bad address"
  end
  h
 end
 private :convAddr
 
 def addMembership(mcaddr)
  mreq = convAddr(mcaddr) + Socket.gethostbyname(Socket.gethostname)[3]
  #mreq = convAddr(mcaddr) + "\000\000\000\000"
  setsockopt(IPPROTO_IP, Socket::IP_ADD_MEMBERSHIP, mreq)
 end
 
 def dropMembership(mcaddr)
  mreq = convAddr(mcaddr) + Socket.gethostbyname(Socket.gethostname)[3]
  setsockopt(IPPROTO_IP, IP_DROP_MEMBERSHIP, mreq)
 end
 
 def setMCTTL(ttl)
  setsockopt(IPPROTO_IP, Socket::IP_MULTICAST_TTL, ttl)
 end
 
 def setMCLoop(loop)
  setsockopt(IPPROTO_IP, Socket::IP_MULTICAST_LOOP, loop)
 end
 
 def setMCInterface(int)
  host = Socket.gethostbyname(int)[3]
  setsockopt(IPPROTO_IP, Socket::IP_MULTICAST_IF, host)
 end
 
end
 
if $0 == __FILE__
 
 $port = 2100
 $addr = '239.192.0.1'
 
 sock = MulticastSocket.open
 sock.bind(Socket.gethostname, $port)
 sock.addMembership($addr)
  
 thread = Thread.start do
  2.times { 
    p sock.recvfrom(10) 
  }
 end
 
 sock.send('Hello', 0, $addr, $port)
 sock.send('There', 0, $addr, $port)
 
 thread.join
 sock.dropMembership($addr)
end
 