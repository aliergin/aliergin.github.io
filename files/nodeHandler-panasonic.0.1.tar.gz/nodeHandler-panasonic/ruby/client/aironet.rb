require 'client/ethernet'

#
# This class represents an Cisco Aironet device
#
class AironetDevice < EthernetDevice

  attr_reader :essid
  
  def initialize(logicalName, deviceName)
    super(logicalName, deviceName)
    @essid = "ORBIT"
    @loaded = false    
  end
  
  def getConfigCmd(prop, value)

    case prop
      when "mode"
        return "/sbin/iwconfig #{@deviceName} mode #{value} essid #{@essid}"

#      when /.*:status/ 
#        return "/sbin/ifconfig #{@deviceName} #{value}"

      when "essid"
        @essid = value
        return "/sbin/iwconfig #{@deviceName} essid #{value}"

      when "channel"
        channel = value.to_i
        if (channel < 1 || channel > 11)
          raise "Unsupported channel '#{channel}'. Need to be between 1 and 11."
        end
        return "echo 'Channel: #{value}' >> /proc/driver/aironet/#{@deviceName}/Config"

      when "tx_power"
        power = value.to_i
        if (! [1, 5, 20, 30, 50, 100].include?(power))
          raise "Unsupported power level '#{power}'. Valid levels are 1, 5, 20, 30, 50, 100."
        end
        return "echo 'XmitPower: #{value}' >> /proc/driver/aironet/#{@deviceName}/Config"

      when "bitrate" 
        r = value.to_i
        p = case
          when r == 1 : 2
          when r == 2 : 4
          when r == 5.5 : 11
          when r == 11 : 22
          else 
            raise "Unknown bitrate #{value}. Valid rates are 1, 2, 5.5, and 11."
        end
        return "echo 'DataRates: #{value} 0 0 0 0' >> /proc/driver/aironet/#{@deviceName}/Config"

      when "frag_threshold"
        # 'value' is number of bytes after which payload is fragmented
        return "echo 'FragThreshold: #{value}' >> /proc/driver/aironet/#{@deviceName}/Config"

      when "retries"
        # 'value' is number of retries. '0' disables them
        s = "echo 'LongRetryLimit: #{value}' >> /proc/driver/aironet/#{@deviceName}/Config;"
        return s + "echo 'LongRetryLimit: #{value}' >> /proc/driver/aironet/#{@deviceName}/Config"        

      when "rts_threshold"
        # 'value' is number of bytes until which there is no RTS/CTS exchange So, to 
        # enable RTS/CTS for ALL packets the value should be set to 0. To disable it, 
        # it should be set to max MTU = 2312 bytes
        return "echo 'RTSThreshold: #{value}' >> /proc/driver/aironet/#{@deviceName}/Config"
    end
    super    
  end
  
  #  
  # Called multiple times to ensure that device is up
  #
  def activate()
    if (! @loaded)
      reply = `/sbin/modprobe airo_pci`
      if ! $?.success?
        raise "Problems loading Aironet module -- #{reply}"      
      end
      @loaded = true
    end
  end
  
  
end
