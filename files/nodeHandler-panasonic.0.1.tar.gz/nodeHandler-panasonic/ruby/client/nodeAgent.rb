#!/usr/bin/ruby
#
#
# $Id: nodeAgent.rb,v 1.19 2005/05/21 18:06:32 max Exp $

require 'util/communication'
require 'client/agentCommands'
require 'date'

class NodeAgent < MObject

  include NodeCommunication

  VERSION = "@VERSION@"

  # Interface used for the control channel
  CONTROL_IF = "eth1"
  
  # How many seconds can we go without a message from the node handler
  # before we assume we have lost connectivity and need to reset
  HANDLER_TIMEOUT = 20
  
  # Number of seconds to wait between consecutive RETRY requests
  RETRY_INTERVAL = 3
  
  # Number of seconds between consecutive HEARTBEAT messages
  HEARTBEAT_INTERVAL = 10
  
  # Pause between resending previous messages
  RESEND_INTERVAL = 0.1
  
  # Singleton
  @@instance = nil
  
  # Name of image we booted into
  @@imageName = 'UNKNOWN'
  
  #
  # Return singleton
  #
  def NodeAgent.instance
   return @@instance
  end
  
  #
  # Set the name of the image found when starting up
  #
  def NodeAgent.imageName(imageName)
    @@imageName = imageName
  end
  
  #
  # Run node handler. This method will
  # block until somebody calls 'done'
  #
  def NodeAgent.run
    if (@@instance != nil)
      raise "Already running"
    end
    info("NodeAgent V#{VERSION}")
    @@instance = NodeAgent.new
    @@running = ConditionVariable.new
    @@mutex = Mutex.new
    @@mutex.synchronize {
      @@running.wait(@@mutex)
    }
  end
  
  attr_reader :x, :y, :agentName
  
  def addAlias(newAlias)
    if @names.length == 1
      # this is the first alias we got, make it the new agent name
      @agentName = newAlias
    end
    @names.insert(0, newAlias)
    MObject.debug("Agent names #{@names.join(', ')}")    
  end
   
  #
  # An comamnd has been successfully completed.
  # According to the communications pattern an agent is
  # not reporting success back to the handler. We simply
  # log it
  #
  def okReply(cmd, id, *msgArray)
    sendHeartbeat()
  end

  #
  # An error occured while executing command 'cmd'
  # with 'id'. Send an error message back to the handler
  #
  def errorReply(cmd, id, *msgArray)
    send(:ERROR, cmd, id, *msgArray)
  end

  
  # Send a message
  #
  # @param message Text message
  #
  def send(*msgArray) 
    if @connected
      send!(@outSeqNumber += 1, *msgArray)
    end
  end
  
  # Send a message
  #
  # @param seqNo
  # @param message Text message
  #
  def send!(seqNo, *msgArray) 
    message = "#{@agentName} #{seqNo} #{LineSerializer.to_s(msgArray)}"
    if (seqNo > 0)
      @messages[@outSeqNumber] = message
    end
    debug("Send message(#{@sendAddr}:#{@sendPort}): '#{message}'")
    @sendSock.send(message, 0, @sendAddr, @sendPort)
    return seqNo
  end
  private :send!
  
  
  # Resend a message and all following ones to the current
  # @outSeqNumber. 
  #
  # This method starts a thread which sends the sequence of
  # messages spaced by RESEND_INTERVAL. If it is being called
  # before a previously created thread has finished, it will
  # return immediately and NOT create a new thread.
  #
  # @param msgId First message to send
  #
  def resend(msgId)
    if (@resendThread != nil && @resendThread.alive?)
      return
    end
    @resendThread = Thread.new(msgId) { | msgId |
      while msgId <= @outSeqNumber
        message = @messages[msgId]
        debug("Resend message(#{@sendAddr}:#{@sendPort}): '#{message}'")
        @sendSock.send(message, 0, @sendAddr, @sendPort)
        sleep RESEND_INTERVAL
        msgId += 1
      end
    }
  end
  
  
  #
  # Called by ExecApp which is monitoring 
  # an application identified by 'id'.
  #
  # @param eventName Name of event
  # @param appId Id of application monitored
  # @param msg Optional message
  def onAppEvent(eventName, appId, *msg)
    debug("onAppEvent(#{eventName}:#{appId}): '#{msg}'")
    send(:APP_EVENT, eventName.to_s.upcase, appId, *msg)
  end
  
  def reset
  
    ExecApp.killAll
    
    @connected = false  # set to true on first message adddressed to us
    @agentName = "/ip/#{@mcInterface}"
    @messages = Array.new # keep all messages

    @recvCache = Hash.new # maintain a cache of "early" messages
    @resendThread = nil

#### ONLY FOR WINDOWS TESTING
    controlIP = @mcInterface != nil ? @mcInterface : "10.10.2.3"
#### END OF HACK
    findCoordinates(controlIP)
    
    @agentName = "/ip/#{controlIP}"
    
    # keeping track of seq numbers of 
    # in and outgoing communication
    @outSeqNumber = 0
    @inSeqNumber = -1
    @inHighestNumber = -1
    @requestThread = nil
    @handlerTimestamp = 0
    
    @names = [@agentName]

  end

  ################################################
  private

  
  # Start the node agent
  def initialize
    initCommunication(true)
    reset

    Thread.new() {
      while true
        sleep HEARTBEAT_INTERVAL
        debug "Sending Heartbeat"
        sendHeartbeat
      end
    }
  end
  
  #
  # Send a heartbeat back to the handler
  #  
  def sendHeartbeat()
    if @connected 
      # Check if we still hear from handler
      if (Time.now - @handlerTimestamp > HANDLER_TIMEOUT)
        error "Lost handler, will reset"
        reset
      else
        ts =  DateTime.now.strftime("%T")
        send!(0, :HEARTBEAT, @outSeqNumber, @inSeqNumber, ts)
      end
    else
      # haven't heard from nodeHandler yet, resend initial message
      @outSeqNumber = 1
      send!(1, "WHOAMI", VERSION, @@imageName)
    end
  end


  #
  # Process the command comming from the handler. Should
  # be of the form:
  #
  # sequenceNo target command arg1 arg2 ...
  #
  # @param argArray command line parsed into an array
  #
  def processCommand(argArray)
    if argArray.size < 3
      raise "Command is too short '#{argArray.join(' ')}'"
    end
    @handlerTimestamp = Time.now # we still hear the handler

    seqNo = argArray.delete_at(0).to_i
    isRetry = (seqNo < 0) # retries have negative seqNo
    seqNo = seqNo.abs
    if (seqNo > @inHighestNumber)
      @inHighestNumber = seqNo
    end
      
    # check if we skipped a command
    if (@inSeqNumber < 0)
      # first message received
      if isRetry || seqNo == 0
        return # don't start with a retry
      end
      debug "First sequence number encountered: #{seqNo}"
      # continue
    elsif seqNo == 0
      # this is a "best effort"  request, process it if we can
    elsif (seqNo <= @inSeqNumber) 
      # already got that one
      #debug "Already got message #{seqNo}"
      return
    elsif (seqNo > @inSeqNumber + 1)
      # we missed some. Drop and send retry for
      # first missed one.
      @recvCache[seqNo] = argArray # cache for catching up
      requestRetry()
      return
    end
    # normal command in sequence
    debug "Exec #{seqNo} '#{argArray.join(' ')}'"
    @inSeqNumber = seqNo
    execCommand(argArray)
    
    # process any early messages in sequence
    while ((argArray = @recvCache[seqNo += 1]) != nil)
      debug "Catching up #{seqNo}"
      @inSeqNumber = seqNo
      execCommand(argArray)
      @recvCache.delete(seqNo)
    end
    
  end
  
  def execCommand(argArray)
    
    target = argArray.delete_at(0)

    # Check if it is us
    # We want to support glob matches, but Ruby only does regex
    # For simply '*' placeholders, replace glob '*' with regex '.*'
    # may work.
    regTarget = Regexp.new(target.gsub(/\*/, '.*'))
    forMe = false
    @names.each { |name|
      if (regTarget.match(name) != nil)
        debug "Match #{name} => #{target}"
        forMe = true
        break
      end
    }
    if (! forMe)
      return
    end
    
    @connected = true  # the nodeAgent knows us!
    command = argArray.delete_at(0).upcase
    method = nil
    begin 
      method = AgentCommands.method(command)
    rescue Exception
      error "Unknown command '#{command}'"
      send(:ERROR, :UNKNOWN_CMD, command)
      return
    end  
    begin
      reply = method.call(self, argArray)
    rescue Exception => err
      error "While executing '#{command}': #{err}"
      send(:ERROR, :EXECUTION, command, err)
      return
    end  
  end

  # This method is called when a packet with a higher seq
  # number has been received.
  # Right now we simply send a retry message, but in the future
  # may consider a random wait first to let other agents report
  # it first.
  #
  def requestRetry()
    if (@requestThread != nil && @requestThread.alive?)
      # already working on it
      return
    end
    @requestThread = Thread.new() {
      while (@inHighestNumber > @inSeqNumber) 
        from = to = @inSeqNumber + 1
        while (@recvCache[to += 1] == nil)
        end
        message = "#{@agentName} 0 RETRY #{from} #{to - 1}"
        debug("Send message(#{@sendAddr}:#{@sendPort}): '#{message}'")
        @sendSock.send(message, 0, @sendAddr, @sendPort)
        sleep RETRY_INTERVAL
      end
    }    
  end
  
  
  #
  # Find the coordinates of this node within the grid. Right
  # now the position is encoded in the IP address, more
  # specifically the lower two bytes.
  #
  # If this script is deployed in a different setting, change the code
  # accordingly.
  #
  def findCoordinates(controlIP)
    match = /.*\.(\d+)\.(\d+)$/.match(controlIP)
    @x = match[1].to_i
    @y = match[2].to_i
    if @x > 100
      # sandbox
      @x = @y / 100
      @y = @y % 100
    end
    info "Located at #{@x}:#{@y}"
  end
  

end


include Log4r

if log = ENV['NODE_AGENT_LOG'] == nil
  log = "/etc/nodeagent/nodeagent_log.xml"
end

# Make sure log exists ...
log = File.exists?(log) ? log : nil
MObject.initLog('nodeAgent', nil, log)

# Discover devices
IO.popen("lspci | grep 'Network controller: Intel' | wc -l") {|p| 
  if p.gets.to_i > 0
    MObject.info "Have Intel cards"
    require 'client/intel'
    AgentCommands::DEV_MAPPINGS['net/w0'] = IntelDevice.new('net/w0', 'eth2')
    AgentCommands::DEV_MAPPINGS['net/w1'] = IntelDevice.new('net/w1', 'eth3')
  end
}
IO.popen("lspci | grep 'Ethernet controller: Atheros' | wc -l") {|p| 
  if p.gets.to_i > 0
    MObject.info "Have Atheros cards"
    require 'client/atheros'
    AgentCommands::DEV_MAPPINGS['net/w0'] = AtherosDevice.new('net/w0', 'ath0')
    AgentCommands::DEV_MAPPINGS['net/w1'] = AtherosDevice.new('net/w1', 'ath1')
  end
}
if (File.exists?(AgentCommands::IMAGE_NAME_FILE))
  File.open(AgentCommands::IMAGE_NAME_FILE) { |f| 
    NodeAgent.imageName(f.read.chomp) 
  }
else
  MObject.warn("Can't find '#{AgentCommands::IMAGE_NAME_FILE}'")
end



begin
  NodeAgent.run  
rescue SystemExit
rescue Interrupt
  # ignore
rescue Exception => ex
  begin 
    bt = ex.backtrace.join("\n\t")
    puts "Exception: #{ex} (#{ex.class})\n\t#{bt}"
  rescue Exception
  end
end
MObject.info("Exiting")
ExecApp.killAll



