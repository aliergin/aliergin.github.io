
require 'util/mobject'
require 'client/execApp'

require 'client/aironet'
require 'client/ethernet'

module AgentCommands

  DEV_MAPPINGS = {
    'net/e0' => EthernetDevice.new('net/e0', 'eth0'),
#    'net/w2' => AironetDevice.new('net/w2', 'eth2')
  }

  VERSION = "$Revision: 1.15 $".split(":")[1].chomp("$").strip

  SYSTEM_ID = :system
  
  # File containing image name
  IMAGE_NAME_FILE = '/.orbit_image'
  
  #
  # ALIAS: Set an additional name for this node
  #
  # Args: newName
  #
  def AgentCommands.ALIAS(agent, argArray)
    argArray.each{ |name| 
      agent.addAlias(name)
    }
  end
  
  #
  # EXEC: Execute a program
  #
  # Args: id - Id of program/process
  #       args - elements making up the command to execute
  #
  def AgentCommands.EXEC(agent, argArray)
    id = getArg(argArray, "ID of install")
    
    args = [] # potentially substitute arguments
    argArray.each { |arg|
      if (arg[0] == ?%)
        # if arg starts with "%" perform certain substitutions
        arg = arg[1..-1]  # strip off leading '%'
        arg.sub!(/%x/, agent.x.to_s)
        arg.sub!(/%y/, agent.y.to_s)
        arg.sub!(/%n/, agent.agentName)
      end
      if arg =~ /^OML_CONFIG=.*:/
        # OML can't fetch config file over the net, need to download it first
        url = arg.split('=')[1..-1].join('=')
        # this is overkill, but so what
        require 'digest/md5'
        fileName = "/tmp/#{Digest::MD5.hexdigest(url)}.xml"
        MObject.debug("Fetching oml definition file ", url)
        if (! system("wget -q -O #{fileName} #{url}"))
          raise "Couldn't fetch OML config file #{url}"
        end
        arg = "OML_CONFIG=#{fileName}"
      end
      args << arg
    }
    cmd = args.join(' ')
    ExecApp.new(id, agent, cmd)
  end
  
  #
  # KILL: Send a signal to a process
  #
  # Args: id - Id of program/process
  #       signal - Signal to send [KILL]
  #
  def AgentCommands.KILL(agent, argArray)
    id = getArg(argArray, "ID of process")
    signal = getArgDefault(argArray, "KILL")  
    ExecApp[id].kill(signal)
  end

  #
  # STDIN: Send a line to a process
  #
  # Args: id - Id of program/process
  #       [line] - Rest of args are being sent to stdin
  #
  def AgentCommands.STDIN(agent, argArray)
    id = getArg(argArray, "ID of process")
    line = argArray.join(' ')	
    ExecApp[id].stdin(line)
  end
 
  
  #
  # PM_INSTALL: Poor man's installer. Fetch a tar file and 
  #             extract it into a specified directory
  #
  # Args: id - Id of install, used for reporting progress
  #       url - URL of tar file
  #       installRoot - Directory to extract tar file in ["/"]
  #
  def AgentCommands.PM_INSTALL(agent, argArray)
    id = getArg(argArray, "ID of install")
    url = getArg(argArray, "URL of program to install")    
    installRoot = getArgDefault(argArray, "/")
     
    MObject.debug "Installing #{url} into #{installRoot}"
    cmd = "cd /tmp;wget -q #{url};"
    file = url.split('/')[-1]
    cmd += "tar -C #{installRoot} -xf #{file}; rm #{file}"
    ExecApp.new(id, agent, cmd)
  end

  #
  # APT: Execute apt-get command on node
  #
  # Args: id - Id of install, used for reporting progress
  #       command - Command to apt-get
  #       pkgName - name of package to install (should that be optional?)
  #       args - Optional args given to 'apt-get'
  #
  def AgentCommands.APT_INSTALL(agent, argArray)
    id = getArg(argArray, "ID of install")
    command = getArg(argArray, "Command to apt-get")
    pkgName = getArg(argArray, "Name of package to install")    

    cmd = "apt-get -q -y #{argArray.join(' ')} #{command} #{pkgName}"
    ExecApp.new(id, agent, cmd)
  end
  
  #
  # RESET: Reset this node agent
  #
  def AgentCommands.RESET(agent, argArray)
    agent.reset
  end
  
  
  #
  # RESTART: Restart node agent
  #
  def AgentCommands.RESTART(agent, argArray)
    ExecApp.killAll
    system('/etc/init.d/nodeAgent restart')
    # will be killed by now :(
  end

  #
  # REBOOT: Reboot node
  #
  def AgentCommands.REBOOT(agent, argArray)
    agent.send(:STATUS, SYSTEM_ID, "REBOOTING")
    system('/sbin/reboot')
  end

  #
  # MODPROBE: Load a kernel module
  #
  # Args: moduleName - Name of module
  #       args - Optional parameters to modprobe command
  #
  def AgentCommands.MODPROBE(agent, argArray)
    moduleName = getArg(argArray, "Name of module to probe")
    id = "module/#{moduleName}"
    ExecApp.new(id, agent, "/sbin/modprobe #{argArray.join(' ')} #{moduleName}")
  end

  #
  # CONFIGURE: Configure a system parameter
  #
  # Args: path - Name of parameter as path
  #       value - Value to sent parameter to
  #
  def AgentCommands.CONFIGURE(agent, argArray)
    path = getArg(argArray, "Name of parameter as path")
    value = getArg(argArray, "Value to set parameter to")
    
   if (type, id, prop = path.split("/")).length != 3
     raise "Expected path '#{path}' to contain three levels"
   end
   
   device = DEV_MAPPINGS["#{type}/#{id}"]
   if (device == nil)
     raise "Unknown resource '#{type}/#{id}' in 'configure'"
   end
   
   device.configure(agent, prop, value)
  end

  #
  # LOAD_NODE: Load a specified image onto this node
  #  through frisbee
  #
  # Args: mcAddr - Address of image multicast
  #       mcPort - Port of image multicast
  #       disk - Disk to image [/dev/hda]
  def AgentCommands.LOAD_IMAGE(agent, argArray)
    mcAddress = getArg(argArray, "Multicast address")
    mcPort = getArg(argArray, "Multicast port")
    disk = getArgDefault(argArray, "/dev/hda")

    MObject.info "AgentCommands", "Frisbee image from ", mcAddress, ":", mcPort
    ip = agent.getMCInterface
    cmd = "frisbee -i #{ip} -m #{mcAddress} -p #{mcPort} #{disk}"
    MObject.debug "AgentCommands", "Frisbee command: ", cmd
    ExecApp.new('builtin:load_image', agent, cmd, true)
  end  

  #
  # SAVE_NODE: Save the image of this node with frisbee and send 
  # it to the image server.
  #
  # Args: mcAddr - Address of image multicast
  #       mcPort - Port of image multicast
  #       disk - Disk to image [/dev/hda]
  def AgentCommands.SAVE_IMAGE(agent, argArray)
    nsfDir = getArg(argArray, "NSF path for saved image")
    imgName = getArg(argArray, "Name of saved image")
    disk = getArgDefault(argArray, "/dev/hda")

    MObject.info "AgentCommands", "Image zip #{disk} to #{nsfDir}/#{imgName}"
    Dir.mkdir("/mnt")
    #check the disk.  Assuming that the system disk is hda1
#     cmd = "fsck -py #{disk}1"
#     if ! system(cmd)
#       raise "While fscking #{$?}"
#     end  
    system("mkdir /mount")
    system("mount -o nolock #{disk}1 /mount")
    File.open('/mnt/#{IMAGE_NAME_FILE}', 'w') {|f| f.puts(imgName)}
    system("umount /mount")
    cmd = "mount -o nolock #{nsfDir} /mnt"
    if ! system(cmd)
      raise "While mounting #{nsfDir}: #{$?}"
    end
    
    cmd = "imagezip #{disk} /mnt/#{imgName}"
    MObject.debug "AgentCommands", "Image save command: #{cmd}"
    ExecApp.new('builtin:save_image', agent, cmd, true)
  end  
  
  #
  # RETRY: Resend a command to the nodes
  #
  # Args: messageId
  #
  def AgentCommands.RETRY(agent, argArray)
    msgId = getArg(argArray, "Number of message to resend").to_i
    MObject.debug "AgentCommands", "RETRY message #{msgId}"
    agent.resend(msgId)
  end
  
  private
  
  # Remove the first element from 'argArray' and
  # return it. If it is nil, raise exception 
  # with 'exepString' providing MObject.information about the 
  # missing argument
  #
  # @return First element in 'argArray' or raise execprion if nil
  # @param argArray Array of arguments
  # @param exepString MObject.information about argument, used for expection
  # @raises Exception if arg is nil
  #
  def AgentCommands.getArg(argArray, exepString)
    arg = argArray.delete_at(0)
    if (arg == nil)
      raise exepString
    end
    return arg
  end
    
  # Remove the first element from 'argArray' and
  # return it. If it is nil, return 'default'
  #
  # @return First element in 'argArray' or 'default' if nil
  # @param argArray Array of arguments
  # @param default Default value if arg in argArray is nil
  #
  def AgentCommands.getArgDefault(argArray, default = nil)
    arg = argArray.delete_at(0)
    if (arg == nil)
      arg = default
    end
    return arg
  end

end
