
require 'util/mobject'

#
# This class is the base class for all configuarable 
# devices
#
class Device < MObject

  attr_reader :deviceName, :logicalName
  
  def initialize(logicalName, deviceName)
    @deviceName = deviceName
    @logicalName = logicalName    
  end
  
  # Configure a property of this device
  #
  # @param agent Agent to inform about result
  # @param prop Property to configure
  # @param value Value to set property to
  #
  def configure(agent, prop, value)
    info "configure #{@logicalName}/#{prop} = #{value}"
    activate() # make sure that the device is actually loaded

    if (value[0] == '%'[0])
      # if value starts with "%" perform certain substitutions
      value = value[1..-1]  # strip off leading '%'
      value.sub!(/%x/, agent.x.to_s)
      value.sub!(/%y/, agent.y.to_s)
    end

    path = "#{logicalName}/#{prop}"
    begin
      cmd = getConfigCmd(prop, value)
      debug "configure cmd: #{cmd}"
      reply = `#{cmd}`
      if $?.success?
        agent.okReply(:CONFIGURE, path, reply)
      else
        agent.errorReply(:CONFIGURE, path, reply)      
      end
    rescue => err
      error("While configuring #{prop} with #{value} \n\t#{err}")
      agent.errorReply(:CONFIGURE, path, err)
	end
  end
    
  def getConfigCmd(prop, value)
    raise "Unknown property '#{prop}'"
  end
  
  #  
  # Called multiple times to ensure that device is up
  #
  def activate()
    # do nothing
  end

  def deactivate()
    # do nothing
  end

end
 