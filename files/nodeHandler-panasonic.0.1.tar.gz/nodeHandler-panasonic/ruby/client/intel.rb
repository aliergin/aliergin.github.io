
require 'client/ethernet'

#
# This class represents an Atheros device
#
class IntelDevice < EthernetDevice

  def initialize(logicalName, deviceName)
    super(logicalName, deviceName)
    @essid = "ORBIT"
    @loaded = false
  end
  
  def getConfigCmd(prop, value)

    case prop
      when 'type'
        # 'value' defines type of operation
        p = case
          when value == 'a' : 1
          when value == 'b' : 2
          when value == 'g' : 3
          else 
            raise "Unknown type. Should be 'a', 'b', or 'g'."
        end
        return "iwpriv #{@deviceName} set_mode #{p}"

      when "mode"
        # 'value' defines mode of operation
        p = case
          #when value == 'master' : 'master'
          when value == 'managed' : 'managed'
          when value == 'ad-hoc' : 'ad-hoc'
          #when value == 'monitor' : 'monitor'
          else 
            raise "Unknown mode '#{value}'. Should be 'managed', or 'ad-hoc'."
        end
        return "/sbin/iwconfig #{@deviceName} mode #{value}"

      when "essid"
        @essid = value
        return "/sbin/iwconfig #{@deviceName} essid #{value}"

      when "frequency"
        return "/sbin/iwconfig #{@deviceName} freq #{value}"      

      when "tx_power"
        return "/sbin/iwconfig #{@deviceName} txpower #{value}"      

      when "rate"
        return "/sbin/iwconfig #{@deviceName} rate #{value}"      

      when "channel"
        return "/sbin/iwconfig #{@deviceName} channel #{value}"      

      when "unload"
        return "/sbin/modprobe -r #{value}"      

      when "load"
        return "/sbin/modprobe #{value}"      
     
    end
    super
  end
  
  #  
  # Called multiple times to ensure that device is up
  #
  def activate()
    if (! @loaded)
      reply = `/sbin/modprobe ipw2200`
      if ! $?.success?
        raise "Problems loading Intel module -- #{reply}"      
      end
      @loaded = true
    end
  end
  
end
