#
# This class describes a property
#
class Property

  #
  # Unmarshall a Property instance from an XML tree.
  #
  # @param appDefRoot Root of property definition
  #
  def Property.from_xml(defRoot)
    if (defRoot.name != "property")
      raise "Property definition needs to start with an 'property' element"
    end 
    idref = defRoot.attributes['idref']
    obj = unit = nil
    isBinding = false
    defRoot.elements.each { |el|
      case el.name
      when 'binding'
        obj = el.attribute['idref']
        isBinding = true
      when 'value' 
        obj = el.text
        unit = el.attribute['unit']
      else
        warn "Ignoring element '#{el.name}'"
      end
    }
    if isBinding : warn "NOT IMPLEMENTED: Resolving bindings from XML streams" end
    p = Property.new(idred, obj, unit, isBinding)
    return p
  end

  attr_reader :idref, :value, :unit, :bindingRef, :isBound

  #
  # @param idref Reference to property in {@link AppDefinition}
  # @param obj Value or property binding to establish value of property
  # @param unit Unit of value
  # @param isBinding If true "obj" is a property reference, otherwise it's a value
  #
  def initialize(idref, obj = nil, unit = nil, isBinding = false)
    @idref = idref
    @unit = unit
    if isBinding
      @bindingRef = obj
    else
      @value = obj
    end
    @isBound = isBinding
  end
  
  #
  # Return the object definition as an XML element
  #
  def to_xml
    a = REXML::Element.new("property")
#    a.add_attribute("idref", idref)
    a.add_attribute("name", idref)
    if isBound
      a.add_element("binding", {"idref" => bindingRef})
    elsif value != nil
      v = a.add_element("value")
      v.text = value
      if (unit != nil)
        v.add_attribute("unit", unit)
      end  
    else
      Log.warn("NOT IMPLEMENTED: check for default value in app definition")
    end 
    return a
  end
  
end



module CreatePropertiesModule

  # Set a property of the application to a specific value
  #
  # @param propName Name of the application property
  # @param value Value of property
  #
  def setProperty(propName, value, unit = nil)
    prop = Property.new(propName, value, unit)
    @properties += [prop]
  end
  
  # Bind the value of a property to another property in the context
  #
  # @param propName name of application property
  # @param propRef Property to bind to
  #
  def bindProperty(propName, propRef = propName)
    prop = Property.new(propName, propRef, nil, true)
    @properties += [prop]
  end
  
  # Add a list of properties described in a hash table
  # where key is the property name and the value its value.
  # If value starts with "$", value is interpreted as 
  # the name of another property to bind to.
  #
  # @param properties Hash describing a set of properties
  # 
  def addProperties(properties)
    if properties != nil
      if properties.kind_of?(Hash)
        properties.each {|k, v|
          if v.kind_of?(Symbol) 
            v = v.to_s
          end
          if v.kind_of?(String) && v[0] == ?$
            # is binding
            bindProperty(k, v[1..-1])
          else
            setProperty(k, v)
          end
        }
      elsif properties.kind_of? Array
        properties.each {|p|
          if ! p.kind_of? Property
            raise "Propertie array needs to contain Property, but is '" \
              + p.class.to_s + "'."            
          end
          @properties += [p]
        }
      else
        raise "Properties declarations needs to be a Hash or Array, but is '" \
          + properties.class.to_s + "'."
      end
      
    end
  end

end
