#
#
#
require 'set'
require 'benchmark'
require 'thread'  # Queue class
require 'experiment'
require 'nodeSet'
require 'util/communication'
require 'handlerCommands'
require 'rexml/document'
require 'rexml/element'
require 'nodeHandlerServer'
require 'cmc'

require 'config/grid'

NH_VERSION = "$Revision: 1.71 $".split(":")[1].chomp("$").strip
NH_VERSION_STRING = "NodeHandler Version #{NH_VERSION}"
  
  
#
# Define an experiment property which can be used to bind
# to application and other properties. Changing an experiment
# property should also change the bound properties, or trigger
# commands to change them.
#
def defProperty(name, defaultValue, description)
  Experiment.defProperty(name, defaultValue, description)
end
  
#
# Define a set of nodes to be used in the experiment.
# This can either be a specific declaration of nodes to
# use, or a set combining other sets.
#
def defNodes(groupName, selector, &block)

  if NodeSet['ALL'] != nil
    # for safety!
    raise "Can't define any more nodes after 'allNodes' has been called"
  end

  if selector.kind_of?(ExperimentProperty)
    selector = selector.value
  end
    
  if ! selector.kind_of?(Array)
    raise "Selector needs to be an array, but is #{selector.class}: #{selector}"
  end
  if selector[0].kind_of?(String)
    ns = GroupNodeSet.new(groupName, selector)
  else
    ns = BasicNodeSet.new(groupName, selector)  
  end

  return RootNodeSetPath.new(ns, nil, nil, block)
end


#
# Evaluate block in the context of a previously defined
# node set 'groupName'.
#
# @returns A {@link RootNodeSet}
# @param groupName Name of node group
#
def nodes(groupName, &block)
  ns = NodeSet[groupName]
  if (ns == nil)
    raise "Undefined node set '#{groupName}'"
  end
  return RootNodeSetPath.new(ns, nil, nil, block)
end

#
# Evalute block over all nodes in the experiment.
#
def allNodes(&block)
  ns = NodeSet['_ALL_']
  return RootNodeSetPath.new(ns, nil, nil, block)
end


def whenAll(nodesSelector, nodeTest, interval = 5, &block)
  ns = NodeSet[nodesSelector]
  if ns == nil
    raise "WhenAll: Unknown node set '#{nodesSelector}"
  end
  Thread.new(ns) { |ns|
    while true 
      begin
        res = false
        isUp = ns.up?
        #MObject.debug("whenAll::internal", "Checking ", ns, " up?: ", isUp)
        if isUp  
          res = ns.inject(true) { |flag, node|
            if flag	
              match = node.match(nodeTest)
              #match.each{|e| e.write($stdout, 2)}
              flag = (match != nil && match.length > 0)
              MObject.debug("whenAll::internal", "Not true for ", node) if !flag
              #p "FLAG: #{flag}"
            end
            flag
          }
        end
        if res
          MObject.info("whenAll", nodesSelector, ": '", nodeTest, "' fires")
          begin 
            RootNodeSetPath.new(ns, nil, nil, block)
          rescue Exception => ex
            bt = ex.backtrace.join("\n\t")
            MObject.error("whenAll", "Exception: #{ex} (#{ex.class})\n\t#{bt}")
          end
          # done
          break
        end
        Kernel.sleep(interval)
      rescue Exception => ex
        bt = ex.backtrace.join("\n\t")
        puts "Exception: #{ex} (#{ex.class})\n\t#{bt}"
      end
    end
  }
end

#
# Execute 'block' when all nodes matching 'pattern'
# are ready.
#
def whenAllInstalled(&block)
  whenAll("_ALL_", "apps/app/status[text()='INSTALLED.OK']", &block)
end

#
# The block is executed when all nodes have checked in
#
def whenNodesUp(&block) 
#  MObject.info "Let's go!"
#  yield(Experiment.parameterContext)
#  Experiment.startApplications
end

#
# The block is executed if all nodes have been configured
#
def whenAppsRunning(pattern = '/*/*', &block) 
#  MObject.info "Let's go!"
#  yield(Experiment, Experiment.parameterContext)
end


#
# Return the appropriate antenna (set)
#
# @returns A {@link Antenna}
# @param x, y Coordiantes of antenna
# @param precision How close to x/y does the antenna really have to be
#
def antenna(x, y, precision = nil)
  a = Antenna[x, y, precision = nil]
  if (a == nil)
    raise "Undefined antenna within #{x}@#{y}"
  end
  return a
end


#
# Wait for some time before issuing more commands
#
# @param time Time to wait in seconds
#
def wait(time)
  Kernel.sleep time
end

def info(*msg)
  MObject.info('exp', *msg)
end


class NodeHandler < MObject

  include NodeCommunication

  VERSION = "$Revision: 1.71 $".split(":")[1].chomp("$").strip

  # Interface used for the control channel
  CONTROL_IF = "eth1"
  
  # Interval between resending the latest message. This
  # allows the agents to find out if they are behind.
  #
  RESEND_LAST_INTERVAL = 5
  
  # Interval between bursts of serving retry requests
  #
  RETRY_SERVICE_INTERVAL = 0.1
  
  DOCUMENT = REXML::Document.new
  ROOT_EL = DOCUMENT.add(REXML::Element.new("context"))
  LOG_EL = ROOT_EL.add_element("log")
  EXPERIMENT_EL = ROOT_EL.add_element("experiment")  
  NODES_EL = ROOT_EL.add_element("nodes")    
  OML_EL = ROOT_EL.add_element("oml")#.add_element('experiment', {'id' => 'unamed_exp'})
    
  # Singleton
  @@instance = nil
  #
  # Return singleton
  #
  def NodeHandler.instance
    if (@@instance == nil)
      @@instance = NodeHandler.new
    end
    return @@instance
  end
  
  #
  # Run node handler. This method will
  # block until somebody calls 'done'
  #
  def NodeHandler.run
    NodeHandler.instance.run
  end
   
  # Send a command to a group of agents
  #
  # @param command Command
  # @param nodeSelector Selector of target agents
  # @param paramArray Array of optional parameters
  #
  def NodeHandler.sendCommand(nodeSelector, command, paramArray)
    instance.send(nodeSelector, command, paramArray)
  end

  # Resend a command
  #
  #
  # @param commandId Command number
  #
  def NodeHandler.resendCommand(commandId) 
    instance.resend(commandId)
  end

  @@justPrint = false  # If true, don't send commands to node, just log action

  def NodeHandler.JUST_PRINT()
    return @@justPrint  
  end
  
  def NodeHandler.JUST_PRINT=(flag)
    @@justPrint = flag
  end
  
  @@shutdown = true  # If true, shutdown nodes at exit

  def NodeHandler.SHUTDOWN()
    return @@shutdown  
  end
  
  def NodeHandler.SHUTDOWN=(flag)
    @@shutdown= flag
  end

  @@mutex = Mutex.new
  @@running = ConditionVariable.new  

  def NodeHandler.exit()
    @@mutex.synchronize {
      @@running.signal
    }
  end
  
  
  def run()
    if (@running != nil)
      raise "Already running"
    end
    if NodeHandler.SHUTDOWN
      # make sure, everything is switched off before starting
      CMC::nodeAllOff()
    end
    sendReset  # if the nodes are already up, reset the agent now
    Experiment.start()
#    @running = ConditionVariable.new
#    @mutex = Mutex.new
    @@mutex.synchronize {
      @@running.wait(@@mutex)
    }
  end
  
    
  private
  
  # Start the node handler
  def initialize
  
    initialize_oml
    if @@justPrint
      puts ">> Opening multicast sockets"
    else
      initCommunication(false)
      @seqCount = 0
      @senderSeq = Hash.new  # keeping track of all sender's seq no
      @messages = Array.new # keep all messages
	@resendQueue = Queue.new # queue for resend request
      @handlerCommands = Hash.new

      # Resend the latest message regularily to 
      # allow all agents to catch up to the latest
      Thread.new() {
        while true
          if (@seqCount > 0)
            resend(@seqCount)
          end
          sleep RESEND_LAST_INTERVAL
        end
      }
  
      Thread.new() {
        resendRequests = Set.new # a list of msg# to resend
        list = Array.new
        sendBlockSize = 5 # Number of retries before refreshing from queue
        while true
          if (resendRequests.length == 0)
            resendRequests.add(@resendQueue.pop()) # may block
          end
          while (! @resendQueue.empty?)
            resendRequests.add(@resendQueue.pop()) # shouldn't block  
          end      
          # Don't resend what we just did
          resendRequests.subtract(list)
#          debug("Process resend queue #{resendRequests.length}")
          # We send the first 'sendBlockSize' queued requests in increasing order
          list = resendRequests.to_a.sort.slice(0, sendBlockSize)
          list.each { |msgId|
            resend!(msgId)
          }
          sleep RETRY_SERVICE_INTERVAL
        end
      }

#    Thread.new() {
#      while true do
#        sleep 10
#        debug ">>> GC"
#        GC.start
#      end
#    }
    end

    
  end

  def initialize_oml()
#    dbp = OConfig.getOmlDBSettings()
#    dbp['id'] = OmlApp.getDbName()
#    OML_EL.add_element('db', dbp)
#    mcp = OConfig.getOmlMCSettings()
#
  end
   
  #
  # Process the command comming from an agent
  #
  # @param argArray command line parsed into an array
  #
  def processCommand(argArray)
  
#sender = nil
#senderId = nil
#bm = Benchmark.measure {
  
    debug "Process message '#{argArray.join(' ')}'"

    if argArray.size < 3
      raise "Command is too short '#{argArray.join(' ')}'"
    end
    senderId = argArray.delete_at(0)
    sender = Node.whoIs(senderId)
#}
#MObject.debug("processCommandTop1: #{bm.to_s.chomp}")

#bm = Benchmark.measure {    
    if (sender == nil) 
      debug "Received message from unknown sender '#{senderId}': '#{argArray.join(' ')}'"
      return
    end
    senderSeq = argArray.delete_at(0).to_i
    if (! inSequence?(sender, senderSeq))
      debug "Message from #{sender} out of sequence"
      return
    end
              
#}
#MObject.debug("processCommandTop2: #{bm.to_s.chomp}")
    
#bm = Benchmark.measure {
    command = argArray.delete_at(0)
    method = @handlerCommands[command]
    if (method == nil)
      begin 
        method = @handlerCommands[command] = HandlerCommands.method(command)
      rescue Exception
        raise "Unknown command '#{command}'"
      end
    end
    reply = method.call(self, sender, senderId, argArray)
#}
#MObject.debug("processCommandBottom: #{bm.to_s.chomp}")
    
  end
  
  #
  # Check if the packet with a sequence # of 'senderSeq' from
  # node 'sender' is in sequence. Return true if it is ok to process
  # the packet. Return false, if processing should be abandoned.
  #
  # If a gap in the seqence number is detected, processing of the 
  # packet at hand is delayed (false is returned), and a retry message 
  # for the missing packets is sent to the sender.
  #
  public
  def inSequence?(sender, senderSeq)
    if (senderSeq == 0)
      # these are best-effort, non-in-sequence message. We always accept them
      return true
    end
    
    lastSeqNo = @senderSeq[sender]
    if lastSeqNo == nil then
      lastSeqNo = 0 #first time
    end
        
    if (senderSeq > lastSeqNo + 1)
      debug("#{sender}: Missed messages #{lastSeqNo + 1} to #{senderSeq - 1}")
      # this is a bit a hack. We can have a node sending retries
      # while we still think it is down. Right now we simply ignore that
      if (! sender.isUp)
        warn "#{sender} is sending messages, but is considered down"
        return true
      end
      # Retry messages should really be sent as special messages, not causing a 
      # retry themselves if a node misses one.
      sendRetry(sender.getFullName, lastSeqNo + 1)
      return false
    elsif (senderSeq <= lastSeqNo)
      # already got that
      return false
    end
    @senderSeq[sender] = senderSeq
    return true
  end
  
  
  # Send a message
  #
  # sequenceNo target command arg1 arg2 ...
  #
  # @param message Text message
  #
  public
  def send(target, command, msgArray) 
    if @@justPrint
      puts "MSG: #{target} #{command}(#{msgArray.join(', ')})"
    else
      @seqCount += 1
      message = "#{@seqCount} #{target} #{command} #{LineSerializer.to_s(msgArray)}"
      @messages[@seqCount] = message
      debug("Send message(", @sendAddr, ":", @sendPort, ")(args: ", msgArray.size, "): '", message, "'")
      @sendSock.send(message, 0, @sendAddr, @sendPort)
    end
  end
  
  # Send a retry message
  #
  # 0 target RETRY msgId
  #
  # @param message Text message
  #
  public
  def sendRetry(target, seqNo) 
    if @@justPrint
      puts "RETRY MSG: #{target} #{seqNo}"
    else
      message = "0 #{target} RETRY #{seqNo}"
      debug("Send message(", @sendAddr, ":", @sendPort, "): '", message, "'")
      @sendSock.send(message, 0, @sendAddr, @sendPort)
    end
  end
  
  # Send a reset message
  #
  # 0 target RESET
  #
  #
  public
  def sendReset(target = '/*/*') 
    if @@justPrint
      puts "RESET MSG: #{target} #{seqNo}"
    else
      message = "0 #{target} RESET"
      debug("Send message(", @sendAddr, ":", @sendPort, "): '", message, "'")
      @sendSock.send(message, 0, @sendAddr, @sendPort)
    end
  end
  
 
  # Resend a message
  #
  #
  # @param msgId Message number (can also be a range)
  #
  def resend(msgId) 
    debug("Resend request for #{msgId}")
    if (msgId.kind_of? Range)
      msgId.each { |i| @resendQueue.push(i) }
    else
      @resendQueue.push(msgId)
    end
  end
 
  def resend!(msgId)
    # retries have a negative seqNo to avoid agent joiners latching
    # onto retries
    message = @messages[msgId]
    # avoid race conditions
    if (message == nil) 
      return
    end
    
    message = "-#{message}"
    debug("Resend message(#{@sendAddr}:#{@sendPort}-#{@seqCount}): '#{message}'")
    @sendSock.send(message, 0, @sendAddr, @sendPort)
  end
    
  #
  # Log an error from 'source'.
  # THe reason is described in string 'reason' with
  # additional information provided in hash table extra
  #
  # @return log id
  #
  def logError(source, reason, extra = nil) 
    return log('error', source, reason, extra)
  end 
  
  @@logCounter = 0

  #
  # Log a message with 'severity' from 'source'.
  # THe reason is described in string 'reason' with
  # additional information provided in hash table extra
  #
  # @return log id
  def log(severity, source, reason, extra = nil) 
    id = "log_#{@@logCounter += 1}"
    el = LOG_EL.add_element(severity, {'timeStamp' => Time.now, 'id' => id})
    el.text = reason
    if source.kind_of?(Node)
      el.add_attribute('source', source.nodeId)
    end
    extra.each {|k, v|
      el.add_element(k.to_s).text = v
    } if extra != nil
    return id
  end 
  
end

def shutdown(finalStateFile)
  NodeHandler.instance.sendReset
  OmlApp.stopCollectionServer
  
  # dump state
  if (finalStateFile == '-')
    ss = $stdout
  else
    ss = File.open(finalStateFile, 'w')
  end
  ss.write("<?xml version='1.0'?>\n")
  #NodeHandler::DOCUMENT.write(ss, 2, true, true)
  NodeHandler::DOCUMENT.write(ss, 2)
  
  begin 
    NodeHandlerServer::stop 
  rescue Exception
  end
  if NodeHandler.SHUTDOWN
    CMC::nodeAllOff()  
  end
end

def findDefaultLogConfigFile()
  log = ENV['NODEHANDLER_LOG']
  if log != nil
    if ! File.exists?(log)
      raise "Can't find log file '#{log}'"
    end
    return log
  end
  logFile = "nodeHandlerLog.xml"
  [".#{logFile}", "~/.#{logFile}", "/etc/#{logFile}", "log/default.xml"].each {|f|
    if File.exists?(f)
      return f
    end
  }
  return nil
end




require 'optparse'

#MulticastSocket.bind(4444)
runTutorial = false
doProfiling = false
logConfigFile = nil
finalStateFile = "/tmp/#{Experiment.ID}.xml"
startTime = Time.now
webPort = 4000

opts = OptionParser.new
opts.banner = "Usage: nodeHandler [options] expDefFile [-- expOptions]"

#opts.on("-l", "--load FILE", "Pre-load additional experiment definition files") {|file| 
#  Experiment.load(file)
#}
opts.on("-l", "--log FILE", "File containing logging configuration information") {|file| 
  logConfigFile = file
}

opts.on("-n", "--just-print", "Print the commands that would be executed, but do not execute them") {
  NodeHandler.JUST_PRINT = true
}

opts.on("-p", "--port PORT_NO", "Port to start web server on") {|port| 
  webPort = port.to_i
}


opts.on("-r", "--result FILE", "File to write final state information to") {|file| 
  finalStateFile = file
}

opts.on("-s", "--shutdown flag", 
    "If true, shut down grid at the end of an experiment [#{NodeHandler.SHUTDOWN}]") {|flag|
  NodeHandler.SHUTDOWN = (flag == 'true') || (flag == 'yes')
}

opts.on("-t", "--tutorial", "Load tutorial") {
  runTutorial = true
}
  
opts.on_tail("-h", "--help", "Show this message") { puts opts; exit }
opts.on_tail("-v", "--version", "Show the version") { 
  puts NH_VERSION_STRING
  exit
}

#opts.on_tail("-p", "--profile", "Profile node handler") {
#  require 'profiler'
#  Thread.new() {
#    f = File.new('profile.1', 'w')
#    while true do
#      t = sleep 60	  
#      Profiler__::print_profile(f)
#      f.flush
#      Profiler__::reset_profile()
#    end
#  }
#  doProfiling = true
#}


begin 
  rest = opts.parse(ARGV)
  
  # create the loggers.
  if (logConfigFile == nil)
    logConfigFile = findDefaultLogConfigFile
  end
  MObject.initLog('nodeHandler', Experiment.ID, logConfigFile)
  MObject.info('init', NH_VERSION_STRING)
  MObject.info('init', "Experiment ID: #{Experiment.ID}")
  
rescue SystemExit => err
  exit
rescue Exception => ex
  begin 
    bt = ex.backtrace.join("\n\t")
    puts "Exception: #{ex} (#{ex.class})\n\t#{bt}"
  rescue Exception
  end
  exit -1
end

expFile = nil
if runTutorial
  expFile = 'test:exp:tutorial1'
end

rest.each { |s|
  if s[0] == '-'[0]
    break
  end
  if (expFile != nil)
    MObject.fatal('init', "Found additional experiment file '#{s}'")
    puts opts      
    exit -1
  end
  expFile = s
}
if expFile == nil
  MObject.fatal('init', "Missing experiment file")
  puts opts
  exit -1
end

Experiment.expArgs = rest - [expFile]

Profiler__::start_profile if doProfiling
begin
  NodeHandlerServer::start(webPort, {:Logger => Logger.new("web"), :DocumentRoot => "/home/kishore/public_html"})
  
  Experiment.load(expFile) 
  NodeHandler.run

rescue SystemExit
rescue Interrupt
  # ignore
rescue IOError => iex
  MObject.fatal('run', iex)
rescue Exception => ex
  begin 
    bt = ex.backtrace.join("\n\t")
    MObject.fatal('run', "Exception: #{ex} (#{ex.class})\n\t#{bt}")
  rescue Exception
  end
end
shutdown(finalStateFile)

duration = (Time.now - startTime).to_i
MObject.info('run', "Experiment #{Experiment.ID} finished after #{duration / 60}:#{duration % 60}")

