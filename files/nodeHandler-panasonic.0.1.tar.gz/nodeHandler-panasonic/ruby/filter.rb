
require 'property'

#
# This class describes a measurement filter
#
class Filter

  FILTER_URI = "uri:oml:filter"
  
  SAMPLE = "sample_based"
  TIME = "time_based"
  
#  SAMPLE_SIZE = FILTER_URI + ":trigger" # number of samples
#  SAMPLE_RATE = FILTER_URI + ":trigger" # dwell time in seconds
  SAMPLE_SIZE = "trigger" # number of samples
  SAMPLE_RATE = "trigger" # dwell time in seconds

  # Filter definition are below as the need to be after the initialize function

  include CreatePropertiesModule
  
  def Filter.create(idref, properties = nil, returnType = 'long')
    Filter.new(idref, properties, returnType)
  end
  
  
  
  attr_reader :idref, :properties, :returnType
  
  def initialize(idref, properties, returnType)
    @idref = idref
    
    @properties = Array.new
    addProperties(properties)
    @returnType = returnType
  end
  
  #
  # Common filter definitions
  #
#  MIN_MAX = Filter.create(FILTER_URI + ":min-max")
#  MEAN = Filter.create(FILTER_URI + ":mean")
  MIN_MAX = Filter.create(":min-max")
  MEAN = Filter.create("sample_mean")
  SUM = Filter.create("sample_sum")

  def clone(properties = nil)
    f = Filter.new(idref, @properties)
    f.addProperties(properties)
    return f
  end
  
  #
  # Return the object definition as an XML element
  #
  def to_xml
    a = REXML::Element.new("filter")
	a.add_attribute("idref", idref)
	a.add_attribute("refid", idref) # for legacy reason
	a.add_attribute('returnType', returnType) 
	
	if @properties.length > 0
      pe = a.add_element("properties")
      @properties.each {|p|
        pe.add_element(p.to_xml)
      }
    end
	
    return a
  end
  
end

