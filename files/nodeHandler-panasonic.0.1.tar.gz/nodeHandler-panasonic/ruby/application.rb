#
# 
#

require 'version'
require 'measurement'
require 'appProperty'
require 'property'
require 'omlApp'

require 'rexml/document'

#
# This class defines the bindings and configurations
# of an application to be run on a node
# during an experiment. It will refer to an 
# {@link AppDefinition} for information on the 
# available parameters and measurment points
#

class Application < MObject

  include CreatePropertiesModule
	
  # Definition of application
  attr_reader :appDefinition

  # Short and longer description of the application
  #attr_reader :description
	
  # Specific property settings
  attr_reader :properties
	
  # Measurement points used and their configurations/filter
  attr_reader :measurements


  #
  # @param appRef Reference to appliciation definition
  #
  def initialize(appRef, name = idRef)
    super("app:#{appRef}")
    @appRef = appRef
	@appDefinition = AppDefinition[appRef]
    @properties = Array.new
	@measurements = Array.new
  end
  
  #
  # Instantiate this application for a particular 
  # node set.
  #
  # @param nodeSet NodeSet to configure according to this prototype
  # @param vName Virtual name used for this app (used for state name)
  # @param bindings Bindings for local parameters
  #
  def instantiate(nodeSet, vName, context)
    # Create property list
    bindings = Hash.new
    @properties.each {|p|
        # property :idref, :value, :unit, :bindingRef, :isBound
        name = p.idref
        if p.isBound
          value = context[p.bindingRef]
        else
          value = p.value
        end
        bindings[name] = value
    }
    omlUrl = OmlApp.create(self, "#{nodeSet.groupName}_#{vName}")
    env = {'OML_CONFIG' => omlUrl, '%OML_NAME' => 'node%x-%y', 
           'LD_LIBRARY_PATH' => '/usr/local/lib/oml2' }
    nodeSet.addApplication(self, vName, bindings, env)
  end

  #
  # Return true if the application can be installed, or false if it supposed
  # to be native to client's image.
  #
  def installable?
    d = appDefinition
    return d.aptName != nil || d.binaryRepository != nil
  end
  

  #
  # Instantiate this application for a particular 
  # node set.
  #
  # @param nodeSet NodeSet to configure according to this prototype
  # @param vName Virtual name used for this app (used for state name)
  #
  def install(nodeSet, vName)
    if (rep = appDefinition.binaryRepository) == nil 
      raise "Missing binary repository for '#{appDefinition.name}"
    end
    # TODO: Need to differentiate among different install methods (apt, tar)
    nodeSet.send(:INSTALL, ["proc/#{vName}", rep])
  end
  
	
  #
  # Return the application definition as XML element
  #
  def to_xml
    a = REXML::Element.new("application")
	a.add_attribute("refid", appDefinition.uri)
#    a.add_element("description").text = description
    
    if @properties.length > 0
      pe = a.add_element("properties")
      @properties.each {|p|
        pe.add_element(p.to_xml)
      }
    end

    if @measurements.length > 0
      me = a.add_element("measurements")
      @measurements.each {|m|
        me.add_element(m.to_xml)
      }
    end
    return a
  end

	
	
  
  #
  # Define a measurement point.
  #
  # @param idRef Reference to measurement point
  # @param filterMode Type of OML filter - time or sample
  # @param metrics Metrics to use from measurement point
  #
  def addMeasurement(idRef, filterMode, properties = nil, metrics = nil)
    
    mDef = appDefinition.measurements[idRef]
    if (mDef == nil)
      raise "Unknown measurement point '#{idRef}'"
    end
    m = Measurement.new(mDef, filterMode, properties, metrics)
    @measurements += [m]
    return m
  end
  
  def to_s()
    @appRef
  end
  
end

# a = Application['foo']
#
# mu = MutableApplication.new('#goo')
# mu.uri = "change"
# a.uri = "fail"
#
# a2 = Application['#goo']

