#
# Create an application representation from scratch
#
require "appDefinition.rb"


a = AppDefinition.create("nodeAgent")
a.url = "http://apps.orbit-lab.org/nodeAgent"
a.name = "NodeAgent"
a.version(0, 0, 1)
a.shortDescription = "Node Agent"
a.description = "\
    A node agent is active on every experiment node and communicates through \
    semantic multicast with all other agents in the system. It can control all the resources \
    on a node and can react to commands from the management agent to control \
    the life cycle of experiments on the respective node."

# addProperty(name, description, mnemonic, type, isDynamic = false, constraints = nil)
a.addProperty("channel_id", "Channel to send on", "c", "int", true)
a.addProperty("payload_length", "Length of payload of packet", "l", "int", true)


a.addMeasurement("group1", nil, [
  ["rssi", AppMeasurement::FLOAT],
  ["noise", AppMeasurement::FLOAT]
])
a.addMeasurement("group2", nil, [
  ["throughput", AppMeasurement::FLOAT]
])
a.addMeasurement("group3", nil, [
  ["offered_load", AppMeasurement::FLOAT]
])

a.to_xml.write($stdout, 2)
puts




