
Experiment.name = "imageNode"
Experiment.project = "Orbit::Admin"

Experiment.startMode = Experiment::REBOOT


#
# Define nodes used in experiment
#
node([5, 1]).onNodeUp {|n|
  n.saveImage
}
