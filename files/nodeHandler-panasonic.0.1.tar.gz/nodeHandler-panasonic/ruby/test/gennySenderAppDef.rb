#
# Create an application representation from scratch
#
require "appDefinition.rb"

a = AppDefinition.create("gennySender")
a.url = "http://apps.orbit-lab.org/gennySender"
a.name = "gennySender"
a.version(0, 0, 1)
a.shortDescription = "Programmable traffic generator"
a.description = <<TEXT
Genny Sender is a custom UDP traffic generator that is able to send 
packets at a constant bit rate. It can be configured to use libmac 
or plain sockets as its underlying transport mechanism. Users can 
change packet rates and payload lengths during the course of the 
experiment. Genny sender uses pipes to accept run-time arguments 
from users.
TEXT

# addProperty(name, description, mnemonic, type, isDynamic = false, constraints = nil)
a.addProperty('interface_name', "Interface to send on", ?i, String, false)
#a.addProperty(:pipe_name, "Pipe on which genny sender listens on", ?p, String, false)
a.addProperty('rate', "Packet rate", ?r, Integer, true)
a.addProperty('payload_length', "Payload length (bytes)", ?l, Integer, true)
a.addProperty('use_socket', "Socket or Libmac", ?s, :boolean, false)

a.addMeasurement("group3", nil, [
  ["offered_load", Float]
])

a.repository("http://repository.orbit-lab.org/common/gennySender")
a.repository("http://controlpxe.orbit-lab.org/repository/genny-0.3.tar")

a.path = "/opt/genny/bin/gennySender"


if $0 == __FILE__
  a.to_xml.write($stdout, 2)
  puts
end

