require 'resolv'
require 'util/mobject'

#
# An extended object class with support for logging
#
class Websupp
  def Websupp.getPeerSubDomain( req )       
      fqdn = req.peeraddr[2].split('.')
      domain = fqdn.slice(1..fqdn.length).join('.')
      MObject.debug('websupp', 'peer sub domain for ', fqdn, ' is ', domain)
      return domain
  end

  def Websupp.getIPAddresses( querry, domain )
    # We have to get either node name or IP address
    ip = Array.new
    nodeq = querry['node']
    if (nodeq == nil)
      ipq = querry['ip']
      # If we didn't get the node names it must be the list of IP addresses
      if (ipq==nil) 
        raise "Request has to have either 'node' or 'ip' argument"
      end
      ip = ipq.split(',')
    else
      nodeq.split(',').each { |node|
        # It is the node name; get it's IP address
	name = domain == nil || domain == "" ? node : "#{node}.#{domain}"
        MObject.debug('websupp', "Looking for #{name}")
        addr = Resolv.getaddress(name)
        if (addr==nil) 
          raise "Host not found '#{name}'"
        end
        ip<<addr.to_s
      }
    end
    return (ip)
  end

  def Websupp.getAddress( addr )
    begin 
      ip = Resolv.getaddress(addr)
    rescue
      return nil
    end
    return ip
  end

end
