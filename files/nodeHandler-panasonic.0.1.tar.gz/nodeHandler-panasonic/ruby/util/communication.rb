#
# Implements the communication link between the node handler and all its associated agents
#
require 'thread'
require 'benchmark'
require 'external/multicast2.rb'
require 'util/mobject'
require 'util/lineSerializer'

#
# We implement the following communication protocol with an emphasis on 
# minimizing the need for an agent (many) to send to a handler (one). 
# THere is no need for agent to agent communication. 
#
# We also assume that a handler is sending at least a message every N seconds
# allowing an agent to determine if it lost connection to its handler. A special
# command from the handler will solicit "heartbeat" replies from the targeted
# agents, allowing the handler to establish which agents are still listening
#
#
# From handler:
#
#   sequenceNo target command arg1 arg2 ...
#
# From agent:
#
#   senderId contextId command arg1 arg2 ...
#
# 
module NodeCommunication

  # 
  MC_CMD_ADDR = "224.4.0.1"
  MC_RESPONSE_ADDR = "224.4.0.2"
  MC_CMD_PORT = 9006
  MC_RESPONSE_PORT = 9008
  
  CONTROL_IF = 'eth1'
  

  # Initialize the multicast sockets through
  # which to send and receive messages
  #
  # @param agent? Set to true if the node is an agent, false
  #                for the handler
  #
  def initCommunication(isAgent)
  
    @outCount = 0

    @mcInterface = getMCInterface
    MObject.debug("comm", "Binding multicast sockets to interface '#{@mcInterface}'")

#    hostName = Socket.gethostname
    
    @sendPort = isAgent ? MC_RESPONSE_PORT : MC_CMD_PORT
    @sendAddr = isAgent ? MC_RESPONSE_ADDR : MC_CMD_ADDR
#    @sendSock = MulticastSocket.bind(@sendPort)
    @sendSock = MulticastSocket.bind(0, @mcInterface)
    @sendSock.addMembership(@sendAddr)
    MObject.debug("comm", "Open send port #{@sendAddr}:#{@sendSock.addr.join('#')}");
    
    recvPort = isAgent ? MC_CMD_PORT : MC_RESPONSE_PORT
    recvAddr = isAgent ? MC_CMD_ADDR : MC_RESPONSE_ADDR
    @recvSock = MulticastSocket.bind(recvPort, @mcInterface)
    @recvSock.addMembership(recvAddr)
    MObject.debug("comm", "Open receive port #{recvAddr}:#{@recvSock.addr.join('#')}");
    
    # Create two threads, one for receiving packets and one for
    # processing them. Put a queue in between
    queue = Queue.new
    Thread.new() {
      begin
        while true do
          cmd = @recvSock.recvfrom(1024)[0]
          cmd.each {|line|
            #MObject.debug("received line: '#{line}'")
            queue.push(line)
          }
        end
      rescue EOFError
        # do nothing
      rescue Exception => err
        MObject.error("comm", "While listening for commands: #{err}")
      ensure
        @recvSock.close
      end
    }
    Thread.new() {
        while true do
          line = queue.pop
          begin
#            bm = Benchmark.measure {
#              a = LineSerializer.to_a(line)
#              processCommand(a)
#            }
#            MObject.debug("received command (#{queue.length}:#{bm.to_s.chomp}): '#{line}'")
            MObject.debug("comm", "process message (", queue.length, "): '", line, "}'")
            a = LineSerializer.to_a(line)
            processCommand(a)
          rescue Exception => err
            bt = err.backtrace.join("\n\t")
            MObject.error("comm", "While processing command '#{line}' Error: '#{err}'")
            MObject.debug("comm", "While processing command '#{line}' \n\tError: #{err}\n\t#{bt}")
          end
        end
    }
  end
  
  # 
  # Return the IP address of the control interface
  #
  # This method assumes that the 'ifconfig' command returns something like:
  #
  # eth1      Link encap:Ethernet  HWaddr 00:0D:61:46:1E:E1  
  #           inet addr:10.10.101.101  Bcast:10.10.255.255  Mask:255.255.0.0
  #           UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
  #           RX packets:118965 errors:0 dropped:0 overruns:0 frame:0
  #           TX packets:10291 errors:0 dropped:0 overruns:0 carrier:0
  #           collisions:0 txqueuelen:1000 
  #           RX bytes:17394487 (16.5 MiB)  TX bytes:1073233 (1.0 MiB)
  #           Interrupt:11 Memory:eb024000-0 
  #
  def getMCInterface
    if MulticastSocket.unix?
      match = /[.\d]+\.[.\d]+\.[.\d]+\.[.\d]+/
      controlIP = IO.popen("/sbin/ifconfig #{CONTROL_IF}", "r").readlines[1][match]
      # hack for APP1
      if controlIP == nil
        controlIP = IO.popen("/sbin/ifconfig eth0", "r").readlines[1][match]
      end   
    else
#      # This only works for PPP connections
#      IO.popen("route print", "r").each {|l| 
#        if l[/^Default/]
#          controlIP = l[/\d*\.\d*\.\d*\.\d*/]
#          break
#        end
#      }
      controlIP = nil
#      controlIP = "192.168.1.56"   
#      controlIP = "172.16.1.46"   
#      controlIP = "192.168.121.234"
    end
    MObject.debug("comm", "Control IP: #{controlIP}")
    return controlIP
  end


end

  
  