#
# 
#

require "version.rb"
require "parameter.rb"
require "application.rb"
require "measurement.rb"

require "rexml/document"

#
# This class describes a prototype which can be used 
# for an experiment on Orbit
#

class Prototype

  private_class_method :new
	
  @@prototypes = Hash.new

  #
  # Return a known prototype instance.
  #
  # @param uri URI identifying the prototype
  #
  def Prototype.[](uri)
    proto = @@prototypes[uri]
    if proto == nil
      MObject.debug('Prototype: ', 'Loading prototype "', uri, '".')
      str, type = OConfig.load(uri, true)
      #MObject.debug('Prototype: ', 'str: "', str, '".')
      if type == "text/xml"
        # proto = Prototype.from_xml(str.to_xml???)
      elsif type == "text/ruby"
        # 'str' has already been evaluated
        proto = @@prototypes[uri]
      end
      if proto == nil
        raise "Unknown prototype '#{uri}'."
      end
    end
    return proto
  end
	
  #
  # Return a known AppDefinition instance.
  #
  # @param id URI identifying the AppDefinition
  #
  def Prototype.create(uri, name = uri)
	return MutablePrototype.new(uri, name)
  end

  # Global reference
  attr_reader :uri

  # Name of prototype	
  attr_reader :name
	
  # Version of prototype
  attr_reader :version
	
	
  # Description of the prototype
  attr_reader :description
	
  # Parameters of the prototype
  attr_reader :parameters
		
  # Applications used on the prototype
  attr_reader :applications

  def initialize(uri, name = uri)
    if @@prototypes.has_key? uri
      raise "prototype with name '" + uri + "' already exists."
    end
    @@prototypes[uri] = self

    @uri = uri
    @name = name
    @properties = Hash.new
	@applications = Hash.new
  end
	
  #
  # Instantiate this prototype for a particular 
  # node set.
  #
  # @param nodeSet NodeSet to configure according to this prototype
  # @param bindings Bindings for local parameters
  #
  def instantiate(nodeSet, bindings)
    if bindings == nil : bindings = Hash.new end
    # check if bindings contain unknown properties
    if (diff = bindings.keys - @properties.keys) != []
      raise "Unknown parameters '#{diff.join(', ')}'" \
        + " not in '#{@properties.keys.join(', ')}'."
    end
  	# merge bindings with properties declaration
  	context = Hash.new
  	@properties.each {|name, param|
  	  if (bindings.has_key? name)
  	    context[name] = bindings[name]
  	  else
  	    # use default 
  	    if (default = param.defaultValue) == nil
  	      raise "Property #{name} is required"
  	    end
  	    context[name] = default
  	  end
  	}
    @applications.each {|name, app|
      app.instantiate(nodeSet, name, context)
    }    
  end
  
  #
  # Return the prototype definition as XML element
  #
  def to_xml
    a = REXML::Element.new("prototype")
	a.add_attribute("id", @uri)
	a.add_element("name").text = name != nil ? name : uri 
#    if (uri != nil) 
#      a.add_element("url").text = uri
#    end
    
    if (version != nil) 
      a.add_element(version.to_xml)
    end
    a.add_element("description").text = description
    
    if @properties.length > 0
      pe = a.add_element("properties")
      @properties.each_value {|p|
        pe.add_element(p.to_xml)
      }
    end

    if @applications.length > 0
      ae = a.add_element("applications")
      @applications.each_value {|app|
        ae.add_element(app.to_xml)
      }
    end
    
    return a
  end
end

#
# These instances can be edited
#
class MutablePrototype < Prototype

	public_class_method :new
	
	attr_writer :uri, :name, :description
	
	def initialize(uri, name = uri)
	    super(uri)

	end
	
	#
	# Define a property for this prototype
	#
	# @param id ID of parameter, also used as name
	# @param description Description of parameter's purpose
	# @param default Default value if not set, makes parameter optional
	#
	def defProperty(id, description, default = nil)
      if @properties[id] != nil
        raise "Property '" + id + "' already defined."
      end
	  param = Parameter.new(id, id, description, default)
	  @properties[id] = param
	end
	
	def setVersion(major = 0, minor = 0, revision = 0)
	  @currentVersion = MutableVersion.new(major, minor, revision) 
	end
	
	#
	# Add an application which should be installed on this prototype.
	#
	# @returns The newly create application object
	# @param name Name used for reference
	# @param idRef Reference to application
	#
	def addApplication(name, idRef)
	  
	  if @applications.has_key? name
	    raise "Prototype already has an application '" + name + "'."
	  end
	  app = Application.new(idRef, name)
	  @applications[name] = app
	  return app
	end
	
end


