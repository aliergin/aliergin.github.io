require 'util/mobject'
require 'prototype'
require 'rexml/document'
require 'rexml/element'
require 'rexml/xpath'
require 'util/arrayMD'
require 'observer'
require 'date'
require 'net/http'



class Node < MObject
  include Observable
  
  W0_IF = "eth2"
  W_ADHOC = "ad-hoc"
  
  STATUS_DOWN = 'DOWN'
  STATUS_UP = 'UP'
  
  ALIAS_CMD = 'ALIAS'
  
  DEFAULT_DISK = '/dev/hda'
  
  FRISBEE_SERVICE = 'http://frisbee:5012/frisbee'
  
  @@nodes = ArrayMD.new
  @@nodeAliases = Hash.new  # mapping between aliases and node 
  @@nodeRoot = nil
  @@nodeColsEl = Array.new
  @@groupsEl = Hash.new  
  
  #
  # Return the node at location 'x'@'y'.
  # If no node exists, return nil.
  #
  def Node.[] (x, y)
    n = @@nodes[x][y]
    # take care of ArrayMD elements
    return n.kind_of?(Node) ? n : nil
  end
  
  #
  # Return the node at location 'x'@'y'.
  # If no node exists, create a new one.
  #
  def Node.at! (x, y)
    n = @@nodes[x][y]
    if !n.kind_of?(Node)
      n = Node.new(x, y)
    end
    return n
  end
  
  # Return an array of nodes matching
  # the 'xpathExpr'
  #
  def Node.match(xpathExpr) 
    m = REXML::XPath.match(NodeHandler::ROOT_EL, "nodes/#{xpathExpr}")
    nodes = Set.new
    m.each { |ne|
      if ne.kind_of?(NodeElement)
        nodes.add(ne.node)
      end
    }
    return nodes.to_a
  end
  
  #
  # Return node which is expected to be 
  # initially identified by 'idString'.
  #
  # @return Node, or nil if not found
  #
  def Node.whoIs(idString)
    if (idString =~ %r{^/ip/}) != nil
      # this is an initial check-in, so we'll even create it
      begin
        x, y = OConfig.getCoordFromControlIP(idString)
        return Node[x, y]
      rescue Exception
        # don't do anything
      end
    end
    # we assume 'idString is a known alias
    return @@nodeAliases[idString]
  end
  
  #
  # Execute block for every created node
  #
  def Node.each(&block)
    @@nodes.each(&block)
  end
  
  attr_reader :x, :y
  
  # True if node is up, false otherwise
  attr_reader :isUp
  
  # A set listing all the group memberships for this node
  attr_reader :groupMembership
  
  # ID of shadow xml node
  attr_reader :nodeId

  # Name of image to expect on node
  attr_writer :image  
  
  public :to_s
  
  #
  # Return the IP address of the node's control interface
  #
  def getControlIP()
    return OConfig::getControlIP(x, y)
  end

  #
  # Return the name of the node
  #
  def getNodeName()
    return "node"+x.to_s+"-"+y.to_s
  end
  
  #
  # Add an application to this node 
  #
  # @param app Application definition
  # @param vName Virtual name given to this app
  # @param paramBindings Parameter bindings for this application
  # @param env Envioronment to set before starting application
  #
  def addApplication(app, vName, paramBindings, env)
    procEl = getConfigNode(['apps'])
    @apps["app:#{vName.to_s}"] = NodeApp.new(app, vName, paramBindings, env, self, procEl)
    debug("Add application #{vName}:#{app} to #{self}")
  end
  
  #
  # An appliciation on this node produced an event
  #
  # @param eventName Name of event
  # @param appId Logical name of app
  # @param message Explanatory message
  #
  def onAppEvent(eventName, appId, message)
    debug("Message for app '#{appId}'")
    appName, op = appId.split('/')
    app = @apps[appName]
    if (app == nil)
      warn("Received event '#{eventName}' for unknown application '#{appName}'")
      return
    end
    app.onEvent(op, eventName, message)   
  end
  
  def ready?
    app.each { |a|
      if !a.isReady
        return false
      end
    }
    return true
  end
  
  #
  #
  def addAlias(group, individual = nodeId)
    group = group.to_s
    if (group[0] == '/'[0])
      group = group[1..-1]
    end
    name = "/#{group}/#{individual}"
    debug("Add alias #{name}")
    @aliases.add(name)
    @@nodeAliases[name] = self
    groupEl = @@groupsEl[group]
    if groupEl == nil
      groupEl = @@nodeRoot.add_element('group', {'name' => group}) 
      @@groupsEl[group] = groupEl
    end
    NodeElement.new(self, name, groupEl, @el, nodeId)
  end
  
  #
  # Set resource 'path' to 'value'
  #
  # @param path Path to resource
  # @paran value New value
  #
  def configure(path, value, status = "unknown")
    if (value.kind_of?(String) && value[0] == '%'[0])
      # if value starts with "%" perform certain substitutions
      value = value[1..-1]  # strip off leading '%'
      value.sub!(/%x/, @x.to_s)
      value.sub!(/%y/, @y.to_s)
    end
    el = getConfigNode(path)
    el.text = value
    el.add_attribute('status', status)
  end

  #
  # Save the image currently stored on the node's disk to
  # 'nsfDir', a NSF mountable directory and name the 
  # image 'imgName'. 
  #
  # If no image name is given, a name is formed 
  # using the pattern "node-#{x}:#{y}-#{ts}.ndz",
  # where 'x' and 'y' are the node's coordinate and 
  # 'ts' is a time stamp of the form 'YYYY-MM-DD-hh:mm:ss'.
  #
  # @param imgName Name of file containing image
  # @param nsfDir NSF mountable directory to store image 
  #                  ['frisbee:/orbit/image/tmp']
  # @param disk Disk to save ['/dev/hda']
  # 
  def saveImage(imgName = nil, 
                nsfDir = 'frisbee:/export/orbit/image/tmp', 
                disk = DEFAULT_DISK)
                
    if imgName == nil
      ts = DateTime.now.strftime("%F-%T")
      #imgName = "node-#{x}:#{y}-#{ts}.ndz"
      imgName = "node-#{x}-#{y}-#{ts}.ndz".split(':').join('-')
    end
    procEl = getConfigNode(['apps'])
    info("Saving #{disk} from #{@nodeId} as \"tmp/#{imgName}\"")
    params = {:imgName => imgName, :nsfDir => nsfDir, :disk => disk}
    @apps['builtin:save_image'] = NodeBuiltin.new('save_image', params, self, procEl, 'ISSUED')
    send('SAVE_IMAGE', nsfDir, imgName)
  end
  
  #
  # Load an image onto this node using frisbee.
  #
  # @param image Name of image in repository
  # @param disk Disk to image [DEFAULT_DISK]
  # 
  def loadImage(image, disk = DEFAULT_DISK)
    procEl = getConfigNode(['apps'])
    params = {:image => image, :disk => disk}
    @apps['builtin:load_image'] = NodeBuiltin.new('load_image', params, self, procEl)
  end

  # 
  # Send the LOAD_IMAGE command immediately to the node.
  #
  # @see loadImage
  def loadImage!(image, disk = DEFAULT_DISK)
    loadImage(image, disk)
    
    # get frisbeed address
    url = "#{FRISBEE_SERVICE}/getAddress?img=#{image}"
    debug "HTTP.Get #{url}"
    
    if NodeHandler.JUST_PRINT
      puts "FRISBEE: Prepare image #{image} for node #{nodeId}"
      mcAddress = "Some_MC_address"
      mcPort = "Some_MC_port"
    else
      response = Net::HTTP.get_response(URI.parse(url))
      if (! response.kind_of? Net::HTTPSuccess)
        raise "Can't get frisbee address #{response.to_s}"
      end
    
      debug "Frisbee service Code = #{response.code} Body: #{response.body}"
      mcAddress, mcPort = response.body.split(':')
    end
      
    debug "Loading image from frisbee multicast #{mcAddress}::#{mcPort}"
    
    app = @apps['builtin:load_image']
    app.setStatus('ISSUED')
    app.addProperty(:mcAddress, mcAddress)
    app.addProperty(:mcPort, mcPort)
    send('LOAD_IMAGE', mcAddress, mcPort, disk)
  end

    
  #
  # Set the status of a configurable resource of this node
  #
  # @param path Name of resource
  # @param status Status of resource
  # @param extra Optional hash table defining additional status attributes
  #
  def configureStatus(path, status, optional = nil)
    el = getConfigNode(path)
    el.add_attribute('status', status)
    optional.each {|k, v|
      el.add_attribute(k.to_s, v)
    } if optional != nil
  end
  
  #
  # Power the node on
  #
  def powerOn()
      CMC::nodeOn(x, y)
  end
  
  #
  # Power the node off
  #
  def powerOff()
      CMC::nodeOff(x, y)
  end

  #
  # Reset the node
  #
  def reset()
      CMC::nodeReset(x, y)
  end
      
  
  #
  # Grid node checks in, set status to "UP" and 
  # inform all registered node sets.
  #
  # @param initialName Initial name of node
  # @param agentVersion Version of node agent
  # @param cmdVersion Version of commands supported by node agent
  # @param image Name of image installed on node
  #
  def checkIn(initialName, agentVersion, image)
    info("Node #{to_s} checked in as #{initialName} booting off #{image}")
    NodeHandler::sendCommand(initialName, ALIAS_CMD, [getFullName] << @aliases.to_a)
    @isUp = true
    @statusEl.text = STATUS_UP
    changed
    notify_observers(self, :node_is_up)
    if (image != @image) 
      warn("Expected image '", @image, "', but node reported '", image, "'.")
      changed
      notify_observers(self, :node_wrong_image)      
    end
  end
  
  #
  # Send a command to node. This is for Experts ONLY
  # and should be used with care.
  #
  # @param command Command 
  # @param args Array of parameters
  #
  def send!(command, *args)
    send(command, *args)
  end

  #
  # Warning this is a HACK
  #
#  def inSequence?(senderSeq)
#    if (senderSeq < 0)
#      # these are retry requests
#      return true
#    end
#    if (senderSeq > @senderSeq + 1)
#      debug("#{to_s}: Missed messages #{@senderSeq + 1} to #{senderSeq - 1}")
#      # this is a bit a hack. We can have a node sending retries
#      # while we still think it is down. Right now we simply ignore that
#      if (! @isUp)
#        warn "#{to_s} is sending messages, but is considered down"
#        return true
#      end
#      # Retry messages should really be sent as special messages, not causing a 
#      # retry themselves if a node misses one.
#      send('RETRY', @senderSeq + 1)
#      return false
#    elsif (senderSeq <= @senderSeq)
#      # already got that
#      return false
#    end
#    @senderSeq = senderSeq
#    return true
#  end
  
  #
  # Received a timestamp from the node
  #
  def heartbeat(sendSeqNo, recvSeqNo, timestamp)
#    # check if we received all packets
#    inSequence?(sendSeqNo)
    
    @heartbeat.add_attribute('ts', timestamp)
    @heartbeat.add_attribute('sentPackets', sendSeqNo)
    @heartbeat.add_attribute('receivedPackets', recvSeqNo)
  end
  
  # Return the result of an XPath match with this nodes root element at 
  # its seed.
  #
  def match(xpathExpr) 
    m = REXML::XPath.match(@el, xpathExpr)
    return m
  end
  
  def getFullName()
    return "/#{getRowName}/#{getColName}"
  end
  
  private
  
  def initialize(x, y)
    @nodeId = "n_#{x}_#{y}"
    super("node::#{@nodeId}")
    
    @x = x
    @y = y
    @aliases = Set.new
    @apps = Hash.new
    @isUp = false
#   @senderSeq = 0
    
    @@nodes[x][y] = self
    @@nodeAliases[getFullName] = self

    # maintain XML shadow of node state
    rowEl = @@nodeColsEl[x]
    if rowEl == nil
      if @@nodeRoot == nil
        @@nodeRoot = NodeHandler::NODES_EL
      end
      rowEl = @@nodeRoot.add_element('row', {'x' => x}) 
      @@nodeColsEl[x] = rowEl
    end
    @el = NodeElement.new(self, getFullName, rowEl, nil, @nodeId)
    @statusEl = @el.add_element("status")
    @statusEl.text = STATUS_DOWN
    
    @heartbeat = @el.add_element("heartbeat")
    
    
    debug "Created node #{x}@#{y}"
  end
  
  #
  # Send a command to node
  #
  # @param command Command 
  # @param args Array of parameters
  #
  def send(command, *args)
    #debug("nodeSet#send: args(#{args.length})'#{args.join('#')}")
    if (@isUp)
      NodeHandler.sendCommand(getFullName, command, args)
    else
      raise "Node not up. Embed command in 'onNodeUp' block"
#      debug "Deferred message: #{command} #{@nodeSelector} #{args.join(' ')}"
#      @deferred << [command, args]
    end
  end
  
  
  def getRowName()
    return "r_#{x}"
  end
 
  def getColName()
    return "c_#{y}"
  end
  
  
 
  #
  # Return an XML element whose path (an array) is relative
  # to this element's root element (@el)
  # 
  def getConfigNode(path)
  
    parent = @el
    el = nil
    path.each {|name|
      if (el = parent.elements[name]) == nil
        el = parent.add_element(name)
      end
      parent = el
    }
    return el
  end  
  

  def to_s()
    return "#{@nodeId}(#{@aliases.to_a.join(', ')})"
  end
  
    
end

#
# XML element representing a Node
#
class NodeElement < REXML::Element

  attr_reader :node

  def initialize(node, name, parent, refEl, id)
    super('node', parent, nil)
    @node = node
    @refEl = refEl
    
    if refEl == nil
      # direct element
      add_attribute('id', id)
	  add_attribute('name', name);
	  add_attribute('x', node.x);
	  add_attribute('y', node.y);	
	else
      @elements = refEl.elements
#p @elements
	  @attributes = refEl.attributes
	  @children = refEl._children
      @href = id
    end
  end
  
  def _children
    return @children
  end
end


#
# Helper class for built in commands
#
class NodeBuiltin < MObject

  # @param vName Virtual name given to this app
  # @param paramBindings Parameter bindings for this application
  # @param node Node this application belongs to
  # @param procEl 'apps' element in state tree
  #
  def initialize(vName, paramBindings, node, procEl, status = 'UNKNOWN')
    
    @el = procEl.add_element('builtin', {'name' => vName.to_s})
    @statusEl = @el.add_element('status')
    setStatus(status)
    
    @param = @el.add_element('properties')
    paramBindings.each {|k, v|
      if v.class == ExperimentProperty
        @param.add_element(k.to_s, {'idref' => v.id}).text = v.value      
      else
        @param.add_element(k.to_s).text = v
      end
    }
    @io = @ioOut = @ioErr = nil
    
  end
  
  def addProperty(name, value)
    @param.add_element(name.to_s).text = value
  end

  def getTS()
    return DateTime.now.strftime("%T")
  end
  
  def setStatus(status)
    @statusEl.text = status
    @statusEl.add_element('history', {'ts' => getTS()}).text = status
  end
  
  def getIoEl()
    if @io == nil
      @io = @el.add_element('io')
    end
    return @io
  end

  def getStdoutEl()
    if @ioOut == nil
      @ioOut = getIoEl.add_element('out')
    end
    return @ioOut
  end

  def getStderrEl()
    if @ioErr == nil
      @ioErr = getIoEl.add_element('err')
    end
    return @ioErr
  end
  
  def addLine(ioEl, message)
    ioEl.add_element('line', {'ts' => getTS()}).text = message
  end
  
  def onEvent(op, eventName, message)
    case eventName
      when 'STARTED'
          setStatus "STARTED"
      when 'DONE.OK'
          setStatus "DONE.OK"
      when 'DONE.ERROR'
          setStatus "DONE.ERROR"
      when 'STDOUT'
          addLine(getStdoutEl, message)
      when 'STDERR'
          addLine(getStderrEl, message)

      else
          setStatus "UNKNOWN.EVENT: #{eventName} #{message}"       
      end 
  end
end

#
# Helper class for applications running on a node
#
class NodeApp < NodeBuiltin

  # @param app Application definition
  # @param vName Virtual name given to this app
  # @param paramBindings Parameter bindings for this application
  # @param env Envioronment to set before starting application
  # @param node Node this application belongs to
  # @param procEl 'apps' element in state tree
  #
  def initialize(app, vName, paramBindings, env, node, procEl)
    super(vName, paramBindings, node, procEl, 
            app.installable? ? "INSTALL_PENDING" : "INSTALLED.OK")
    @env = env

    @el.name = 'app'
    @isReady = ! app.installable?
    @el.add_element('appDef', {'href' => app.appDefinition.uri})
    
    if env != nil
      envEl = @el.add_element('envList')
      env.each {|k, v|
        envEl.add_element('env', {'name' => k.to_s}).text = v.to_s      
      }
    end
  end
  
  def onEvent(op, eventName, message)
    if (op == 'install')
      case eventName
        when 'DONE.OK'
          setStatus("INSTALLED.OK")
          @isReady = true
        when 'DONE.ERROR'
          setStaus("INSTALLED.ERROR")
        else
          super(op, eventName, message)       
      end 
    else
      super(op, eventName, message)
    end
  end
end


