#
# Implements various servlets to control what Cmc serves to nodes
#

require 'webrick'
require 'stringio'
require 'log4r'
require 'util/mobject'
require 'util/websupp'
require 'net/http'


include WEBrick

module CmcService

  # Directory holding Cmc information
  Cmc_DIR = "/tftpboot/Cmclinux.cfg"
  
  CMC_HOST = "http://cmc.orbit-lab.org"
  CMC_URL = {
    "grid.orbit-lab.org" => "controlgrid.html",
    "sandbox1.orbit-lab.org" => "controlsandbox1.html" 
  }

  def CmcService.mount(prefix = '/cmc')
    GridService.mount_proc(prefix) {|req, res|
      res['ContentType'] = "text/html"
      res.body = %{<?xml version='1.0'?>
        <serviceGroup name="cmc">
          <info>Controls nodes through their attached CMs</info>
          <service name="on">
            <info>Switch on a node at a specific coordinate</info>
            <args><arg name="x" value="x_coord"/></args>
            <args><arg name="y" value="y_coord"/></args>
          </service>
          <service name="off">
            <info>Switch off a node at a specific coordinate</info>
            <args><arg name="x" value="x_coord"/></args>
            <args><arg name="y" value="y_coord"/></args>
          </service>
          <service name="allOff">
            <info>Switch all nodes off</info>
          </service>
          <service name="reset">
            <info>Reset a node at a specific coordinate</info>
            <args><arg name="x" value="x_coord"/></args>
            <args><arg name="y" value="y_coord"/></args>
          </service>
          <service name="status">
            <info>Returns the settings of this service</info>
          </service>
        </serviceGroup>
      }
    }
    GridService.mount("#{prefix}/on", SwitchOnNodeServlet)
    GridService.mount("#{prefix}/off", SwitchOffNodeServlet)    
    GridService.mount("#{prefix}/allOff", SwitchOffAllNodesServlet)        
    GridService.mount("#{prefix}/reset", ResetNodeServlet)            
    GridService.mount("#{prefix}/status", StatusServlet)  

  end
  
  #
  # Switch on a node at a specific location
  #
  class SwitchOnNodeServlet < HTTPServlet::AbstractServlet
    def do_GET(req, res)
      x, y = CmcService.getCoords(req)
      cmcCommand = "cmd=U&x=#{x}&y=#{y}"  
      CmcService.issueCmcCommand(cmcCommand, req, res)
    end
  end

  #
  # Switch off a node at a specific location
  #
  class SwitchOffNodeServlet < HTTPServlet::AbstractServlet
    def do_GET(req, res)
      x, y = CmcService.getCoords(req)
      cmcCommand = "cmd=d&x=#{x}&y=#{y}"  
      CmcService.issueCmcCommand(cmcCommand, req, res)
    end
  end
  
  #
  # Switch off ALL nodes
  #
  class SwitchOffAllNodesServlet < HTTPServlet::AbstractServlet
    def do_GET(req, res)
      cmcCommand = "cmd=d&x=ALL&y=ALL"  
      CmcService.issueCmcCommand(cmcCommand, req, res)
    end
  end
  
  #
  # Reset a node at a specific location
  #
  class ResetNodeServlet < HTTPServlet::AbstractServlet
    def do_GET(req, res)
      x, y = CmcService.getCoords(req)
      cmcCommand = "cmd=R&x=#{x}&y=#{y}"  
      CmcService.issueCmcCommand(cmcCommand, req, res)
    end
  end
  
  def CmcService.getCoords(req)
    q = req.query
    x = q['x']
    y = q['y']  
    # Do we have everything?
    if (x == nil || y == nil)
      raise HTTPStatus::BadRequest, "Missing argument 'x', or 'y'"
    end
    return [x, y]
  end
    
  def CmcService.issueCmcCommand(cmd, req, res)

    # Which subdomain did the request come from?
    domain = Websupp.getPeerSubDomain(req)
    page = CMC_URL[domain]
    if page == nil
      raise HTTPStatus::BadRequest, "Unsupported domain '#{domain}'"
    end
      
    url = "#{CMC_HOST}/#{page}?#{cmd}"
    MObject.debug "CMC.IssueCommand", "url: ", url
      
    response = Net::HTTP.get_response(URI.parse(url))
    if (! response.kind_of? Net::HTTPSuccess)
      raise HTTPStatus::BadRequest("Error while issuing #{url}")
    end
      
    res['ContentType'] = "text"
    res.body = "OK"
  end

  class StatusServlet < HTTPServlet::AbstractServlet
    def do_GET(req, res)
      res['ContentType'] = "text/xml"
      s = %{<?xml version='1.0'?>
        <CMC_STATUS>
          <CMC_HOST>#{CMC_HOST}</CMC_HOST>
          <domains>
      }
      CMC_URL.each { |key, value|
        s += "<domain name='#{key}' page='#{value}' />"
      }
      s += "</domains> </CMC_STATUS>"
      res.body = s
    end
  end

end

if $0 == __FILE__
include Log4r

  MObject.initLog('CmcService')

  MObject.info("Cmc Service Testharness")
  module GridService

    SERVER = HTTPServer.new(
      :Port => 5012,
      :Logger => Logger.new("#{MObject.logger.fullname}::web")
    )

    def GridService.mount(name, servlet)
      SERVER.mount(name, servlet)
    end

    def GridService.mount_proc(name, &block) 
      SERVER.mount_proc(name, &block)
    end
  end

  trap("INT") { GridService::SERVER.shutdown }
  GridService::SERVER.start

end

CmcService::mount()
