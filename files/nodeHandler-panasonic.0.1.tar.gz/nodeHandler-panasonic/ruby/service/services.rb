#!/usr/bin/ruby
#
# Implements various servlets to control a frisbee server
#

require 'webrick'
require 'log4r'
require 'util/mobject'

#require 'service/pxe'
#require 'service/frisbee'
#require 'service/cmc'

include WEBrick
include Log4r

binpath = ENV['GRID_SERVICES_BIN'] != nil ? ENV['GRID_SERVICES_BIN'] : "/opt/gridservices/service"
# Make sure log exists ...
raise "gridservices: Can't find executable directory" if (!FileTest.exists?(binpath) || !FileTest.directory?(binpath))

log = ENV['GRID_SERVICES_LOG'] != nil ? ENV['GRID_SERVICES_LOG'] : "/etc/gridservice/gridservices_log.xml"
# Make sure log exists ...
log = File.exists?(log) ? log : nil

MObject.initLog('services', log)
MObject.info("Orbit Services")

module GridService
  SERVER = HTTPServer.new(
    :Port => 5012,
    :Logger => Logger.new("#{MObject.logger.fullname}::web")
  )

  def GridService.mount(name, servlet) 
    SERVER.mount(name, servlet)
  end

  def GridService.mount_proc(name, &block) 
    SERVER.mount_proc(name, &block)
  end

  def GridService.mount_file( url, path ) 
    SERVER.mount(url, HTTPServlet::FileHandler, path) { 
      raise HTTPStatus::NotFound, " #{binpath}/favicon.ico not found."
    }
  end

end

trap("INT") { GridService::SERVER.shutdown }
GridService::mount_file( "/favicon.ico", binpath+"/favicon.ico" )
Dir.foreach(binpath) {|filename|
  if ((filename =~ /\.rb$/) && (filename != 'services.rb') ) then
    MObject.info("Found #{filename} service module")
    require binpath+"/"+filename
  end
}
GridService::SERVER.start


