#
# Define a prototype
#

require 'prototype'
require 'filter'
require 'appDefinition'

p = Prototype.create("test:proto:receiver")
p.name = "Receiver"
p.description = "Nodes which receive packets"
p.defProperty('protocol', 'Protocol to use', 'udp')
p.defProperty('port', 'Port to listen on', 4000)
p.defProperty('hostname', 'My own ID for libmac filter', 'localhost')

otr = p.addApplication('otr', "test:app:otr")
otr.bindProperty('protocol')
otr.bindProperty('port')
otr.bindProperty('hostname')

otr.addMeasurement('receiverport',  Filter::TIME, 
  {Filter::SAMPLE_SIZE => 1},
  [
    ['stream_no'],
    ['pkt_seqno'],
    ['sender_port'],
    ['flow_no'],
    ['pkt_num_rcvd'],
    ['rcvd_pkt_size', Filter::SUM],      
    ['rx_timestamp'],
    ['rssi'],
    ['xmitrate']
  ]
)

if $0 == __FILE__
  p.to_xml.write($stdout, 2)
  puts
end

