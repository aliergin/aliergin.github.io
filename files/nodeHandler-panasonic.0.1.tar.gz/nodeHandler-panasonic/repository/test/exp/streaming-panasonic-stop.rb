require 'net/http'
require 'uri'

Experiment.name = "tutorial-1"
Experiment.project = "orbit:tutorial"

#
# Define various elements used in the experiment
#

defProperty('rate', 300, 'Bits per second sent from sender')
defProperty('packetSize', 256, 'Size of packets sent from sender')
defProperty('startExp', 0, 'Start experiment flag')

# Streaming Sources
defNodes('sender', [[1,2],[1,8],[2,1],[2,5],[3,2],[3,8],[4,1],[4,7]]) {|node|
  # Dummy
  node.image = nil  # assume the right image to be on disk
  node.prototype("test:proto:sender", {
    'destinationHost' => '192.168.2.1',
    'packetSize' => Experiment.property("packetSize"),
    'rate' => Experiment.property("rate"),
    'protocol' => 'udp'
  })
  node.net.w0.down = "true"
  node.net.w1.down = "true"
  node.net.w0.unload = "ath_pci"
  node.net.w0.load = "ath_pci"
  node.net.w0.type = 'a'
  node.net.w0.essid = "something"
  node.net.w0.mode = "managed"
  node.net.w0.rate = "54M"
  node.net.w0.ip = "%192.168.%x.%y"
  node.net.w0.bash = "/root/stop-everything.sh"
}

#
# Now, start the application
#
whenAllInstalled() {|node|
  Experiment.props.packetSize = 1024
  Experiment.props.rate = 5000
  Experiment.props.startExp = 0

  Experiment.done
}



