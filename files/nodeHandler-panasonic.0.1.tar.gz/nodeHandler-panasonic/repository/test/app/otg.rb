#
# Create an application representation from scratch
#
require 'appDefinition'

a = AppDefinition.create('test:app:otg')
a.name = "otg"
a.version(0, 0, 1)
a.shortDescription = "Programmable traffic generator"
a.description = <<TEXT
OTG is a configurable traffic generator. It contains generators 
producing various forms of packet streams and port for sending
these packets via various transports, such as TCP and UDP.
TEXT

# addProperty(name, description, mnemonic, type, isDynamic = false, constraints = nil)
a.addProperty('protocol', 'Protocol to use [udp|tcp]', nil, String, false)

# UDP
a.addProperty("hostname", "Name of local host [name]", nil, String, false)
a.addProperty("port",  "Local port to bind to [int]", nil, Integer, false)
a.addProperty("dsthostname", "Name of destination host [string]", nil, String, false)
a.addProperty("dstport", "Destination port to send to", nil, String, false)
#a.addProperty("pause", "Pause the traffic Sending of port ", nil, String, false)
#a.addProperty("resume", "Resume the traffic Sending of port ", nil, String, false)

# CBR
a.addProperty("size", "Size of packet [bytes]", nil, Integer, false)
a.addProperty("interval", "Internval between consecutive packets [msec]", nil, Integer, false)
a.addProperty("rate", "Data rate of the flow [kbps]", nil, Integer, false)

a.addMeasurement("senderport", nil, [
    ['stream_no', 'int'],
    ['pkt_seqno', 'long'],
    ['pkt_size', 'long'],
    ['gen_timestamp', 'long'],
    ['tx_timestamp', 'long']
])

#a.repository("http://repository.orbit-lab.org/common/gennySender")
#a.repository("http://controlpxe.orbit-lab.org/repository/genny-0.3.tar")
#a.aptName = 'orbit-otg'

a.path = "/usr/local/bin/otg"


if $0 == __FILE__
  require 'stringio'
  require 'rexml/document'
  include REXML
    
  sio = StringIO.new()
  a.to_xml.write(sio, 2)
  sio.rewind
  puts sio.read
  
  sio.rewind
  doc = Document.new(sio)
  t = AppDefinition.from_xml(doc.root)
  
  puts
  puts "-------------------------"
  puts
  t.to_xml.write($stdout, 2)
  
end

