
Experiment.name = "imageNode"
Experiment.project = "Orbit::Admin"

defProperty('node', [1, 1], "Node to save image of")

#
# Define nodes used in experiment
#
defNodes('save', Experiment.property('node')) {|n|
  n.pxeImage("orbit-1.0.5", "pxe:1.0.5")
  n.onNodeUp {|n|
    n.saveImage
  }
}

whenAll('save', "apps/builtin/status[text()='DONE.OK']") {|node|
  node.pxeImage(nil)
  Experiment.done
}



